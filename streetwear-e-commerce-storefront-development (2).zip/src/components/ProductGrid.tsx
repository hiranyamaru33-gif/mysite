import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import type { ProductSummary } from "@/lib/types";

export default function ProductGrid({
  products,
  priorityCount = 0,
  columns = 4,
  emptyMessage = "No pieces match that combination.",
}: {
  products: ProductSummary[];
  priorityCount?: number;
  columns?: 3 | 4;
  emptyMessage?: string;
}) {
  const cols =
    columns === 3
      ? "sm:grid-cols-2 lg:grid-cols-3"
      : "grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4";

  if (!products.length) {
    return (
      <div className="rounded-2xl border border-dashed border-white/15 px-6 py-20 text-center">
        <p className="text-sm text-bone/50">{emptyMessage}</p>
        <Link href="/shop" className="btn btn-ghost mt-6">
          Reset filters
        </Link>
      </div>
    );
  }

  return (
    <div className={`grid gap-x-5 gap-y-12 sm:gap-x-6 ${cols}`}>
      {products.map((product, index) => (
        <Reveal
          key={product.slug}
          delay={Math.min(index, 7) * 60}
          className="flex"
        >
          <div className="w-full">
            <ProductCard
              product={product}
              index={index}
              priority={index < priorityCount}
            />
          </div>
        </Reveal>
      ))}
    </div>
  );
}
