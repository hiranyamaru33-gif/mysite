"use client";

import { useEffect, useMemo, useState } from "react";
import { useCart } from "@/components/CartProvider";
import { formatPrice } from "@/lib/format";

type Props = {
  slug: string;
  name: string;
  price: number;
  colorway: string;
  image: string;
  sizes: string[];
  stock: number;
};

const LOW_STOCK_NOTE = 12;

export default function ProductPurchase({
  slug,
  name,
  price,
  colorway,
  image,
  sizes,
  stock,
}: Props) {
  const { addItem, openCart } = useCart();
  const selectable = sizes.filter((size) => size !== "One Size");
  // The parent keys this component by product slug, so state resets on change.
  const [size, setSize] = useState<string>(
    selectable.length ? selectable[Math.min(2, selectable.length - 1)] : "One Size",
  );
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState(false);
  const [pincode, setPincode] = useState("");
  const [pincodeResult, setPincodeResult] = useState<string | null>(null);

  const deliveryEstimate = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() + 4);
    const end = new Date();
    end.setDate(end.getDate() + 7);
    const fmt = (value: Date) =>
      value.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
    return `${fmt(date)} – ${fmt(end)}`;
  }, []);

  const handleAdd = () => {
    if (selectable.length && !size) {
      setError(true);
      return;
    }
    setError(false);
    addItem(
      { slug, name, colorway, image, price, size },
      quantity,
    );
  };

  const checkPincode = () => {
    if (!/^\d{4,6}$/.test(pincode)) {
      setPincodeResult("Enter a valid 4–6 digit postcode.");
      return;
    }
    setPincodeResult(
      `Express delivery available to ${pincode} — arrives in 2 days.`,
    );
  };

  return (
    <div className="space-y-7">
      {/* Size */}
      <div>
        <div className="flex items-baseline justify-between">
          <p className="field-label">
            {selectable.length ? "Size" : "Fit"}{" "}
            <span className="ml-1 text-bone/70 normal-case">{size}</span>
          </p>
          <button
            type="button"
            onClick={() =>
              document
                .getElementById("size-guide")
                ?.scrollIntoView({ behavior: "smooth", block: "center" })
            }
            className="link-sweep text-[0.68rem] tracking-[0.14em] text-bone/50 uppercase"
          >
            Size guide
          </button>
        </div>

        {selectable.length ? (
          <div className="mt-3 flex flex-wrap gap-2">
            {selectable.map((option) => {
              const checked = option === size;
              return (
                <button
                  key={option}
                  type="button"
                  onClick={() => {
                    setSize(option);
                    setError(false);
                  }}
                  aria-pressed={checked}
                  className={`h-12 min-w-14 rounded-full border px-4 text-[0.8rem] font-semibold tracking-[0.06em] transition-all duration-300 ${
                    checked
                      ? "border-acid bg-acid text-void"
                      : "border-white/18 text-bone/70 hover:border-bone/60 hover:text-bone"
                  }`}
                >
                  {option}
                </button>
              );
            })}
          </div>
        ) : (
          <p className="mt-3 text-sm text-bone/60">
            One size — adjustable, fits 54–60cm.
          </p>
        )}

        {error ? (
          <p className="mt-2 text-xs text-flare">Please choose a size.</p>
        ) : null}
      </div>

      {/* Quantity + add */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="inline-flex h-14 shrink-0 items-center rounded-full border border-white/18 px-2">
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            aria-label="Decrease quantity"
            className="grid h-10 w-10 place-items-center rounded-full text-lg text-bone/60 transition-colors hover:text-acid"
          >
            −
          </button>
          <span className="w-8 text-center text-sm font-semibold tabular-nums">
            {quantity}
          </span>
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.min(stock, value + 1))}
            aria-label="Increase quantity"
            className="grid h-10 w-10 place-items-center rounded-full text-lg text-bone/60 transition-colors hover:text-acid"
          >
            +
          </button>
        </div>

        <button
          type="button"
          onClick={handleAdd}
          className="btn btn-acid h-14 flex-1 !text-[0.78rem]"
        >
          Add to cart · {formatPrice(price * quantity)}
        </button>
      </div>

      <button
        type="button"
        onClick={() => {
          handleAdd();
          openCart();
        }}
        className="btn btn-ghost w-full"
      >
        Buy it now
      </button>

      {/* Reassurance */}
      <dl className="grid gap-4 border-y border-white/10 py-6 text-sm sm:grid-cols-2">
        <div>
          <dt className="field-label">Delivery</dt>
          <dd className="mt-1.5 text-bone/70">
            Arrives {deliveryEstimate}
            <br />
            <span className="text-bone/40">
              Free over $250 · 30-day returns
            </span>
          </dd>
        </div>
        <div>
          <dt className="field-label">Stock</dt>
          <dd className="mt-1.5 text-bone/70">
            {stock > 0 ? (
              stock <= LOW_STOCK_NOTE ? (
                <span className="text-flare">
                  Only {stock} left in this colourway
                </span>
              ) : (
                <>In stock — ships within 24h</>
              )
            ) : (
              <>Sold out</>
            )}
          </dd>
        </div>
      </dl>

      {/* Postcode */}
      <div>
        <label htmlFor="pincode" className="field-label block">
          Check delivery
        </label>
        <div className="mt-2 flex gap-3">
          <input
            id="pincode"
            value={pincode}
            onChange={(event) => setPincode(event.target.value)}
            inputMode="numeric"
            placeholder="Postcode"
            className="field flex-1"
          />
          <button type="button" onClick={checkPincode} className="btn btn-ghost">
            Check
          </button>
        </div>
        {pincodeResult ? (
          <p className="mt-2 text-xs text-acid animate-[fade_0.4s_ease_both]">
            {pincodeResult}
          </p>
        ) : null}
      </div>

      <ul className="space-y-2.5 text-sm text-bone/55">
        {[
          "Free repairs for the life of the garment",
          "Carbon-neutral tracked shipping worldwide",
          "Plastic-free packaging, always",
        ].map((item) => (
          <li key={item} className="flex items-start gap-2.5">
            <svg
              className="mt-1 shrink-0 text-acid"
              width="12"
              height="12"
              viewBox="0 0 12 12"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M1.5 6.5 4.5 9.5 10.5 2.5"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
