"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useRef } from "react";
import { computeTotals, lineKey, useCart } from "@/components/CartProvider";
import { formatPrice, formatPriceExact } from "@/lib/format";
import { FREE_SHIPPING_THRESHOLD } from "@/lib/types";

const EMPTY_SUGGESTIONS = [
  { href: "/shop?category=hoodies", label: "Hoodies & Fleece" },
  { href: "/shop?category=outerwear", label: "Outerwear" },
  { href: "/shop?category=accessories", label: "Accessories" },
];

export default function CartDrawer() {
  const {
    lines,
    isOpen,
    closeCart,
    removeItem,
    setQuantity,
    subtotal,
    count,
  } = useCart();

  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  const totals = useMemo(() => computeTotals(subtotal, 0), [subtotal]);

  useEffect(() => {
    if (!isOpen) return;
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeCart();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, closeCart]);

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <div
      className={`fixed inset-0 z-[70] ${isOpen ? "" : "pointer-events-none"}`}
      aria-hidden={!isOpen}
    >
      <div
        onClick={closeCart}
        className={`absolute inset-0 bg-void/70 backdrop-blur-[3px] transition-opacity duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          isOpen ? "opacity-100" : "opacity-0"
        }`}
      />

      <div
        ref={panelRef}
        role="dialog"
        aria-modal={isOpen}
        aria-label="Shopping cart"
        className={`absolute inset-y-0 right-0 flex w-full max-w-[27rem] flex-col border-l border-white/10 bg-void-soft transition-transform duration-[600ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between border-b border-white/10 px-6 py-5">
          <div>
            <h2 className="text-lg font-bold tracking-[-0.02em]">
              Your cart
              <span className="ml-2 text-sm font-medium text-bone/40 tabular-nums">
                ({count})
              </span>
            </h2>
            <p className="mt-1 text-[0.7rem] tracking-[0.14em] text-bone/35 uppercase">
              {remaining > 0
                ? `${formatPrice(remaining)} from free shipping`
                : "Free shipping unlocked"}
            </p>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={closeCart}
            aria-label="Close cart"
            className="grid h-9 w-9 place-items-center rounded-full border border-white/15 text-bone/70 transition-colors duration-300 hover:border-bone/60 hover:text-bone"
          >
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
              <path
                d="M1 1l12 12M13 1L1 13"
                stroke="currentColor"
                strokeWidth="1.6"
              />
            </svg>
          </button>
        </header>

        <div className="h-[2px] w-full bg-white/10">
          <div
            className="h-full bg-acid transition-[width] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="flex-1 overflow-y-auto overscroll-contain px-6">
          {lines.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center py-16 text-center">
              <div className="grid h-16 w-16 place-items-center rounded-full border border-white/10">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M6 8h12l-1 12H7L6 8Z"
                    stroke="currentColor"
                    strokeWidth="1.4"
                  />
                  <path
                    d="M9 8V6a3 3 0 0 1 6 0v2"
                    stroke="currentColor"
                    strokeWidth="1.4"
                  />
                </svg>
              </div>
              <p className="mt-5 text-base font-semibold">Nothing in here yet</p>
              <p className="mt-2 max-w-[16rem] text-sm text-bone/45">
                Start with the pieces we cannot keep in stock.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {EMPTY_SUGGESTIONS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={closeCart}
                    className="rounded-full border border-white/15 px-4 py-2 text-[0.7rem] font-medium tracking-[0.14em] uppercase transition-colors hover:border-acid hover:text-acid"
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <ul className="divide-y divide-white/8">
              {lines.map((line) => (
                <li
                  key={lineKey(line)}
                  className="flex gap-4 py-5 first:pt-5 animate-[rise_0.5s_var(--ease-out-expo)_both]"
                >
                  <Link
                    href={`/product/${line.slug}`}
                    onClick={closeCart}
                    className="relative h-24 w-20 shrink-0 overflow-hidden bg-void"
                  >
                    {line.image ? (
                      <Image
                        src={line.image}
                        alt={line.name}
                        fill
                        sizes="80px"
                        className="object-cover"
                      />
                    ) : null}
                  </Link>

                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <Link
                        href={`/product/${line.slug}`}
                        onClick={closeCart}
                        className="truncate text-sm font-semibold hover:text-acid"
                      >
                        {line.name}
                      </Link>
                      <span className="shrink-0 text-sm font-semibold tabular-nums">
                        {formatPrice(line.price * line.quantity)}
                      </span>
                    </div>

                    <p className="mt-1 text-xs text-bone/40">
                      {line.colorway} · Size {line.size}
                    </p>

                    <div className="mt-auto flex items-center justify-between pt-3">
                      <div className="inline-flex items-center rounded-full border border-white/15">
                        <button
                          type="button"
                          onClick={() =>
                            setQuantity(lineKey(line), line.quantity - 1)
                          }
                          aria-label={`Decrease quantity of ${line.name}`}
                          className="grid h-7 w-7 place-items-center rounded-full text-bone/60 transition-colors hover:text-acid"
                        >
                          −
                        </button>
                        <span className="w-7 text-center text-xs font-semibold tabular-nums">
                          {line.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setQuantity(lineKey(line), line.quantity + 1)
                          }
                          aria-label={`Increase quantity of ${line.name}`}
                          className="grid h-7 w-7 place-items-center rounded-full text-bone/60 transition-colors hover:text-acid"
                        >
                          +
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeItem(lineKey(line))}
                        className="text-[0.68rem] tracking-[0.14em] text-bone/35 uppercase transition-colors hover:text-flare"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 ? (
          <footer className="border-t border-white/10 bg-void px-6 py-5">
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-bone/50">Subtotal</dt>
                <dd className="font-semibold tabular-nums">
                  {formatPriceExact(subtotal)}
                </dd>
              </div>
              <div className="flex justify-between text-bone/50">
                <dt>Est. tax</dt>
                <dd className="tabular-nums">{formatPriceExact(totals.tax)}</dd>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-3 text-base">
                <dt className="font-semibold">Total</dt>
                <dd className="font-semibold tabular-nums">
                  {formatPriceExact(totals.total)}
                </dd>
              </div>
            </dl>

            <Link
              href="/checkout"
              onClick={closeCart}
              className="btn btn-acid mt-5 w-full"
            >
              Checkout · {formatPriceExact(totals.total)}
            </Link>
            <button
              type="button"
              onClick={closeCart}
              className="mt-3 w-full text-center text-[0.7rem] tracking-[0.16em] text-bone/40 uppercase transition-colors hover:text-bone"
            >
              Continue shopping
            </button>
          </footer>
        ) : null}
      </div>
    </div>
  );
}
