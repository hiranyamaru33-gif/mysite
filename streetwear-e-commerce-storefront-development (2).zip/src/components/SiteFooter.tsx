import Link from "next/link";
import Wordmark from "@/components/Wordmark";
import NewsletterForm from "@/components/NewsletterForm";

const COLUMNS = [
  {
    title: "Shop",
    links: [
      { label: "All products", href: "/shop" },
      { label: "Hoodies & Fleece", href: "/shop?category=hoodies" },
      { label: "Outerwear", href: "/shop?category=outerwear" },
      { label: "Footwear", href: "/shop?category=footwear" },
      { label: "Accessories", href: "/shop?category=accessories" },
    ],
  },
  {
    title: "Collections",
    links: [
      { label: "Void Core", href: "/shop?collection=void-core" },
      { label: "Night Shift", href: "/shop?collection=night-shift" },
      { label: "Off-Grid", href: "/shop?collection=off-grid" },
      { label: "Archive", href: "/shop?collection=archive" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Shipping & delivery", href: "/support#shipping" },
      { label: "Returns & exchanges", href: "/support#returns" },
      { label: "Size guide", href: "/support#sizing" },
      { label: "Care instructions", href: "/support#care" },
      { label: "Contact", href: "/support#contact" },
    ],
  },
];

export default function SiteFooter() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-void-soft">
      <div className="mx-auto max-w-[1500px] px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <Wordmark size={30} />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-bone/55">
              Heavyweight streetwear built in small runs. Designed in Rotterdam,
              cut in Portugal, made to be worn until it falls apart — then
              repaired.
            </p>

            <NewsletterForm id="footer-email" />
          </div>

          <div className="grid gap-10 sm:grid-cols-3">
            {COLUMNS.map((column) => (
              <div key={column.title}>
                <h3 className="eyebrow text-bone/40">{column.title}</h3>
                <ul className="mt-5 space-y-3">
                  {column.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="link-sweep text-sm text-bone/70 transition-colors hover:text-bone"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-xs text-bone/40 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} voidzone. All rights reserved.</p>
          <div className="flex flex-wrap gap-6">
            <span>Privacy</span>
            <span>Terms</span>
            <span>Accessibility</span>
            <span className="text-bone/25">
              Demo storefront — no real orders are placed.
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
