import Image from "next/image";
import Link from "next/link";
import Reveal from "@/components/Reveal";

export default function Hero({
  image,
  alt,
  stats,
}: {
  image: string;
  alt: string;
  stats: { value: string; label: string }[];
}) {
  return (
    <section className="relative isolate overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src={image}
          alt={alt}
          fill
          priority
          sizes="100vw"
          className="animate-drift object-cover object-[58%_38%] opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-void/85 via-void/55 to-void" />
        <div className="absolute inset-0 bg-gradient-to-r from-void via-void/45 to-transparent" />
        <div className="grain-after absolute inset-0 opacity-[0.16]" />
      </div>

      <div className="relative mx-auto flex min-h-[100svh] max-w-[1500px] flex-col justify-end px-5 pt-32 pb-14 sm:px-8 sm:pb-20">
        <Reveal>
          <p className="eyebrow flex items-center gap-3 text-acid">
            <span className="inline-block h-[1px] w-10 bg-acid" />
            Autumn / Winter 26 — Drop 04
          </p>
        </Reveal>

        <Reveal delay={90}>
          <h1 className="mt-6 max-w-[15ch] text-[clamp(3.4rem,11vw,10.5rem)] leading-[0.84] font-extrabold tracking-[-0.055em]">
            BUILT FOR
            <br />
            <span className="text-bone/35">THE</span>{" "}
            <span className="relative inline-block">
              VOID
              <svg
                className="absolute -bottom-1 left-0 w-full text-acid"
                height="12"
                viewBox="0 0 200 12"
                preserveAspectRatio="none"
                aria-hidden="true"
              >
                <path
                  d="M2 8c40-6 90-6 196-2"
                  stroke="currentColor"
                  strokeWidth="3"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </h1>
        </Reveal>

        <div className="mt-10 grid gap-10 lg:grid-cols-[1.1fr_auto] lg:items-end">
          <Reveal delay={180}>
            <p className="max-w-md text-[0.98rem] leading-relaxed text-bone/65">
              Heavyweight streetwear made in small runs — 500gsm fleece, taped
              membrane shells and overdyed denim. Nothing restocked forever,
              nothing designed to be thrown away.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/shop" className="btn btn-acid">
                Shop the collection
              </Link>
              <Link href="/#collections" className="btn btn-ghost">
                Explore collections
              </Link>
            </div>
          </Reveal>

          <Reveal delay={260}>
            <dl className="flex gap-8 border-t border-white/15 pt-6 lg:border-t-0 lg:border-l lg:pt-0 lg:pl-10">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <dt className="text-[0.65rem] tracking-[0.18em] text-bone/40 uppercase">
                    {stat.label}
                  </dt>
                  <dd className="mt-1.5 font-[family-name:var(--font-display)] text-2xl font-bold tracking-[-0.03em] tabular-nums">
                    {stat.value}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </div>

      <div className="relative mx-auto flex max-w-[1500px] items-center gap-3 px-5 pb-8 sm:px-8">
        <span className="text-[0.6rem] tracking-[0.24em] text-bone/35 uppercase">
          Scroll
        </span>
        <span className="relative h-[1px] w-16 overflow-hidden bg-white/15">
          <span className="absolute inset-y-0 left-0 w-6 animate-marquee bg-acid" />
        </span>
      </div>
    </section>
  );
}
