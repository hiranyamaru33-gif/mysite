export default function Wordmark({
  className = "",
  size = 20,
}: {
  className?: string;
  size?: number;
}) {
  return (
    <span
      className={`inline-flex items-baseline font-[family-name:var(--font-display)] font-extrabold uppercase leading-none tracking-[-0.055em] ${className}`}
      style={{ fontSize: size }}
    >
      <span>void</span>
      <span className="text-acid">zone</span>
      <span
        aria-hidden="true"
        className="ml-[0.12em] inline-block h-[0.62em] w-[0.16em] translate-y-[-0.04em] bg-acid"
      />
    </span>
  );
}
