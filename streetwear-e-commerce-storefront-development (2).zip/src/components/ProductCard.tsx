"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/components/CartProvider";
import Stars from "@/components/Stars";
import { discountPercent, formatPrice } from "@/lib/format";
import type { ProductSummary } from "@/lib/types";

export default function ProductCard({
  product,
  index = 0,
  priority = false,
}: {
  product: ProductSummary;
  index?: number;
  priority?: boolean;
}) {
  const { addItem } = useCart();
  const [active, setActive] = useState(0);
  const [justAdded, setJustAdded] = useState(false);

  const images = product.images.length
    ? product.images
    : [{ url: "", alt: product.name }];
  const off = discountPercent(product.price, product.compareAtPrice);
  const lowStock = product.stock > 0 && product.stock <= 20;

  const quickAdd = () => {
    const size = product.sizes[Math.min(1, product.sizes.length - 1)] ?? "One Size";
    addItem({
      slug: product.slug,
      name: product.name,
      colorway: product.colorway,
      image: images[0]?.url ?? "",
      price: product.price,
      size,
    });
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1800);
  };

  return (
    <article className="group relative flex flex-col">
      <Link
        href={`/product/${product.slug}`}
        className="relative block overflow-hidden bg-void-soft"
        onMouseEnter={() => images[1] && setActive(1)}
        onMouseLeave={() => setActive(0)}
        onFocus={() => images[1] && setActive(1)}
        onBlur={() => setActive(0)}
      >
        <div className="relative aspect-[4/5] w-full">
          {images.map((image, imageIndex) => (
            <Image
              key={image.url + imageIndex}
              src={image.url}
              alt={image.alt}
              fill
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              priority={priority && imageIndex === 0}
              className={`object-cover transition-[opacity,transform] duration-[1100ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
                imageIndex === active
                  ? "scale-100 opacity-100"
                  : "scale-[1.06] opacity-0"
              } group-hover:scale-[1.04]`}
            />
          ))}

          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/70 via-transparent to-transparent opacity-70 transition-opacity duration-700 group-hover:opacity-40" />
        </div>

        <div className="absolute top-3 left-3 flex flex-col items-start gap-1.5">
          {product.badges.slice(0, 2).map((badge) => (
            <span
              key={badge}
              className="rounded-full bg-void/70 px-2.5 py-1 text-[0.6rem] font-semibold tracking-[0.16em] text-bone uppercase backdrop-blur-md"
            >
              {badge}
            </span>
          ))}
          {off ? (
            <span className="rounded-full bg-flare px-2.5 py-1 text-[0.6rem] font-bold tracking-[0.16em] text-void uppercase">
              −{off}%
            </span>
          ) : null}
        </div>

        {images.length > 1 ? (
          <div className="absolute bottom-3 left-3 flex gap-1.5">
            {images.slice(0, 4).map((image, dotIndex) => (
              <span
                key={image.url + dotIndex}
                className={`h-[3px] rounded-full transition-all duration-500 ${
                  dotIndex === active ? "w-6 bg-acid" : "w-2 bg-white/40"
                }`}
              />
            ))}
          </div>
        ) : null}
      </Link>

      <div className="flex flex-1 flex-col pt-4">
        <div className="flex items-start justify-between gap-4">
          <h3 className="text-[0.95rem] leading-tight font-semibold tracking-[-0.01em]">
            <Link
              href={`/product/${product.slug}`}
              className="transition-colors duration-300 hover:text-acid"
            >
              {product.name}
            </Link>
          </h3>
          <div className="shrink-0 text-right">
            <p className="text-[0.95rem] font-semibold tabular-nums">
              {formatPrice(product.price)}
            </p>
            {product.compareAtPrice ? (
              <p className="text-xs text-bone/35 line-through tabular-nums">
                {formatPrice(product.compareAtPrice)}
              </p>
            ) : null}
          </div>
        </div>

        <p className="mt-1.5 line-clamp-1 text-xs text-bone/45">
          {product.subtitle}
        </p>

        <div className="mt-2.5 flex items-center gap-2">
          <Stars rating={product.rating} size={12} />
          <span className="text-[0.7rem] text-bone/40 tabular-nums">
            {product.rating > 0 ? product.rating.toFixed(1) : "New"} (
            {product.reviewCount})
          </span>
        </div>

        <div className="mt-4 flex items-center gap-3">
          <span className="flex items-center gap-2 text-[0.7rem] text-bone/40">
            <span
              className="h-3 w-3 rounded-full ring-1 ring-white/20 ring-inset"
              style={{ backgroundColor: product.colorHex }}
            />
            {product.colorway}
          </span>
          {lowStock ? (
            <span className="text-[0.7rem] font-medium text-flare">
              {product.stock} left
            </span>
          ) : null}
        </div>

        <button
          type="button"
          onClick={quickAdd}
          data-index={index}
          className={`btn mt-4 w-full transition-all duration-500 ${
            justAdded
              ? "btn-acid"
              : "border border-white/15 text-bone/80 hover:border-bone hover:bg-bone hover:text-void"
          }`}
        >
          {justAdded ? "Added ✓" : "Quick add"}
        </button>
      </div>
    </article>
  );
}
