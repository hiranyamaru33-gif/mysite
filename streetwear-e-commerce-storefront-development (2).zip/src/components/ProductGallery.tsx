"use client";

import Image from "next/image";
import { useEffect, useState } from "react";

export default function ProductGallery({
  images,
  name,
}: {
  images: { url: string; alt: string }[];
  name: string;
}) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState(false);
  const [origin, setOrigin] = useState("50% 50%");

  useEffect(() => {
    if (!zoom) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setZoom(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [zoom]);

  const current = images[active] ?? images[0];

  return (
    <>
      <div className="flex flex-col-reverse gap-4 lg:flex-row lg:gap-5">
        {/* Thumbnails */}
        <div
          className="flex shrink-0 gap-3 overflow-x-auto lg:w-20 lg:flex-col lg:overflow-visible"
          role="tablist"
          aria-label={`${name} images`}
        >
          {images.map((image, index) => (
            <button
              key={image.url + index}
              type="button"
              role="tab"
              aria-selected={index === active}
              aria-label={`View image ${index + 1}`}
              onClick={() => setActive(index)}
              className={`relative h-20 w-16 shrink-0 overflow-hidden border transition-colors duration-300 lg:h-24 lg:w-full ${
                index === active
                  ? "border-acid"
                  : "border-white/12 opacity-55 hover:opacity-100"
              }`}
            >
              <Image
                src={image.url}
                alt=""
                fill
                sizes="80px"
                className="object-cover"
              />
            </button>
          ))}
        </div>

        {/* Main image */}
        <div className="relative min-w-0 flex-1">
          <button
            type="button"
            onClick={() => setZoom(true)}
            onMouseMove={(event) => {
              const rect = event.currentTarget.getBoundingClientRect();
              const x = ((event.clientX - rect.left) / rect.width) * 100;
              const y = ((event.clientY - rect.top) / rect.height) * 100;
              setOrigin(`${x}% ${y}%`);
            }}
            aria-label={`Zoom into ${name}`}
            className="group relative block aspect-[4/5] w-full cursor-zoom-in overflow-hidden bg-void-soft"
          >
            {images.map((image, index) => (
              <Image
                key={image.url + index}
                src={image.url}
                alt={index === active ? image.alt : ""}
                fill
                priority={index === 0}
                sizes="(max-width: 1024px) 100vw, 55vw"
                className={`object-cover transition-[opacity,transform] duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
                  index === active
                    ? "scale-100 opacity-100 group-hover:scale-[1.05]"
                    : "scale-[1.04] opacity-0"
                }`}
                style={{ transformOrigin: origin }}
              />
            ))}

            <span className="pointer-events-none absolute right-4 bottom-4 inline-flex items-center gap-2 rounded-full bg-void/70 px-3 py-1.5 text-[0.62rem] tracking-[0.18em] text-bone/80 uppercase opacity-0 backdrop-blur-md transition-opacity duration-500 group-hover:opacity-100">
              Click to zoom
            </span>

            <span className="pointer-events-none absolute bottom-4 left-4 text-[0.65rem] tracking-[0.16em] text-bone/45 uppercase tabular-nums">
              {String(active + 1).padStart(2, "0")} /{" "}
              {String(images.length).padStart(2, "0")}
            </span>
          </button>

          {/* Mobile swipe strip */}
          <div className="mt-4 flex gap-2 lg:hidden">
            {images.map((image, index) => (
              <span
                key={image.url + index}
                className={`h-[3px] flex-1 rounded-full transition-colors duration-400 ${
                  index === active ? "bg-acid" : "bg-white/15"
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {zoom && current ? (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-void/95 p-4 backdrop-blur-md"
          onClick={() => setZoom(false)}
          role="dialog"
          aria-modal="true"
          aria-label={`${name} — full image`}
        >
          <button
            type="button"
            onClick={() => setZoom(false)}
            aria-label="Close zoom"
            className="absolute top-5 right-5 grid h-11 w-11 place-items-center rounded-full border border-white/20 text-bone/70 transition-colors hover:border-bone hover:text-bone"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path
                d="M1 1l12 12M13 1L1 13"
                stroke="currentColor"
                strokeWidth="1.6"
              />
            </svg>
          </button>

          <div className="relative aspect-[4/5] max-h-[88vh] w-full max-w-3xl">
            <Image
              src={current.url}
              alt={current.alt}
              fill
              sizes="90vw"
              className="object-contain"
            />
          </div>
        </div>
      ) : null}
    </>
  );
}
