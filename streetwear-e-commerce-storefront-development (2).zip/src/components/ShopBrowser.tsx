"use client";

import { useCallback, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import ProductGrid from "@/components/ProductGrid";
import { CATEGORY_LABELS } from "@/lib/catalog";
import { formatPrice } from "@/lib/format";
import { SORT_LABELS, type ProductSummary, type SortKey } from "@/lib/types";

const ALL_SIZES = ["XS", "S", "M", "L", "XL", "XXL"];

type Props = {
  products: ProductSummary[];
  collections: { slug: string; name: string; count: number }[];
  categoryCounts: { category: string; total: number }[];
  minPrice: number;
  maxPrice: number;
};

export default function ShopBrowser({
  products,
  collections,
  categoryCounts,
  minPrice,
  maxPrice,
}: Props) {
  const router = useRouter();
  const params = useSearchParams();
  const [filtersOpen, setFiltersOpen] = useState(false);

  /* The URL is the single source of truth for every filter. */
  const categories = params.getAll("category");
  const selectedCollections = params.getAll("collection");
  const sizes = params.getAll("size");
  const onSale = params.get("sale") === "1";
  const inStock = params.get("stock") === "1";
  const max = Number(params.get("max") ?? maxPrice) || maxPrice;
  const sortParam = params.get("sort") ?? "featured";
  const sort: SortKey = sortParam in SORT_LABELS ? (sortParam as SortKey) : "featured";

  const write = useCallback(
    (mutate: (next: URLSearchParams) => void) => {
      const next = new URLSearchParams(params.toString());
      mutate(next);
      const query = next.toString();
      router.replace(query ? `/shop?${query}` : "/shop", { scroll: false });
    },
    [params, router],
  );

  const toggleValue = useCallback(
    (key: string, value: string) => {
      write((next) => {
        const existing = next.getAll(key);
        next.delete(key);
        const result = existing.includes(value)
          ? existing.filter((entry) => entry !== value)
          : [...existing, value];
        result.forEach((entry) => next.append(key, entry));
      });
    },
    [write],
  );

  const setFlag = useCallback(
    (key: string, value: boolean) => {
      write((next) => {
        if (value) next.set(key, "1");
        else next.delete(key);
      });
    },
    [write],
  );

  const setMax = useCallback(
    (value: number) => {
      write((next) => {
        if (value < maxPrice) next.set("max", String(value));
        else next.delete("max");
      });
    },
    [write, maxPrice],
  );

  const setSort = useCallback(
    (value: SortKey) => {
      write((next) => {
        if (value === "featured") next.delete("sort");
        else next.set("sort", value);
      });
    },
    [write],
  );

  const resetAll = useCallback(() => {
    router.replace("/shop", { scroll: false });
  }, [router]);

  const visible = useMemo(() => {
    const filtered = products.filter((product) => {
      if (categories.length && !categories.includes(product.category))
        return false;
      if (
        selectedCollections.length &&
        (!product.collection || !selectedCollections.includes(product.collection))
      )
        return false;
      if (sizes.length && !product.sizes.some((size) => sizes.includes(size)))
        return false;
      if (onSale && !product.compareAtPrice) return false;
      if (inStock && product.stock <= 0) return false;
      if (product.price > max) return false;
      return true;
    });

    switch (sort) {
      case "price-asc":
        return filtered.sort((a, b) => a.price - b.price);
      case "price-desc":
        return filtered.sort((a, b) => b.price - a.price);
      case "rating":
        return filtered.sort((a, b) => b.rating - a.rating);
      case "popular":
        return filtered.sort(
          (a, b) => b.reviewCount * b.rating - a.reviewCount * a.rating,
        );
      case "newest":
        return filtered.sort((a, b) => b.id - a.id);
      default:
        return filtered.sort(
          (a, b) => Number(b.featured) - Number(a.featured) || b.id - a.id,
        );
    }
  }, [
    products,
    categories,
    selectedCollections,
    sizes,
    onSale,
    inStock,
    max,
    sort,
  ]);

  const activeCount =
    categories.length +
    selectedCollections.length +
    sizes.length +
    (onSale ? 1 : 0) +
    (inStock ? 1 : 0) +
    (max < maxPrice ? 1 : 0);

  const FilterPanel = (
    <div className="space-y-9">
      <FilterGroup title="Category">
        {categoryCounts.map((entry) => (
          <CheckRow
            key={entry.category}
            label={CATEGORY_LABELS[entry.category] ?? entry.category}
            count={entry.total}
            checked={categories.includes(entry.category)}
            onChange={() => toggleValue("category", entry.category)}
          />
        ))}
      </FilterGroup>

      <FilterGroup title="Collection">
        {collections.map((entry) => (
          <CheckRow
            key={entry.slug}
            label={entry.name}
            count={entry.count}
            checked={selectedCollections.includes(entry.slug)}
            onChange={() => toggleValue("collection", entry.slug)}
          />
        ))}
      </FilterGroup>

      <FilterGroup title="Size">
        <div className="flex flex-wrap gap-2">
          {ALL_SIZES.map((size) => {
            const checked = sizes.includes(size);
            return (
              <button
                key={size}
                type="button"
                onClick={() => toggleValue("size", size)}
                aria-pressed={checked}
                className={`h-9 min-w-11 rounded-full border px-3 text-[0.72rem] font-semibold tracking-[0.08em] transition-colors duration-300 ${
                  checked
                    ? "border-acid bg-acid text-void"
                    : "border-white/15 text-bone/65 hover:border-bone/50 hover:text-bone"
                }`}
              >
                {size}
              </button>
            );
          })}
        </div>
      </FilterGroup>

      <FilterGroup title={`Max price · ${formatPrice(max)}`}>
        <input
          type="range"
          min={minPrice}
          max={maxPrice}
          step={1000}
          value={max}
          onChange={(event) => setMax(Number(event.target.value))}
          aria-label="Maximum price"
          className="h-1 w-full cursor-pointer appearance-none rounded-full bg-white/15 accent-[var(--color-acid)]"
        />
        <div className="mt-2 flex justify-between text-[0.7rem] text-bone/35 tabular-nums">
          <span>{formatPrice(minPrice)}</span>
          <span>{formatPrice(maxPrice)}</span>
        </div>
      </FilterGroup>

      <FilterGroup title="Availability">
        <label className="flex cursor-pointer items-center justify-between gap-3 py-1">
          <span className="text-sm text-bone/70">On sale only</span>
          <Switch checked={onSale} onChange={(value) => setFlag("sale", value)} />
        </label>
        <label className="flex cursor-pointer items-center justify-between gap-3 py-1">
          <span className="text-sm text-bone/70">In stock only</span>
          <Switch
            checked={inStock}
            onChange={(value) => setFlag("stock", value)}
          />
        </label>
      </FilterGroup>

      {activeCount > 0 ? (
        <button
          type="button"
          onClick={resetAll}
          className="text-[0.7rem] tracking-[0.16em] text-bone/45 uppercase transition-colors hover:text-acid"
        >
          Clear all filters ({activeCount})
        </button>
      ) : null}
    </div>
  );

  return (
    <div className="mx-auto grid max-w-[1500px] gap-10 px-5 pb-4 sm:px-8 lg:grid-cols-[16rem_1fr] lg:gap-14">
      {/* Desktop filters */}
      <aside className="hidden lg:block">
        <div className="sticky top-28 max-h-[calc(100vh-9rem)] overflow-y-auto pr-2 pb-6">
          <h2 className="eyebrow mb-7 text-bone/40">Filters</h2>
          {FilterPanel}
        </div>
      </aside>

      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setFiltersOpen(true)}
              className="btn btn-ghost !px-4 !py-2.5 lg:hidden"
            >
              Filters
              {activeCount > 0 ? (
                <span className="grid h-5 min-w-5 place-items-center rounded-full bg-acid px-1 text-[0.65rem] font-bold text-void tabular-nums">
                  {activeCount}
                </span>
              ) : null}
            </button>

            <p className="text-sm text-bone/50">
              <span className="font-semibold text-bone tabular-nums">
                {visible.length}
              </span>{" "}
              {visible.length === 1 ? "piece" : "pieces"}
            </p>
          </div>

          <label className="flex items-center gap-3">
            <span className="hidden text-[0.7rem] tracking-[0.16em] text-bone/40 uppercase sm:inline">
              Sort
            </span>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as SortKey)}
              aria-label="Sort products"
              className="rounded-full border border-white/15 bg-void px-4 py-2.5 text-[0.75rem] font-medium tracking-[0.06em] text-bone outline-none transition-colors hover:border-bone/50 focus-visible:border-acid"
            >
              {Object.entries(SORT_LABELS).map(([value, label]) => (
                <option key={value} value={value} className="bg-void">
                  {label}
                </option>
              ))}
            </select>
          </label>
        </div>

        {activeCount > 0 ? (
          <div className="flex flex-wrap items-center gap-2 pt-5">
            {categories.map((value) => (
              <Chip
                key={value}
                label={CATEGORY_LABELS[value] ?? value}
                onClear={() => toggleValue("category", value)}
              />
            ))}
            {selectedCollections.map((value) => (
              <Chip
                key={value}
                label={
                  collections.find((collection) => collection.slug === value)
                    ?.name ?? value
                }
                onClear={() => toggleValue("collection", value)}
              />
            ))}
            {sizes.map((value) => (
              <Chip
                key={value}
                label={`Size ${value}`}
                onClear={() => toggleValue("size", value)}
              />
            ))}
            {onSale ? (
              <Chip label="On sale" onClear={() => setFlag("sale", false)} />
            ) : null}
            {inStock ? (
              <Chip label="In stock" onClear={() => setFlag("stock", false)} />
            ) : null}
            {max < maxPrice ? (
              <Chip
                label={`Under ${formatPrice(max)}`}
                onClear={() => setMax(maxPrice)}
              />
            ) : null}
            <button
              type="button"
              onClick={resetAll}
              className="ml-1 text-[0.7rem] tracking-[0.14em] text-bone/40 uppercase transition-colors hover:text-flare"
            >
              Clear
            </button>
          </div>
        ) : null}

        <div className="pt-10">
          <ProductGrid
            products={visible}
            emptyMessage="Nothing matches those filters yet — try widening the price or clearing a size."
          />
        </div>
      </div>

      {/* Mobile filters */}
      <div
        className={`fixed inset-0 z-[65] lg:hidden ${
          filtersOpen ? "" : "pointer-events-none"
        }`}
        aria-hidden={!filtersOpen}
      >
        <div
          onClick={() => setFiltersOpen(false)}
          className={`absolute inset-0 bg-void/75 backdrop-blur-sm transition-opacity duration-400 ${
            filtersOpen ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          className={`absolute inset-x-0 bottom-0 max-h-[86vh] overflow-y-auto rounded-t-3xl border-t border-white/12 bg-void-soft px-6 pt-4 pb-8 transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
            filtersOpen ? "translate-y-0" : "translate-y-full"
          }`}
        >
          <div className="mx-auto mb-5 h-1 w-10 rounded-full bg-white/20" />
          <div className="flex items-center justify-between pb-4">
            <h2 className="text-lg font-bold tracking-[-0.02em]">Filters</h2>
            <button
              type="button"
              onClick={() => setFiltersOpen(false)}
              className="text-[0.7rem] tracking-[0.16em] text-acid uppercase"
            >
              Show {visible.length} results
            </button>
          </div>
          {FilterPanel}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- atoms ------------------------------- */

function FilterGroup({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h3 className="mb-3.5 text-[0.68rem] font-semibold tracking-[0.18em] text-bone/45 uppercase">
        {title}
      </h3>
      {children}
    </div>
  );
}

function CheckRow({
  label,
  count,
  checked,
  onChange,
}: {
  label: string;
  count: number;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <label className="group flex cursor-pointer items-center gap-3 py-1.5">
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="peer sr-only"
      />
      <span
        className={`grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border transition-colors duration-300 ${
          checked
            ? "border-acid bg-acid text-void"
            : "border-white/25 text-transparent group-hover:border-bone/60"
        }`}
      >
        <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
          <path
            d="M1.5 6.5 4.5 9.5 10.5 2.5"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span
        className={`flex-1 text-sm transition-colors ${
          checked ? "text-bone" : "text-bone/65 group-hover:text-bone/90"
        }`}
      >
        {label}
      </span>
      <span className="text-[0.7rem] text-bone/30 tabular-nums">{count}</span>
    </label>
  );
}

function Switch({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300 ${
        checked ? "bg-acid" : "bg-white/15"
      }`}
    >
      <span
        className={`absolute top-1 h-4 w-4 rounded-full transition-[left] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          checked ? "left-6 bg-void" : "left-1 bg-bone"
        }`}
      />
    </button>
  );
}

function Chip({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-acid/40 bg-acid/10 px-3 py-1.5 text-[0.7rem] font-medium text-acid">
      {label}
      <button
        type="button"
        onClick={onClear}
        aria-label={`Remove ${label} filter`}
        className="text-acid/70 transition-colors hover:text-void"
      >
        <svg width="9" height="9" viewBox="0 0 10 10" fill="none">
          <path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.6" />
        </svg>
      </button>
    </span>
  );
}
