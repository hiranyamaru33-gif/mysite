"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "@/components/CartProvider";
import Wordmark from "@/components/Wordmark";

const NAV = [
  { label: "New In", href: "/shop?sort=newest" },
  { label: "Shop All", href: "/shop" },
  { label: "Collections", href: "/#collections" },
  { label: "Journal", href: "/#story" },
];

export default function SiteHeader() {
  const { count, openCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [menuOpen]);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:rounded-full focus:bg-acid focus:px-5 focus:py-2 focus:text-xs focus:font-semibold focus:tracking-widest focus:text-void focus:uppercase"
      >
        Skip to content
      </a>

      <header
        data-scrolled={scrolled}
        className={`fixed inset-x-0 top-0 z-50 transition-[background-color,backdrop-filter,border-color,padding] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          scrolled
            ? "border-b border-white/10 bg-void/85 py-3 backdrop-blur-xl"
            : "border-b border-transparent py-5"
        }`}
      >
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-6 px-5 sm:px-8">
          <Link
            href="/"
            aria-label="voidzone — home"
            className="shrink-0 transition-opacity duration-300 hover:opacity-80"
          >
            <Wordmark size={22} />
          </Link>

          <nav className="hidden items-center gap-9 lg:flex">
            {NAV.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="link-sweep text-[0.7rem] font-medium tracking-[0.2em] text-bone/70 uppercase transition-colors duration-300 hover:text-bone"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <Link
              href="/shop"
              className="hidden h-10 items-center rounded-full px-4 text-[0.7rem] font-medium tracking-[0.18em] text-bone/70 uppercase transition-colors duration-300 hover:bg-white/5 hover:text-bone sm:inline-flex"
            >
              Search
            </Link>

            <button
              type="button"
              onClick={openCart}
              aria-label={`Open cart, ${count} item${count === 1 ? "" : "s"}`}
              className="group relative inline-flex h-10 items-center gap-2 rounded-full border border-white/15 px-4 text-[0.7rem] font-semibold tracking-[0.18em] uppercase transition-colors duration-300 hover:border-bone/60 hover:bg-white/5"
            >
              Cart
              <span
                className={`grid h-5 min-w-5 place-items-center rounded-full px-1 text-[0.65rem] font-bold tabular-nums transition-colors duration-300 ${
                  count > 0 ? "bg-acid text-void" : "bg-white/10 text-bone/70"
                }`}
              >
                {count}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setMenuOpen((value) => !value)}
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
              className="grid h-10 w-10 place-items-center rounded-full border border-white/15 transition-colors duration-300 hover:bg-white/5 lg:hidden"
            >
              <span className="relative block h-[9px] w-4">
                <span
                  className={`absolute left-0 h-[1.5px] w-full bg-bone transition-transform duration-300 ${
                    menuOpen ? "top-1/2 rotate-45" : "top-0"
                  }`}
                />
                <span
                  className={`absolute left-0 h-[1.5px] w-full bg-bone transition-transform duration-300 ${
                    menuOpen ? "top-1/2 -rotate-45" : "bottom-0"
                  }`}
                />
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer nav */}
      <div
        data-open={menuOpen}
        className={`fixed inset-0 z-40 lg:hidden ${menuOpen ? "" : "pointer-events-none"}`}
        aria-hidden={!menuOpen}
      >
        <div
          onClick={() => setMenuOpen(false)}
          className={`absolute inset-0 bg-void/80 backdrop-blur-sm transition-opacity duration-500 ${
            menuOpen ? "opacity-100" : "opacity-0"
          }`}
        />
        <nav
          className={`absolute inset-x-0 top-0 origin-top bg-void-soft px-6 pt-24 pb-10 transition-[transform,opacity] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
            menuOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
          }`}
        >
          <ul className="space-y-1">
            {NAV.map((item, index) => (
              <li key={item.label}>
                <Link
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="block border-b border-white/10 py-4 text-3xl font-bold tracking-[-0.03em] text-bone/85 transition-colors hover:text-acid"
                  style={{ transitionDelay: `${index * 20}ms` }}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <Link
            href="/shop"
            onClick={() => setMenuOpen(false)}
            className="btn btn-acid mt-8 w-full"
          >
            Shop the collection
          </Link>
        </nav>
      </div>
    </>
  );
}
