"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import { cartStore, lineKey } from "@/lib/cart-store";
import { FREE_SHIPPING_THRESHOLD, TAX_RATE, type CartLine } from "@/lib/types";

type CartContextValue = {
  lines: readonly CartLine[];
  isOpen: boolean;
  count: number;
  subtotal: number;
  openCart: () => void;
  closeCart: () => void;
  addItem: (line: Omit<CartLine, "quantity">, quantity?: number) => void;
  removeItem: (key: string) => void;
  setQuantity: (key: string, quantity: number) => void;
  clearCart: () => void;
  lastAdded: string | null;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const lines = useSyncExternalStore(
    cartStore.subscribe,
    cartStore.getSnapshot,
    cartStore.getServerSnapshot,
  );

  const [isOpen, setIsOpen] = useState(false);
  const [lastAdded, setLastAdded] = useState<string | null>(null);
  const timers = useRef<number[]>([]);

  // Clear any pending "just added" timers on unmount.
  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((id) => window.clearTimeout(id));
  }, []);

  // Lock body scroll while the drawer is open.
  useEffect(() => {
    if (!isOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  const addItem = useCallback(
    (line: Omit<CartLine, "quantity">, quantity = 1) => {
      cartStore.addItem(line, quantity);
      setLastAdded(line.slug);
      setIsOpen(true);
      timers.current.push(window.setTimeout(() => setLastAdded(null), 2200));
    },
    [],
  );

  const removeItem = useCallback((key: string) => cartStore.removeItem(key), []);
  const setQuantity = useCallback(
    (key: string, quantity: number) => cartStore.setQuantity(key, quantity),
    [],
  );
  const clearCart = useCallback(() => cartStore.clear(), []);
  const openCart = useCallback(() => setIsOpen(true), []);
  const closeCart = useCallback(() => setIsOpen(false), []);

  const value = useMemo<CartContextValue>(() => {
    const subtotal = lines.reduce(
      (sum, line) => sum + line.price * line.quantity,
      0,
    );
    return {
      lines,
      isOpen,
      count: lines.reduce((sum, line) => sum + line.quantity, 0),
      subtotal,
      openCart,
      closeCart,
      addItem,
      removeItem,
      setQuantity,
      clearCart,
      lastAdded,
    };
  }, [lines, isOpen, lastAdded, openCart, closeCart, addItem, removeItem, setQuantity, clearCart]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside <CartProvider>");
  return context;
}

/** Shared money math so cart, drawer and checkout always agree. */
export function computeTotals(
  subtotal: number,
  shippingCost: number,
  promoPercent = 0,
) {
  const discount = Math.round(subtotal * promoPercent);
  const discounted = subtotal - discount;
  const shipping =
    discounted >= FREE_SHIPPING_THRESHOLD || discounted === 0 ? 0 : shippingCost;
  const tax = Math.round(discounted * TAX_RATE);
  return {
    discount,
    shipping,
    tax,
    total: discounted + shipping + tax,
  };
}

export { lineKey };
