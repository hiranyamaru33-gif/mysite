"use client";

import { useMemo, useState } from "react";
import Stars from "@/components/Stars";
import Reveal from "@/components/Reveal";
import { formatDate } from "@/lib/format";
import type { Review } from "@/db/schema";

type Props = {
  reviews: Review[];
  rating: number;
  reviewCount: number;
  breakdown: { rating: number; count: number }[];
};

const SORTS = [
  { id: "recent", label: "Most recent" },
  { id: "helpful", label: "Most helpful" },
  { id: "high", label: "Highest rated" },
  { id: "low", label: "Lowest rated" },
] as const;

const SIZE_HISTOGRAM = (reviews: Review[]) => {
  const counts = new Map<string, number>();
  for (const review of reviews) {
    counts.set(review.size, (counts.get(review.size) ?? 0) + 1);
  }
  const max = Math.max(1, ...counts.values());
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([size, value]) => ({ size, value, percent: (value / max) * 100 }));
};

export default function ReviewsSection({
  reviews,
  rating,
  reviewCount,
  breakdown,
}: Props) {
  const [sort, setSort] = useState<(typeof SORTS)[number]["id"]>("helpful");
  const [visible, setVisible] = useState(4);

  const sorted = useMemo(() => {
    const copy = [...reviews];
    switch (sort) {
      case "recent":
        return copy.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
      case "high":
        return copy.sort((a, b) => b.rating - a.rating);
      case "low":
        return copy.sort((a, b) => a.rating - b.rating);
      default:
        return copy.sort((a, b) => b.helpful - a.helpful);
    }
  }, [reviews, sort]);

  const histogram = useMemo(() => SIZE_HISTOGRAM(reviews), [reviews]);
  const shown = sorted.slice(0, visible);

  const recommendPercent =
    reviewCount > 0
      ? Math.round(
          (reviews.filter((review) => review.rating >= 4).length / reviewCount) *
            100,
        )
      : 0;

  const averageFit =
    reviews.filter((r) => r.fit === "True to size").length /
    Math.max(1, reviews.length);

  return (
    <section
      id="reviews"
      className="scroll-mt-28 border-t border-white/10 pt-16"
    >
      <div className="grid gap-12 lg:grid-cols-[20rem_1fr] lg:gap-16">
        {/* Summary */}
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="eyebrow text-acid">Verified reviews</p>
          <h2 className="mt-4 text-[clamp(1.8rem,4vw,2.6rem)] leading-[0.95] font-extrabold tracking-[-0.04em]">
            What people say after wearing it
          </h2>

          <div className="mt-7 flex items-end gap-4">
            <span className="font-[family-name:var(--font-display)] text-6xl font-extrabold tracking-[-0.05em] tabular-nums">
              {rating > 0 ? rating.toFixed(1) : "—"}
            </span>
            <div className="pb-1.5">
              <Stars rating={rating} size={16} />
              <p className="mt-1.5 text-xs text-bone/45">
                {reviewCount} verified{" "}
                {reviewCount === 1 ? "review" : "reviews"}
              </p>
            </div>
          </div>

          <ul className="mt-7 space-y-2">
            {breakdown.map((row) => {
              const percent = reviewCount
                ? (row.count / reviewCount) * 100
                : 0;
              return (
                <li key={row.rating} className="flex items-center gap-3">
                  <span className="w-3 text-xs text-bone/50 tabular-nums">
                    {row.rating}
                  </span>
                  <span className="text-[0.7rem] text-bone/30">★</span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
                    <span
                      className="block h-full rounded-full bg-acid/80 transition-[width] duration-1000 ease-[cubic-bezier(0.16,1,0.3,1)]"
                      style={{ width: `${percent}%` }}
                    />
                  </span>
                  <span className="w-6 text-right text-xs text-bone/40 tabular-nums">
                    {row.count}
                  </span>
                </li>
              );
            })}
          </ul>

          <dl className="mt-8 space-y-5 border-t border-white/10 pt-7">
            <div>
              <dt className="field-label">Would recommend</dt>
              <dd className="mt-1 text-2xl font-bold tabular-nums">
                {recommendPercent}%
              </dd>
            </div>
            <div>
              <dt className="field-label">Rated true to size</dt>
              <dd className="mt-1 text-2xl font-bold tabular-nums">
                {Math.round(averageFit * 100)}%
              </dd>
            </div>
          </dl>

          {histogram.length ? (
            <div className="mt-8 border-t border-white/10 pt-7">
              <p className="field-label">Sizes bought</p>
              <ul className="mt-3 flex items-end gap-2">
                {histogram.map((bar) => (
                  <li key={bar.size} className="flex-1 text-center">
                    <span className="flex h-16 items-end justify-center">
                      <span
                        className="w-full rounded-t bg-white/15"
                        style={{ height: `${Math.max(8, bar.percent)}%` }}
                      />
                    </span>
                    <span className="mt-1.5 block text-[0.62rem] text-bone/40">
                      {bar.size}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>

        {/* List */}
        <div>
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
            <p className="text-sm text-bone/50">
              Showing{" "}
              <span className="font-semibold text-bone tabular-nums">
                {shown.length}
              </span>{" "}
              of {reviewCount}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {SORTS.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setSort(option.id)}
                  aria-pressed={sort === option.id}
                  className={`rounded-full px-3.5 py-1.5 text-[0.68rem] font-medium tracking-[0.1em] uppercase transition-colors duration-300 ${
                    sort === option.id
                      ? "bg-bone text-void"
                      : "text-bone/50 hover:text-bone"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          <ul className="divide-y divide-white/8">
            {shown.map((review, index) => (
              <li key={review.id}>
                <Reveal delay={Math.min(index, 4) * 50}>
                  <article className="py-7">
                    <div className="flex flex-wrap items-center gap-3">
                      <Stars rating={review.rating} size={13} />
                      <h3 className="text-[0.95rem] font-semibold">
                        {review.title}
                      </h3>
                      {review.verified ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-acid/12 px-2 py-0.5 text-[0.6rem] font-semibold tracking-[0.12em] text-acid uppercase">
                          <svg width="9" height="9" viewBox="0 0 12 12" fill="none">
                            <path
                              d="M1.5 6.5 4.5 9.5 10.5 2.5"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                          Verified
                        </span>
                      ) : null}
                    </div>

                    <p className="mt-3 max-w-2xl text-[0.92rem] leading-relaxed text-bone/65">
                      {review.body}
                    </p>

                    <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-bone/40">
                      <span className="font-medium text-bone/60">
                        {review.author}
                      </span>
                      {review.location ? <span>{review.location}</span> : null}
                      <span>Size {review.size}</span>
                      <span>{review.fit}</span>
                      <span>{formatDate(review.createdAt)}</span>
                      <span className="ml-auto flex items-center gap-1.5">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                          <path
                            d="M7 11v9H4v-9h3Zm3 9V11l4-8c1.2.2 2 .9 2.3 2L17 11h4l-1.5 6.5c-.3 1.4-1.4 2.5-2.9 2.5H10Z"
                            stroke="currentColor"
                            strokeWidth="1.4"
                          />
                        </svg>
                        {review.helpful} found this helpful
                      </span>
                    </div>
                  </article>
                </Reveal>
              </li>
            ))}
          </ul>

          {visible < sorted.length ? (
            <button
              type="button"
              onClick={() => setVisible((value) => value + 4)}
              className="btn btn-ghost mt-8"
            >
              Load more reviews
            </button>
          ) : null}
        </div>
      </div>
    </section>
  );
}
