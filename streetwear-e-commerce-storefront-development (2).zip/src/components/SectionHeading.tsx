import Link from "next/link";
import Reveal from "@/components/Reveal";

export default function SectionHeading({
  eyebrow,
  title,
  copy,
  href,
  linkLabel = "View all",
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  copy?: string;
  href?: string;
  linkLabel?: string;
  align?: "left" | "center";
}) {
  return (
    <Reveal>
      <div
        className={`flex flex-col gap-6 ${
          align === "center"
            ? "items-center text-center"
            : "md:flex-row md:items-end md:justify-between"
        }`}
      >
        <div className={align === "center" ? "max-w-2xl" : "max-w-xl"}>
          {eyebrow ? (
            <p className="eyebrow flex items-center gap-3 text-acid">
              {align === "center" ? null : (
                <span className="inline-block h-[1px] w-8 bg-acid" />
              )}
              {eyebrow}
            </p>
          ) : null}
          <h2 className="mt-4 text-[clamp(2rem,5vw,3.6rem)] leading-[0.92] font-extrabold tracking-[-0.045em]">
            {title}
          </h2>
          {copy ? (
            <p className="mt-4 text-[0.95rem] leading-relaxed text-bone/55">
              {copy}
            </p>
          ) : null}
        </div>

        {href ? (
          <Link
            href={href}
            className="link-sweep shrink-0 text-[0.72rem] font-semibold tracking-[0.18em] text-bone uppercase"
          >
            {linkLabel}
          </Link>
        ) : null}
      </div>
    </Reveal>
  );
}
