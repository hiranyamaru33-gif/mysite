const ITEMS = [
  "Free tracked shipping over $250",
  "New drop — Night Shift FW26",
  "30-day returns, no questions",
  "Carbon-neutral delivery worldwide",
];

export default function AnnouncementBar() {
  return (
    <div className="relative z-50 overflow-hidden border-b border-white/10 bg-void pt-[76px]">
      <div className="flex w-max animate-marquee items-center gap-10 py-2.5 will-change-transform">
        {[0, 1].map((copy) => (
          <div key={copy} className="flex items-center gap-10" aria-hidden={copy === 1}>
            {ITEMS.map((item) => (
              <span
                key={item}
                className="flex items-center gap-10 text-[0.625rem] font-medium tracking-[0.28em] whitespace-nowrap text-bone/55 uppercase"
              >
                {item}
                <span className="h-1 w-1 rounded-full bg-acid/70" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
