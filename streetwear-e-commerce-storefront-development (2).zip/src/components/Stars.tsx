export default function Stars({
  rating,
  size = 14,
  className = "",
}: {
  rating: number;
  size?: number;
  className?: string;
}) {
  const clamped = Math.max(0, Math.min(5, rating));
  const percent = (clamped / 5) * 100;

  return (
    <span
      className={`relative inline-block leading-none ${className}`}
      role="img"
      aria-label={`${clamped.toFixed(1)} out of 5 stars`}
      style={{ fontSize: size }}
    >
      <span className="text-white/20 tracking-[0.15em]">★★★★★</span>
      <span
        className="absolute inset-0 overflow-hidden text-acid tracking-[0.15em]"
        style={{ width: `${percent}%` }}
        aria-hidden="true"
      >
        ★★★★★
      </span>
    </span>
  );
}
