"use client";

import { useState } from "react";

export default function NewsletterForm({
  variant = "block",
  id = "newsletter",
  label = "Drop notifications",
  placeholder = "you@email.com",
  note = "One email per drop. Nothing else, ever.",
}: {
  variant?: "block" | "inline";
  id?: string;
  label?: string;
  placeholder?: string;
  note?: string;
}) {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (!email) return;
        setDone(true);
        setEmail("");
      }}
      className={variant === "inline" ? "mt-9 flex flex-col gap-3 sm:flex-row" : "mt-8 max-w-sm"}
    >
      {variant === "block" ? (
        <label htmlFor={id} className="field-label block">
          {label}
        </label>
      ) : (
        <label htmlFor={id} className="sr-only">
          {label}
        </label>
      )}

      <div
        className={
          variant === "inline"
            ? "flex flex-1 gap-3"
            : "mt-2 flex items-center gap-3 border-b border-white/20 focus-within:border-acid"
        }
      >
        {variant === "inline" ? (
          <input
            id={id}
            type="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder={placeholder}
            className="field flex-1 text-center sm:text-left"
          />
        ) : (
          <input
            id={id}
            type="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder={placeholder}
            className="w-full bg-transparent py-3 text-sm text-bone outline-none placeholder:text-bone/30"
          />
        )}

        <button
          type="submit"
          className={
            variant === "inline"
              ? "btn btn-acid shrink-0"
              : "shrink-0 text-[0.7rem] font-semibold tracking-[0.18em] text-acid uppercase transition-opacity hover:opacity-70"
          }
        >
          {variant === "inline" ? "Get access" : "Join"}
        </button>
      </div>

      {done ? (
        <p className="mt-2 text-xs text-acid animate-[fade_0.4s_ease_both]">
          You are on the list — see you at the next drop.
        </p>
      ) : note ? (
        <p className="mt-2 text-xs text-bone/35">{note}</p>
      ) : null}
    </form>
  );
}
