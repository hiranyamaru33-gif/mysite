import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ *
 * voidzone — storefront schema
 * ------------------------------------------------------------------ */

export type ProductImage = {
  url: string;
  alt: string;
};

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    name: text("name").notNull(),
    subtitle: text("subtitle").notNull().default(""),
    description: text("description").notNull(),
    details: jsonb("details").$type<string[]>().notNull().default([]),
    price: integer("price").notNull(),
    compareAtPrice: integer("compare_at_price"),
    category: text("category").notNull(),
    collection: text("collection"),
    colorway: text("colorway").notNull().default("Void Black"),
    colorHex: text("color_hex").notNull().default("#111114"),
    sizes: jsonb("sizes").$type<string[]>().notNull().default([]),
    images: jsonb("images").$type<ProductImage[]>().notNull().default([]),
    badges: jsonb("badges").$type<string[]>().notNull().default([]),
    stock: integer("stock").notNull().default(40),
    unitsSold: integer("units_sold").notNull().default(0),
    featured: boolean("featured").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    categoryIdx: index("products_category_idx").on(table.category),
    collectionIdx: index("products_collection_idx").on(table.collection),
    featuredIdx: index("products_featured_idx").on(table.featured),
  }),
);

export const reviews = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    author: text("author").notNull(),
    location: text("location").notNull().default(""),
    rating: integer("rating").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    fit: text("fit").notNull().default("True to size"),
    size: text("size").notNull().default("M"),
    helpful: integer("helpful").notNull().default(0),
    verified: boolean("verified").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    productIdx: index("reviews_product_idx").on(table.productId),
  }),
);

export const collections = pgTable(
  "collections",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    name: text("name").notNull(),
    tagline: text("tagline").notNull().default(""),
    blurb: text("blurb").notNull().default(""),
    image: text("image").notNull(),
    alt: text("alt").notNull().default(""),
    position: integer("position").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    positionIdx: index("collections_position_idx").on(table.position),
  }),
);

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    email: text("email").notNull(),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull(),
    address1: text("address_1").notNull(),
    address2: text("address_2").notNull().default(""),
    city: text("city").notNull(),
    region: text("region").notNull(),
    postalCode: text("postal_code").notNull(),
    country: text("country").notNull().default("United States"),
    shippingMethod: text("shipping_method").notNull().default("standard"),
    shippingCost: integer("shipping_cost").notNull().default(0),
    subtotal: integer("subtotal").notNull(),
    discount: integer("discount").notNull().default(0),
    tax: integer("tax").notNull().default(0),
    total: integer("total").notNull(),
    promoCode: text("promo_code").notNull().default(""),
    items: jsonb("items").$type<OrderItem[]>().notNull().default([]),
    status: text("status").notNull().default("paid"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    referenceIdx: uniqueIndex("orders_reference_idx").on(table.reference),
    emailIdx: index("orders_email_idx").on(table.email),
  }),
);

export type OrderItem = {
  slug: string;
  name: string;
  colorway: string;
  image: string;
  price: number;
  size: string;
  quantity: number;
};


export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Collection = typeof collections.$inferSelect;
export type Order = typeof orders.$inferSelect;
