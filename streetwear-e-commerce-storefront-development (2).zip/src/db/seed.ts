import { config } from "dotenv";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { collections, products, reviews } from "./schema";
import {
  SEED_COLLECTIONS,
  SEED_PRODUCTS,
  buildReviews,
  type SeedProduct,
} from "../lib/catalog";

/* ------------------------------------------------------------------ *
 * Seeding — idempotent, safe to run repeatedly.
 * Usage:  npx tsx src/db/seed.ts
 * ------------------------------------------------------------------ */

config({ path: ".env", quiet: true });

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is not set — check your .env file.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 4,
});

const db = drizzle(pool);

async function seedIfEmpty() {
  const existing = await db.select({ id: products.id }).from(products).limit(1);

  if (existing.length === 0) {
    const inserted = await db
      .insert(products)
      .values(
        SEED_PRODUCTS.map((p: SeedProduct) => ({
          slug: p.slug,
          name: p.name,
          subtitle: p.subtitle,
          description: p.description,
          details: p.details,
          price: p.price,
          compareAtPrice: p.compareAtPrice ?? null,
          category: p.category,
          collection: p.collection,
          colorway: p.colorway,
          colorHex: p.colorHex,
          sizes: p.sizes,
          images: p.images,
          badges: p.badges ?? [],
          stock: p.stock,
          unitsSold: p.unitsSold,
          featured: p.featured ?? false,
        })),
      )
      .returning({ id: products.id, slug: products.slug });

    const bySlug = new Map(inserted.map((row) => [row.slug, row.id]));
    const seedReviews = buildReviews(SEED_PRODUCTS);

    const rows = seedReviews.flatMap((review) => {
      const productId = bySlug.get(review.productSlug);
      if (!productId) return [];
      const createdAt = new Date();
      createdAt.setDate(createdAt.getDate() - review.daysAgo);
      return [
        {
          productId,
          author: review.author,
          location: review.location,
          rating: review.rating,
          title: review.title,
          body: review.body,
          fit: review.fit,
          size: review.size,
          helpful: review.helpful,
          verified: review.verified,
          createdAt,
        },
      ];
    });

    if (rows.length) await db.insert(reviews).values(rows);
    console.log(`seeded ${inserted.length} products and ${rows.length} reviews`);
  } else {
    console.log("products already present — skipping product seed");
  }

  const existingCollections = await db
    .select({ id: collections.id })
    .from(collections)
    .limit(1);

  if (existingCollections.length === 0) {
    await db.insert(collections).values(SEED_COLLECTIONS);
    console.log(`seeded ${SEED_COLLECTIONS.length} collections`);
  } else {
    console.log("collections already present — skipping collection seed");
  }
}

async function main() {
  try {
    await seedIfEmpty();
  } catch (error) {
    console.error("seed failed:", error);
    process.exitCode = 1;
  } finally {
    await pool.end().catch(() => undefined);
    process.exit(process.exitCode ?? 0);
  }
}

void main();
