import { and, count, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { collections, products, reviews } from "@/db/schema";
import { SEED_COLLECTIONS, SEED_PRODUCTS, buildReviews } from "@/lib/catalog";
import type {
  CollectionWithProducts,
  ProductDetail,
  ProductSummary,
  SortKey,
} from "@/lib/types";

/* ------------------------------------------------------------------ *
 * Boot-time catalogue guard.
 * The storefront seeds itself the first time it is loaded so the
 * sandbox is always open for business.
 * ------------------------------------------------------------------ */

let catalogueReady: Promise<void> | null = null;

export function ensureCatalogue(): Promise<void> {
  if (!catalogueReady) {
    catalogueReady = (async () => {
      const existing = await db
        .select({ id: products.id })
        .from(products)
        .limit(1);

      if (existing.length === 0) {
        await db.insert(products).values(
          SEED_PRODUCTS.map((product) => ({
            slug: product.slug,
            name: product.name,
            subtitle: product.subtitle,
            description: product.description,
            details: product.details,
            price: product.price,
            compareAtPrice: product.compareAtPrice ?? null,
            category: product.category,
            collection: product.collection,
            colorway: product.colorway,
            colorHex: product.colorHex,
            sizes: product.sizes,
            images: product.images,
            badges: product.badges ?? [],
            stock: product.stock,
            unitsSold: product.unitsSold,
            featured: product.featured ?? false,
          })),
        );

        const rows = await db
          .select({ id: products.id, slug: products.slug })
          .from(products);
        const bySlug = new Map(rows.map((row) => [row.slug, row.id]));
        const seedReviews = buildReviews(SEED_PRODUCTS).flatMap((review) => {
          const productId = bySlug.get(review.productSlug);
          if (!productId) return [];
          const createdAt = new Date();
          createdAt.setDate(createdAt.getDate() - review.daysAgo);
          return [
            {
              productId,
              author: review.author,
              location: review.location,
              rating: review.rating,
              title: review.title,
              body: review.body,
              fit: review.fit,
              size: review.size,
              helpful: review.helpful,
              verified: review.verified,
              createdAt,
            },
          ];
        });

        if (seedReviews.length) await db.insert(reviews).values(seedReviews);
      }

      const existingCollections = await db
        .select({ id: collections.id })
        .from(collections)
        .limit(1);

      if (existingCollections.length === 0) {
        await db.insert(collections).values(SEED_COLLECTIONS);
      }
    })().catch((error) => {
      catalogueReady = null;
      throw error;
    });
  }

  return catalogueReady;
}

/* ------------------------------------------------------------------ *
 * Rating aggregates
 * ------------------------------------------------------------------ */

const RATING_SELECT = {
  rating: sql<number>`coalesce(round(avg(${reviews.rating}), 1), 0)`,
  reviewCount: sql<number>`count(*)::int`,
};

type RatingRow = { rating: number; reviewCount: number };

async function ratingFor(productId: number): Promise<RatingRow> {
  const [row] = await db
    .select(RATING_SELECT)
    .from(reviews)
    .where(eq(reviews.productId, productId));
  return { rating: Number(row?.rating ?? 0), reviewCount: row?.reviewCount ?? 0 };
}

async function ratingsFor(productIds: number[]): Promise<Map<number, RatingRow>> {
  const map = new Map<number, RatingRow>();
  if (!productIds.length) return map;
  const rows = await db
    .select({
      productId: reviews.productId,
      rating: sql<number>`coalesce(round(avg(${reviews.rating}), 1), 0)`,
      reviewCount: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(inArray(reviews.productId, productIds))
    .groupBy(reviews.productId);

  for (const row of rows) {
    map.set(row.productId, {
      rating: Number(row.rating),
      reviewCount: row.reviewCount,
    });
  }
  return map;
}

/* ------------------------------------------------------------------ *
 * Queries
 * ------------------------------------------------------------------ */

const SUMMARY_FIELDS = {
  id: products.id,
  slug: products.slug,
  name: products.name,
  subtitle: products.subtitle,
  price: products.price,
  compareAtPrice: products.compareAtPrice,
  category: products.category,
  collection: products.collection,
  colorway: products.colorway,
  colorHex: products.colorHex,
  images: products.images,
  badges: products.badges,
  stock: products.stock,
  featured: products.featured,
  sizes: products.sizes,
};

export async function getFeaturedProducts(limit = 8): Promise<ProductSummary[]> {
  await ensureCatalogue();
  const rows = await db
    .select(SUMMARY_FIELDS)
    .from(products)
    .where(eq(products.featured, true))
    .orderBy(desc(products.unitsSold))
    .limit(limit);

  if (rows.length < limit) {
    const extra = await db
      .select(SUMMARY_FIELDS)
      .from(products)
      .orderBy(desc(products.unitsSold))
      .limit(limit - rows.length);
    const seen = new Set(rows.map((r) => r.slug));
    rows.push(...extra.filter((r) => !seen.has(r.slug)));
  }

  return withRatings(rows);
}

export async function getNewArrivals(limit = 4): Promise<ProductSummary[]> {
  await ensureCatalogue();
  const rows = await db
    .select(SUMMARY_FIELDS)
    .from(products)
    .orderBy(desc(products.createdAt))
    .limit(limit);
  return withRatings(rows);
}

export type ProductRow = {
  id: number;
  slug: string;
  name: string;
  subtitle: string;
  price: number;
  compareAtPrice: number | null;
  category: string;
  collection: string | null;
  colorway: string;
  colorHex: string;
  images: { url: string; alt: string }[];
  badges: string[];
  stock: number;
  featured: boolean;
  sizes: string[];
};

async function withRatings(rows: ProductRow[]): Promise<ProductSummary[]> {
  const ratings = await ratingsFor(rows.map((r) => r.id));
  return rows.map((row) => ({
    ...row,
    rating: ratings.get(row.id)?.rating ?? 0,
    reviewCount: ratings.get(row.id)?.reviewCount ?? 0,
  }));
}

export async function getAllProducts(): Promise<ProductSummary[]> {
  await ensureCatalogue();
  const rows = await db.select(SUMMARY_FIELDS).from(products);
  return withRatings(rows);
}

export async function getProductBySlug(
  slug: string,
): Promise<ProductDetail | null> {
  await ensureCatalogue();
  const [row] = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);

  if (!row) return null;

  const [{ rating, reviewCount }, breakdownRows] = await Promise.all([
    ratingFor(row.id),
    db
      .select({ rating: reviews.rating, count: count() })
      .from(reviews)
      .where(eq(reviews.productId, row.id))
      .groupBy(reviews.rating)
      .orderBy(desc(reviews.rating)),
  ]);

  const ratingBreakdown = [5, 4, 3, 2, 1].map((value) => ({
    rating: value,
    count:
      Number(
        breakdownRows.find((entry) => entry.rating === value)?.count ?? 0,
      ) || 0,
  }));

  const collection = row.collection
    ? await db
        .select({ name: collections.name })
        .from(collections)
        .where(eq(collections.slug, row.collection))
        .limit(1)
    : [];

  return {
    ...row,
    rating,
    reviewCount,
    ratingBreakdown,
    collectionName: collection[0]?.name ?? null,
  };
}

export async function getReviewsForProduct(productId: number) {
  await ensureCatalogue();
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt), desc(reviews.helpful));
}

export async function getRelatedProducts(
  product: { id: number; category: string; collection: string | null },
  limit = 4,
): Promise<ProductSummary[]> {
  await ensureCatalogue();
  const rows = await db
    .select(SUMMARY_FIELDS)
    .from(products)
    .where(
      and(
        eq(products.category, product.category),
        sql`${products.id} <> ${product.id}`,
      ),
    )
    .limit(limit);
  return withRatings(rows);
}

export async function getCollections(): Promise<CollectionWithProducts[]> {
  await ensureCatalogue();
  const rows = await db
    .select()
    .from(collections)
    .orderBy(collections.position);

  const all = await getAllProducts();

  return rows.map((row) => ({
    ...row,
    products: all.filter((product) => product.collection === row.slug),
  }));
}

export async function getCollectionBySlug(
  slug: string,
): Promise<CollectionWithProducts | null> {
  const all = await getCollections();
  return all.find((collection) => collection.slug === slug) ?? null;
}

export async function getFacetCounts() {
  await ensureCatalogue();
  const rows = await db
    .select({
      category: products.category,
      total: count(),
      minPrice: sql<number>`min(${products.price})::int`,
      maxPrice: sql<number>`max(${products.price})::int`,
    })
    .from(products)
    .groupBy(products.category);

  return {
    categories: rows.map((row) => ({
      category: row.category,
      total: Number(row.total),
    })),
    minPrice: rows.length ? Math.min(...rows.map((r) => Number(r.minPrice))) : 0,
    maxPrice: rows.length ? Math.max(...rows.map((r) => Number(r.maxPrice))) : 0,
  };
}

export function sortProducts<T extends ProductSummary>(
  list: T[],
  sort: SortKey,
): T[] {
  const copy = [...list];
  switch (sort) {
    case "price-asc":
      return copy.sort((a, b) => a.price - b.price);
    case "price-desc":
      return copy.sort((a, b) => b.price - a.price);
    case "rating":
      return copy.sort((a, b) => b.rating - a.rating);
    case "popular":
      return copy.sort((a, b) => b.reviewCount - a.reviewCount);
    case "newest":
      return copy.sort((a, b) => b.id - a.id);
    case "featured":
    default:
      return copy.sort(
        (a, b) => Number(b.featured) - Number(a.featured) || b.id - a.id,
      );
  }
}

export async function getProductMapBySlugs(slugs: string[]) {
  await ensureCatalogue();
  if (!slugs.length) return new Map<string, ProductSummary>();
  const rows = await db
    .select(SUMMARY_FIELDS)
    .from(products)
    .where(inArray(products.slug, slugs));
  const summaries = await withRatings(rows);
  return new Map(summaries.map((row) => [row.slug, row]));
}
