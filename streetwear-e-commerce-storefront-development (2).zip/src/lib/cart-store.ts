import type { CartLine } from "@/lib/types";

/**
 * A tiny external store backing the shopping cart.
 *
 * Keeping cart state outside React means localStorage is read exactly once at
 * module load (no hydration effect, no flash), and `useSyncExternalStore`
 * handles server/client snapshots correctly.
 */

const STORAGE_KEY = "voidzone.cart.v1";
const EMPTY: readonly CartLine[] = Object.freeze([]);

let current: readonly CartLine[] = EMPTY;
const listeners = new Set<() => void>();
let loaded = false;

export function lineKey(line: Pick<CartLine, "slug" | "size">) {
  return `${line.slug}::${line.size}`;
}

function persist() {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
  } catch {
    /* storage unavailable — cart stays in memory for this session */
  }
}

function commit(next: CartLine[]) {
  current = next;
  persist();
  for (const listener of listeners) listener();
}

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return;
    current = parsed.filter(
      (line): line is CartLine =>
        typeof line === "object" &&
        line !== null &&
        typeof (line as CartLine).slug === "string" &&
        typeof (line as CartLine).price === "number" &&
        typeof (line as CartLine).quantity === "number",
    );
  } catch {
    current = EMPTY;
  }
}

export const cartStore = {
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },

  getSnapshot(): readonly CartLine[] {
    load();
    return current;
  },

  /** Always empty during SSR so markup matches the first client render. */
  getServerSnapshot(): readonly CartLine[] {
    return EMPTY;
  },

  addItem(line: Omit<CartLine, "quantity">, quantity = 1) {
    const key = lineKey(line);
    const index = current.findIndex((entry) => lineKey(entry) === key);

    if (index === -1) {
      commit([...current, { ...line, quantity: Math.min(99, quantity) }]);
      return;
    }

    const next = [...current];
    next[index] = {
      ...next[index],
      quantity: Math.min(99, next[index].quantity + quantity),
    };
    commit(next);
  },

  removeItem(key: string) {
    commit(current.filter((line) => lineKey(line) !== key));
  },

  setQuantity(key: string, quantity: number) {
    commit(
      current.flatMap((line) => {
        if (lineKey(line) !== key) return [line];
        if (quantity <= 0) return [];
        return [{ ...line, quantity: Math.min(99, quantity) }];
      }),
    );
  },

  clear() {
    commit([]);
  },
};
