import type { Collection, Product, Review } from "@/db/schema";

export type ProductSummary = Pick<
  Product,
  | "id"
  | "slug"
  | "name"
  | "subtitle"
  | "price"
  | "compareAtPrice"
  | "category"
  | "collection"
  | "colorway"
  | "colorHex"
  | "images"
  | "badges"
  | "stock"
  | "featured"
  | "sizes"
> & {
  rating: number;
  reviewCount: number;
};

export type ProductDetail = Product & {
  rating: number;
  reviewCount: number;
  ratingBreakdown: { rating: number; count: number }[];
  collectionName: string | null;
};

export type CollectionWithProducts = Collection & {
  products: ProductSummary[];
};

export type ReviewWithMeta = Review;

export type SortKey =
  | "featured"
  | "newest"
  | "price-asc"
  | "price-desc"
  | "rating"
  | "popular";

export const SORT_LABELS: Record<SortKey, string> = {
  featured: "Featured",
  newest: "Newest",
  "price-asc": "Price: Low to High",
  "price-desc": "Price: High to Low",
  rating: "Top Rated",
  popular: "Most Popular",
};

export type CartLine = {
  slug: string;
  name: string;
  colorway: string;
  image: string;
  price: number;
  size: string;
  quantity: number;
};

export type ShippingOption = {
  id: string;
  label: string;
  detail: string;
  cost: number;
  days: string;
};

export const SHIPPING_OPTIONS: ShippingOption[] = [
  {
    id: "standard",
    label: "Standard",
    detail: "Carbon-neutral tracked delivery",
    cost: 0,
    days: "5–7 business days",
  },
  {
    id: "express",
    label: "Express",
    detail: "Priority handling, signature on delivery",
    cost: 1800,
    days: "2–3 business days",
  },
  {
    id: "overnight",
    label: "Overnight",
    detail: "Order before 1pm for next-day arrival",
    cost: 3800,
    days: "Next business day",
  },
];

export const PROMO_CODES: Record<string, { percent: number; label: string }> = {
  VOID10: { percent: 10, label: "10% off your order" },
  NIGHTSHIFT: { percent: 15, label: "15% off Night Shift" },
};

export const FREE_SHIPPING_THRESHOLD = 25000;
export const TAX_RATE = 0.0825;
