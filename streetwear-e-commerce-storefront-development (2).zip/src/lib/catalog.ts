/* ------------------------------------------------------------------ *
 * voidzone — demo catalogue
 * Realistic streetwear SKUs, copy, imagery and review copy.
 * ------------------------------------------------------------------ */

export type SeedProduct = {
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  details: string[];
  price: number;
  compareAtPrice?: number;
  category: string;
  collection: string;
  colorway: string;
  colorHex: string;
  sizes: string[];
  images: { url: string; alt: string }[];
  badges?: string[];
  stock: number;
  unitsSold: number;
  featured?: boolean;
};

/** Prices are authored in whole dollars and stored in the DB as cents. */
const usd = (dollars: number) => Math.round(dollars * 100);

const px = (id: number, w: number, h: number, ext = "jpeg") =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.${ext}?auto=compress&cs=tinysrgb&fit=crop&h=${h}&w=${w}`;

/** Tall 3:4 studio crop used for product detail galleries. */
const tall = (id: number, ext = "jpeg") => px(id, 900, 1200, ext);
/** Wide crop used for collection headers. */
const wide = (id: number, ext = "jpeg") => px(id, 1600, 900, ext);
/** Square crop used for product cards. */
const square = (id: number, ext = "jpeg") => px(id, 800, 800, ext);

const APPAREL = ["XS", "S", "M", "L", "XL", "XXL"];
const WAIST = ["28", "30", "32", "34", "36", "38"];
const SHOE = ["7", "8", "9", "10", "11", "12", "13"];
const ONE = ["One Size"];

export const CATEGORY_LABELS: Record<string, string> = {
  hoodies: "Hoodies & Fleece",
  tees: "Tops",
  bottoms: "Bottoms",
  outerwear: "Outerwear",
  knitwear: "Knitwear",
  accessories: "Accessories",
  footwear: "Footwear",
};

export const SEED_PRODUCTS: SeedProduct[] = [
  /* ----------------------------- HOODIES ---------------------------- */
  {
    slug: "void-state-500-hoodie",
    name: "Void State 500 Hoodie",
    subtitle: "500gsm loopback fleece — built like armour",
    description:
      "The Void State 500 is the hoodie we build everything else around. Fourteen ounces of garment-dyed loopback cotton, cut boxy through the chest with a dropped shoulder that stacks under a shell jacket. The interior is brushed twice, so it holds its structure after the first wash instead of going soft. Ribbed side gussets let you reach overhead without the hem riding up.",
    details: [
      "500gsm garment-dyed loopback cotton, brushed twice for loft",
      "Boxy fit, dropped shoulder, ribbed side gussets",
      "Double-layer hood with flat drawcord and metal tips",
      "Tonal voidzone tab at the left hem",
      "Wash cold inside out, dry flat, do not tumble",
    ],
    price: usd(168),
    compareAtPrice: usd(195),
    category: "hoodies",
    collection: "void-core",
    colorway: "Void Black",
    colorHex: "#14141a",
    sizes: APPAREL,
    images: [
      { url: tall(28701960), alt: "Model wearing the Void State 500 hoodie against a grey backdrop" },
      { url: square(28701960), alt: "Front view of the Void State 500 hoodie" },
      { url: tall(15127546), alt: "Hoodie styled with sunglasses in an industrial setting" },
      { url: square(29652516), alt: "Studio detail of heavyweight fleece fabric" },
    ],
    badges: ["Bestseller", "Restocked"],
    stock: 42,
    unitsSold: 1284,
    featured: true,
  },
  {
    slug: "signal-decay-zip-hoodie",
    name: "Signal Decay Zip Hoodie",
    subtitle: "Full-zip fleece with a taped seam finish",
    description:
      "A full-zip take on the State body, in a lighter 380gsm fleece with taped shoulder seams so it layers cleanly under outerwear. Two-piece raglan sleeves, split kangaroo pockets set high enough to actually use, and a YKK reverse-coil zip with a custom rubber pull.",
    details: [
      "380gsm brushed-back cotton fleece",
      "Two-piece raglan sleeve, taped shoulder seams",
      "YKK reverse-coil zip with rubber voidzone pull",
      "Split kangaroo pockets, ribbed cuffs and hem",
      "Regular fit — size down for a boxy silhouette",
    ],
    price: usd(194),
    category: "hoodies",
    collection: "off-grid",
    colorway: "Concrete",
    colorHex: "#8d8b85",
    sizes: APPAREL,
    images: [
      { url: tall(30410057), alt: "Two models wearing zip hoodies with sunglasses" },
      { url: square(30410057), alt: "Front detail of the Signal Decay zip hoodie" },
      { url: tall(26771145), alt: "Model in a hoodie seated on a street railing" },
      { url: square(21356439), alt: "Model in a hoodie on urban stairs" },
    ],
    badges: ["New"],
    stock: 28,
    unitsSold: 431,
    featured: true,
  },
  {
    slug: "phosphor-boxy-hoodie",
    name: "Phosphor Boxy Hoodie",
    subtitle: "Overdyed fleece in a washed acid tone",
    description:
      "The same 500gsm State body, pushed through an overdye bath until the pigment sits slightly off-register with the seam tape. No two pieces land exactly the same — expect subtle tonal drift across the panels. Pre-shrunk and pre-distressed, so the softness arrives on day one.",
    details: [
      "500gsm cotton fleece, acid overdye",
      "Garment washed for a broken-in hand",
      "Boxy cropped body with raw-edge hem",
      "Embroidered wordmark at the chest, tonal thread",
      "Each piece varies slightly in tone",
    ],
    price: usd(186),
    category: "hoodies",
    collection: "night-shift",
    colorway: "Phosphor",
    colorHex: "#d8e05a",
    sizes: APPAREL,
    images: [
      { url: tall(30283474), alt: "Model in a light hoodie on a city street at night" },
      { url: square(30283474), alt: "Bone-toned hoodie styled on the street" },
      { url: tall(26965992), alt: "Model in a hoodie and sunglasses outdoors" },
      { url: square(19225018), alt: "Hoodie layered under a jacket at night" },
    ],
    badges: ["Limited"],
    stock: 11,
    unitsSold: 267,
    featured: true,
  },

  /* ------------------------------- TEES ----------------------------- */
  {
    slug: "afterimage-box-tee",
    name: "Afterimage Box Tee",
    subtitle: "260gsm compact cotton, wide ribbed collar",
    description:
      "A heavyweight blank that behaves like a premium one. 260gsm compact-spun cotton knitted on slow looms, with a wide ribbed collar that keeps its shape and taped back neck. Cut wide and short so it sits clean over a long sleeve.",
    details: [
      "260gsm compact-spun cotton jersey",
      "Wide ribbed collar, taped back neck",
      "Boxy body, slightly cropped, tubular knit (no side seams)",
      "Water-based puff print at the back",
      "Machine wash cold, tumble low",
    ],
    price: usd(72),
    category: "tees",
    collection: "void-core",
    colorway: "Bone",
    colorHex: "#ece7dd",
    sizes: APPAREL,
    images: [
      { url: tall(19273260), alt: "Model in an oversized t-shirt on a sidewalk" },
      { url: square(19273260), alt: "Oversized tee styled with a jacket" },
      { url: tall(18584221), alt: "Model in oversized streetwear in a studio" },
      { url: square(8794470), alt: "Two models in urban t-shirt outfits" },
    ],
    badges: ["Core"],
    stock: 120,
    unitsSold: 3110,
  },
  {
    slug: "ghost-protocol-longsleeve",
    name: "Ghost Protocol Longsleeve",
    subtitle: "Thermal waffle with thumbhole cuffs",
    description:
      "A waffle-knit long sleeve that reads as a base layer and wears like a top. Ribbed waffle traps heat without bulk, thumbholes sit flat against the cuff, and the body is cut long enough to stay tucked when you move.",
    details: [
      "240gsm cotton-modal waffle knit",
      "Thumbhole cuffs, drop-tail hem",
      "Raglan sleeve for clean layering",
      "Reflective bar tack at the left cuff",
      "Wash cold, hang dry",
    ],
    price: usd(98),
    category: "tees",
    collection: "off-grid",
    colorway: "Slate",
    colorHex: "#3b3f47",
    sizes: APPAREL,
    images: [
      { url: tall(9985771), alt: "Model in a fitted long sleeve against an urban wall" },
      { url: square(9985771), alt: "Dark long sleeve top detail" },
      { url: tall(16314579), alt: "Model in streetwear with skyscrapers behind" },
      { url: square(8794466), alt: "Light tee styled against a pastel wall" },
    ],
    stock: 64,
    unitsSold: 812,
  },
  {
    slug: "grid-error-graphic-tee",
    name: "Grid Error Graphic Tee",
    subtitle: "Screen-printed on the Box Tee body",
    description:
      "The Box Tee body carrying a six-colour screen print pulled from a corrupted scan of the 1994 voidzone transit map. Cracks at the platen, so the print breaks across the seams exactly like it should.",
    details: [
      "260gsm compact cotton, boxy fit",
      "Six-colour plastisol screen print, hand-pulled",
      "Print measures 34cm x 42cm at the back",
      "Wash inside out with like colours",
      "Printed in small batches",
    ],
    price: usd(88),
    compareAtPrice: usd(96),
    category: "tees",
    collection: "archive",
    colorway: "Faded Black",
    colorHex: "#232227",
    sizes: APPAREL,
    images: [
      { url: tall(5325899), alt: "Model in a printed t-shirt on a white background" },
      { url: square(5325899), alt: "Graphic tee full body view" },
      { url: tall(31716926), alt: "Couple posing in graphic streetwear" },
      { url: square(7643904), alt: "Model in a black outfit on a light background" },
    ],
    badges: ["Bestseller"],
    stock: 37,
    unitsSold: 1544,
  },

  /* ----------------------------- BOTTOMS ---------------------------- */
  {
    slug: "deadzone-6p-cargo",
    name: "Deadzone 6-Pocket Cargo",
    subtitle: "Ripstop cargo with a tapered leg",
    description:
      "Six pockets, and every one of them is usable. Cotton-nylon ripstop with a mechanical stretch, bellowed thigh pockets that gusset open, and a hidden zip pocket at the right leg seam. Tapered from the knee so it stacks over a boot instead of pooling.",
    details: [
      "98% cotton / 2% elastane ripstop, 280gsm",
      "Bellowed bellow cargo pockets with gussets",
      "Hidden zip pocket at the right leg seam",
      "Tapered leg, 30cm leg opening",
      "Adjustable hem cinch with cord lock",
    ],
    price: usd(172),
    category: "bottoms",
    collection: "off-grid",
    colorway: "Olive Ash",
    colorHex: "#5c5f45",
    sizes: WAIST,
    images: [
      { url: tall(19189048), alt: "Model wearing cargo pants against graffiti" },
      { url: square(19189048), alt: "Cargo pant styling on the street" },
      { url: tall(30415877), alt: "Model in casual streetwear under a clear sky" },
      { url: square(15553981), alt: "Model in streetwear and sneakers outdoors" },
    ],
    badges: ["Bestseller"],
    stock: 55,
    unitsSold: 1987,
    featured: true,
  },
  {
    slug: "blackout-wide-leg-denim",
    name: "Blackout Wide-Leg Denim",
    subtitle: "14oz selvedge, overdyed to true black",
    description:
      "Fourteen-ounce selvedge denim from Okayama, overdyed twice so the indigo sits almost black and fades to charcoal rather than blue. Cut wide and long from the waist with a clean rise, and finished with a chain-stitched hem you can cuff without losing the line.",
    details: [
      "14oz selvedge denim, double overdyed",
      "Wide straight leg, 24cm leg opening",
      "Copper rivets, tonal stitching, hidden coin pocket",
      "Chain-stitched hem, sanforized pre-shrunk",
      "Raw — expect gentle fading with wear",
    ],
    price: usd(158),
    compareAtPrice: usd(185),
    category: "bottoms",
    collection: "night-shift",
    colorway: "Overdyed Black",
    colorHex: "#1b1b20",
    sizes: WAIST,
    images: [
      { url: tall(13197630), alt: "Model in a denim look on an urban street" },
      { url: square(13197630), alt: "Denim styled in the city" },
      { url: tall(36305259), alt: "Model crouching in a leather jacket and jeans" },
      { url: square(33672363), alt: "Model walking in casual streetwear" },
    ],
    stock: 31,
    unitsSold: 904,
  },
  {
    slug: "phantom-pleated-trouser",
    name: "Phantom Pleated Trouser",
    subtitle: "Single-pleat technical trouser",
    description:
      "A single forward pleat, a wide leg and a matte technical shell that reads formal from a distance and moves like track wear. Side adjusters replace the belt loops so the waist sits flat under a knit.",
    details: [
      "Recycled poly-twill technical shell, matte finish",
      "Single forward pleat, wide straight leg",
      "Side waist adjusters, hook-and-bar closure",
      "Two welt pockets, one zip back pocket",
      "Water-repellent finish",
    ],
    price: usd(165),
    category: "bottoms",
    collection: "void-core",
    colorway: "Graphite",
    colorHex: "#2c2d31",
    sizes: WAIST,
    images: [
      { url: tall(5030327), alt: "Model in street fashion with a bucket hat" },
      { url: square(5030327), alt: "Wide-leg trouser styling" },
      { url: tall(14666106), alt: "Model in a fashionable outfit and sunglasses" },
      { url: square(26088541), alt: "Model in streetwear by a colonnade" },
    ],
    badges: ["New"],
    stock: 22,
    unitsSold: 318,
  },
  {
    slug: "relay-track-pant",
    name: "Relay Track Pant",
    subtitle: "Crinkled nylon with a full side stripe",
    description:
      "Cut from a crinkled nylon that holds its texture through washing. Elastic waist with an internal drawcord, ankle zips for a clean break over a sneaker, and a full-length tonal stripe set slightly off-centre.",
    details: [
      "Crinkled nylon shell with matte hand",
      "Elastic waist with internal drawcord",
      "Ankle zips, tapered leg",
      "Full-length tonal side stripe",
      "Zip back pocket",
    ],
    price: usd(142),
    category: "bottoms",
    collection: "archive",
    colorway: "Storm",
    colorHex: "#4a4d57",
    sizes: APPAREL,
    images: [
      { url: tall(29258889), alt: "Model in a tank top posing in a studio" },
      { url: square(29258889), alt: "Studio look with track trousers" },
      { url: tall(14112701), alt: "Model in streetwear sitting on a road" },
      { url: square(16902027), alt: "Model in a cap and jacket at night" },
    ],
    stock: 48,
    unitsSold: 623,
  },

  /* ---------------------------- OUTERWEAR --------------------------- */
  {
    slug: "voidshell-anorak",
    name: "Voidshell Anorak",
    subtitle: "3-layer weatherproof pullover",
    description:
      "A 3-layer membrane shell with fully taped seams, cut as a pullover anorak so there is no zip line to break. Half-zip with a storm flap, articulated elbow, and a hood that adjusts with one hand from the front. Rated to 20k hydrostatic head — genuinely weatherproof, not water-resistant.",
    details: [
      "3-layer membrane, 20k/20k waterproof-breathable",
      "Fully taped seams, DWR treated face fabric",
      "Half-zip with storm flap and chin guard",
      "Articulated elbow, helmet-compatible hood",
      "Packs into the left hand pocket",
    ],
    price: usd(348),
    compareAtPrice: usd(395),
    category: "outerwear",
    collection: "off-grid",
    colorway: "Deep Void",
    colorHex: "#0f1013",
    sizes: APPAREL,
    images: [
      { url: tall(20267231), alt: "Model in a bomber jacket and bucket hat at night" },
      { url: square(20267231), alt: "Technical outerwear styled at night" },
      { url: tall(10378604, "jpeg"), alt: "Model in a puffer jacket on a bridge at twilight" },
      { url: square(19225018), alt: "Jacket and hoodie layered at night" },
    ],
    badges: ["Bestseller"],
    stock: 16,
    unitsSold: 517,
    featured: true,
  },
  {
    slug: "nightfall-bomber",
    name: "Nightfall Bomber",
    subtitle: "Satin bomber with a quilted liner",
    description:
      "A bomber that works from October to March. Satin-faced poly shell over a diamond-quilted liner, ribbed collar that stands without support, and a two-way zip so it sits properly when seated. Welt pockets lined in cotton twill.",
    details: [
      "Satin poly shell, diamond-quilted lining",
      "Two-way zip, ribbed collar, cuffs and hem",
      "Quilted sleeve lining for easier layering",
      "Cotton-twill lined welt pockets",
      "Regular fit — layers over a hoodie",
    ],
    price: usd(385),
    category: "outerwear",
    collection: "night-shift",
    colorway: "Midnight",
    colorHex: "#191c26",
    sizes: APPAREL,
    images: [
      { url: tall(5236966), alt: "Portrait of a model in a black bomber jacket" },
      { url: square(5236966), alt: "Bomber jacket portrait" },
      { url: tall(5592267), alt: "Model in a bomber over a hoodie" },
      { url: square(20267238), alt: "Model in a black bomber under warm lighting" },
    ],
    badges: ["Icon"],
    stock: 19,
    unitsSold: 742,
  },
  {
    slug: "sandstorm-coach-jacket",
    name: "Sandstorm Coach Jacket",
    subtitle: "Waxed cotton coach jacket",
    description:
      "A coach jacket in 10oz dry-waxed cotton that creases into a personal pattern over a season. Snap placket, slash pockets, and a corduroy collar that gives it just enough warmth to wear through a cold morning.",
    details: [
      "10oz dry-waxed cotton canvas",
      "Corduroy collar, snap-front placket",
      "Slash hand pockets, one internal pocket",
      "Unlined for a lighter shoulder",
      "Rewax annually to maintain finish",
    ],
    price: usd(298),
    category: "outerwear",
    collection: "archive",
    colorway: "Sand",
    colorHex: "#c2a97f",
    sizes: APPAREL,
    images: [
      { url: tall(3427560), alt: "Model in a denim jacket and sunglasses" },
      { url: square(3427560), alt: "Coach jacket styled in a bright interior" },
      { url: tall(29424040), alt: "Young adult posing in denim and a red hat" },
      { url: square(17399988), alt: "Model in a jacket near a window" },
    ],
    badges: ["Restocked"],
    stock: 24,
    unitsSold: 396,
  },

  /* ----------------------------- KNITWEAR --------------------------- */
  {
    slug: "static-knit-crewneck",
    name: "Static Knit Crewneck",
    subtitle: "Brushed lambswool crewneck",
    description:
      "Knitted from brushed lambswool with a hint of nylon for recovery, so it resists pilling under a backpack strap. Fully fashioned — meaning each panel is knitted to shape rather than cut from a sheet, which is why the shoulder sits where it should.",
    details: [
      "80% lambswool / 20% nylon, 7-gauge",
      "Fully fashioned, linked at the shoulder",
      "Ribbed collar, cuffs and hem with high recovery",
      "Brushed face for a soft halo",
      "Hand wash cool or dry clean",
    ],
    price: usd(198),
    category: "knitwear",
    collection: "void-core",
    colorway: "Oat",
    colorHex: "#cbbfa6",
    sizes: APPAREL,
    images: [
      { url: tall(15079022), alt: "Model in a knit sweater in dramatic lighting" },
      { url: square(15079022), alt: "Knitwear detail in low light" },
      { url: tall(6665272), alt: "Portrait in a maroon knitted sweater" },
      { url: square(18398345), alt: "Models wearing brown and grey sweatshirts" },
    ],
    badges: ["Winter"],
    stock: 33,
    unitsSold: 588,
    featured: true,
  },
  {
    slug: "merino-zip-mock",
    name: "Merino Zip Mock",
    subtitle: "Fine merino quarter-zip",
    description:
      "Extra-fine merino in a dense interlock that reads polished but wears like sportswear. Quarter-zip with a bound placket, set-in sleeves, and enough length to wear untucked over trousers.",
    details: [
      "100% extra-fine merino, 18.5 micron",
      "Quarter-zip with bound placket",
      "Set-in sleeve, ribbed collar and cuffs",
      "Naturally odour resistant",
      "Machine wash wool cycle, dry flat",
    ],
    price: usd(224),
    category: "knitwear",
    collection: "night-shift",
    colorway: "Ash",
    colorHex: "#6f6d69",
    sizes: APPAREL,
    images: [
      { url: tall(6664956), alt: "Model in a knitted outfit in a dark studio" },
      { url: square(6664956), alt: "Dark studio knitwear portrait" },
      { url: tall(30452342), alt: "Model in knitwear against a pink backdrop" },
      { url: square(5789010), alt: "Model in a knitted sweater holding a bag" },
    ],
    stock: 27,
    unitsSold: 341,
  },
  {
    slug: "loop-terry-crewneck",
    name: "Loop Terry Crewneck",
    subtitle: "Heavyweight French terry crew",
    description:
      "Twenty-ounce French terry, cross-dyed so the loop and face take pigment at different rates. Wide neck rib, reinforced elbow patches in the same fabric, and a hem long enough to stay put.",
    details: [
      "20oz cross-dyed French terry",
      "Wide neck rib, reinforced elbow patches",
      "Boxy body with a long hem",
      "Loop side out for the first ten wears",
      "Wash cold, dry flat",
    ],
    price: usd(152),
    compareAtPrice: usd(178),
    category: "knitwear",
    collection: "archive",
    colorway: "Rose Dust",
    colorHex: "#b9817a",
    sizes: APPAREL,
    images: [
      { url: tall(8801067), alt: "Model in a vibrant orange knitted sweater" },
      { url: square(8801067), alt: "Colourful knitwear studio shot" },
      { url: tall(27989532), alt: "Model in a pink sweater seated on a box" },
      { url: square(6995890), alt: "Model putting on a soft sweater" },
    ],
    stock: 29,
    unitsSold: 274,
  },

  /* ---------------------------- ACCESSORIES ------------------------- */
  {
    slug: "signal-6-panel-cap",
    name: "Signal 6-Panel Cap",
    subtitle: "Unstructured cotton twill cap",
    description:
      "An unstructured six-panel in washed cotton twill with a soft crown that folds into a pocket. Tonal embroidered signal mark at the front, adjustable webbing strap at the back, and a pre-curved brim.",
    details: [
      "Washed 100% cotton twill",
      "Unstructured soft crown",
      "Tonal 3D embroidery at the front panel",
      "Antique brass slide buckle",
      "One size, fits 54–60cm",
    ],
    price: usd(56),
    category: "accessories",
    collection: "void-core",
    colorway: "Void Black",
    colorHex: "#15151a",
    sizes: ONE,
    images: [
      { url: tall(15752006), alt: "Profile portrait of a model wearing a baseball cap" },
      { url: square(15752006), alt: "Cap worn in profile" },
      { url: tall(29925645), alt: "Model adjusting a baseball cap outdoors" },
      { url: square(8197945), alt: "Model wearing a cap indoors" },
    ],
    badges: ["Core"],
    stock: 96,
    unitsSold: 2460,
  },
  {
    slug: "void-mark-beanie",
    name: "Void Mark Beanie",
    subtitle: "Ribbed lambswool watch cap",
    description:
      "A short ribbed watch cap in lambswool, knitted at a gauge that lets it sit above the ear without slouching. Woven label at the turn-up cuff, no pom, no noise.",
    details: [
      "100% lambswool, 3x2 rib",
      "Short cuff, sits above the ear",
      "Woven voidzone label at the cuff",
      "Hand wash cool, dry flat",
      "One size",
    ],
    price: usd(48),
    category: "accessories",
    collection: "night-shift",
    colorway: "Charcoal",
    colorHex: "#33353a",
    sizes: ONE,
    images: [
      { url: tall(10301340), alt: "Portrait of a model in a jacket, cap and sunglasses" },
      { url: square(10301340), alt: "Winter headwear styled against graffiti" },
      { url: tall(10301342), alt: "Model in a cap and sunglasses leaning on a wall" },
      { url: square(10301338), alt: "Portrait with sunglasses and cap" },
    ],
    badges: ["Winter"],
    stock: 88,
    unitsSold: 1875,
  },
  {
    slug: "transit-utility-sling",
    name: "Transit Utility Sling",
    subtitle: "4L ripstop sling with magnetic close",
    description:
      "Four litres, one compartment, and a magnetic Fidlock buckle you can open one-handed while holding a rail. Bonded ripstop with a water-resistant zip, internal zip pocket, and a strap that swaps left or right.",
    details: [
      "400D bonded ripstop, water-resistant zip",
      "4L main compartment, padded sleeve to 11\"",
      "Fidlock magnetic buckle",
      "Ambidextrous, removable strap",
      "Webbing loop for keys",
    ],
    price: usd(112),
    category: "accessories",
    collection: "off-grid",
    colorway: "Olive Ash",
    colorHex: "#5c5f45",
    sizes: ONE,
    images: [
      { url: tall(20319707), alt: "Model with a backpack on outdoor steps" },
      { url: square(20319707), alt: "Utility bag styled outdoors" },
      { url: tall(14437344), alt: "Model in street fashion on an urban road" },
      { url: square(12212788), alt: "Urban fashion portrait on a rooftop" },
    ],
    badges: ["New"],
    stock: 41,
    unitsSold: 702,
  },

  /* ----------------------------- FOOTWEAR --------------------------- */
  {
    slug: "zero-g-runner",
    name: "Zero-G Runner",
    subtitle: "Knit runner on a cushioned EVA midsole",
    description:
      "A deliberately quiet runner: engineered knit upper, no branding on the toe, and a supercritical EVA midsole tuned for city pavement rather than track. Twenty-six millimetres at the heel, eight at the forefoot.",
    details: [
      "Engineered knit upper with welded support cage",
      "Supercritical EVA midsole, 26/8mm drop",
      "Rubber outsole with recycled content",
      "Removable contoured insole",
      "Runs true to size",
    ],
    price: usd(232),
    compareAtPrice: usd(260),
    category: "footwear",
    collection: "void-core",
    colorway: "Bone",
    colorHex: "#e6e0d4",
    sizes: SHOE,
    images: [
      { url: tall(18368099), alt: "Close-up of a white sneaker on an urban ledge" },
      { url: square(18368099), alt: "White sneaker detail" },
      { url: tall(38181265), alt: "White sneakers on a metal grate" },
      { url: square(32129521), alt: "Model in casual streetwear at night" },
    ],
    badges: ["Bestseller"],
    stock: 34,
    unitsSold: 1112,
    featured: true,
  },
  {
    slug: "concrete-low-suede",
    name: "Concrete Low Suede",
    subtitle: "Pig-lined suede low-top",
    description:
      "A low-top in reverse suede with a pigskin lining that breaks in fast. Vulcanised sole, cotton tape laces, and a heel counter stiff enough to keep the shape through a winter.",
    details: [
      "Reverse suede upper, pigskin lining",
      "Vulcanised rubber cup sole",
      "Cotton tape laces, brass eyelets",
      "Stitched heel counter",
      "Runs a half size large",
    ],
    price: usd(248),
    category: "footwear",
    collection: "archive",
    colorway: "Slate Grey",
    colorHex: "#767a80",
    sizes: SHOE,
    images: [
      { url: tall(13873170), alt: "Model crouching on a city street at night" },
      { url: square(13873170), alt: "Sneaker styling on a night street" },
      { url: tall(9939842), alt: "Model in a white outfit on a concrete bench" },
      { url: square(18805002), alt: "Model seated on city pavement in streetwear" },
    ],
    stock: 21,
    unitsSold: 486,
  },
];

export const SEED_COLLECTIONS = [
  {
    slug: "void-core",
    name: "Void Core",
    tagline: "The permanent collection",
    blurb:
      "The pieces we keep in rotation year-round — heavyweight fleece, compact jersey, technical trousers. Nothing seasonal, nothing that dates.",
    image: wide(10378760),
    alt: "Group of models in urban wear posing on a concrete platform at night",
    position: 0,
  },
  {
    slug: "night-shift",
    name: "Night Shift",
    tagline: "Built for after dark",
    blurb:
      "Overdyed black, satin shells and knitwear that holds warmth without bulk. Designed around the walk home rather than the daylight.",
    image: wide(10380584),
    alt: "Models posing with a car under an illuminated bridge at night",
    position: 1,
  },
  {
    slug: "off-grid",
    name: "Off-Grid",
    tagline: "Weatherproof, utility-led",
    blurb:
      "Ripstop, membrane shells and hardware that survives real weather. Taped seams, adjustable hems, pockets you can actually load.",
    image: wide(7646197),
    alt: "Model in a knit cap and jacket during an evening urban shoot",
    position: 2,
  },
  {
    slug: "archive",
    name: "Archive",
    tagline: "Reissues from the vault",
    blurb:
      "Patterns pulled back from the voidzone archive, remade in the same mills with the same tolerances. When they are gone, they are gone.",
    image: wide(1734323),
    alt: "Person wearing a cap in a dimly lit urban setting at night",
    position: 3,
  },
];

/* ------------------------------------------------------------------ *
 * Reviews — assembled from realistic fragments
 * ------------------------------------------------------------------ */

type Fragment = {
  rating: number;
  title: string;
  body: string;
  fit: string;
};

const POSITIVE: Fragment[] = [
  {
    rating: 5,
    title: "Better in person",
    body: "I have bought a lot of heavyweight fleece and this is the only one that still looks structured after three washes. The ribbed side gussets are the detail nobody talks about but make all the difference when you reach for something overhead.",
    fit: "True to size",
  },
  {
    rating: 5,
    title: "Exactly what I wanted",
    body: "Ordered my usual size and it fits clean without being boxy in a costume way. The fabric has real weight to it — you can feel the difference against the fast fashion equivalents hanging next to it in my closet.",
    fit: "True to size",
  },
  {
    rating: 5,
    title: "Third order, still impressed",
    body: "Second piece I have bought from voidzone and the consistency is what keeps me coming back. Stitching is tight, the hardware feels properly chosen, and the packaging is plastic free which I appreciate more every year.",
    fit: "True to size",
  },
  {
    rating: 4,
    title: "Great, run a half size down",
    body: "Construction is genuinely good and the colour is spot on against the product page. I am between sizes and went up — I would go down if you want it closer to the photos. Otherwise no complaints at all.",
    fit: "Runs large",
  },
  {
    rating: 5,
    title: "The details carry it",
    body: "Every seam is finished, the drawcord tips are metal, and the tag is a soft print instead of a scratchy woven label. Small things, but they add up to something that feels considered rather than assembled.",
    fit: "True to size",
  },
  {
    rating: 4,
    title: "Worth the price",
    body: "Expensive relative to what I normally spend, but I have worn it four days a week since it arrived and it still looks new. If you divide the cost by wears it is easily the cheapest thing in my wardrobe.",
    fit: "True to size",
  },
  {
    rating: 5,
    title: "Layers perfectly",
    body: "Bought this specifically to sit under a shell jacket and it works — sleeves are cut so nothing bunches at the shoulder. Wore it through a wet week and it dried overnight.",
    fit: "True to size",
  },
];

const MIXED: Fragment[] = [
  {
    rating: 4,
    title: "Solid, slight sizing caveat",
    body: "Really happy with the build quality and the fabric hand. My only note is that the shoulder is wider than I expected, so check the measurements rather than relying on the usual letter size.",
    fit: "Runs large",
  },
  {
    rating: 3,
    title: "Good piece, slow shipping",
    body: "The product itself is well made and the colour is right. It took nine days to arrive which was longer than the estimate, and there was no tracking update for the last four of them.",
    fit: "True to size",
  },
  {
    rating: 4,
    title: "Almost perfect",
    body: "Loves the weight and the way it drapes. The cuff rib is a touch tighter than I would like under a watch, but that is a preference rather than a fault.",
    fit: "Runs small",
  },
  {
    rating: 3,
    title: "Nice but sizing is inconsistent",
    body: "Ordered the same size I wear in everything else and the arms were short. Quality is clearly there, so I have exchanged for a size up and will update this once the replacement lands.",
    fit: "Runs small",
  },
];

const NEGATIVE: Fragment[] = [
  {
    rating: 2,
    title: "Colour drift on my pair",
    body: "The piece is well constructed but the overdye on mine went noticeably darker than the product images, which reads almost grey in daylight. Returns were straightforward, but I expected closer to what was shown.",
    fit: "True to size",
  },
  {
    rating: 2,
    title: "Not for me",
    body: "Fabric is heavier than the description suggested and it does not move the way I hoped. Customer service processed the return without any friction, so no complaints on that front.",
    fit: "Runs small",
  },
];

const AUTHORS = [
  ["Marek D.", "Rotterdam, NL"],
  ["Priya N.", "Manchester, UK"],
  ["Kenji T.", "Osaka, JP"],
  ["Amara O.", "Lagos, NG"],
  ["Sofia R.", "Mexico City, MX"],
  ["Lukas B.", "Berlin, DE"],
  ["Noor H.", "Toronto, CA"],
  ["Devon W.", "Atlanta, US"],
  ["Iris V.", "Helsinki, FI"],
  ["Tomas L.", "Lisbon, PT"],
  ["Hana K.", "Seoul, KR"],
  ["Yusuf A.", "Istanbul, TR"],
  ["Elena M.", "Milan, IT"],
  ["Casey J.", "Melbourne, AU"],
  ["Rafael S.", "São Paulo, BR"],
  ["Mira P.", "Warsaw, PL"],
  ["Owen F.", "Dublin, IE"],
  ["Zoe C.", "Vancouver, CA"],
];

/** Tiny deterministic PRNG so the seeded catalogue is stable across runs. */
function makeRandom(seed: number) {
  let state = seed % 2147483647;
  if (state <= 0) state += 2147483646;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state - 1) / 2147483646;
  };
}

export type SeedReview = {
  productSlug: string;
  author: string;
  location: string;
  rating: number;
  title: string;
  body: string;
  fit: string;
  size: string;
  helpful: number;
  verified: boolean;
  daysAgo: number;
};

export function buildReviews(products: SeedProduct[]): SeedReview[] {
  const out: SeedReview[] = [];

  products.forEach((product, productIndex) => {
    const random = makeRandom(9973 + productIndex * 7717);
    const count = 3 + Math.floor(random() * 4); // 3–6 reviews
    const pool = [...POSITIVE, ...POSITIVE, ...MIXED, ...NEGATIVE];
    const shuffled = pool
      .map((value) => ({ value, sort: random() }))
      .sort((a, b) => a.sort - b.sort)
      .map((entry) => entry.value);

    const names = AUTHORS.map((v) => ({ v, sort: random() }))
      .sort((a, b) => a.sort - b.sort)
      .map((entry) => entry.v);

    for (let i = 0; i < count; i += 1) {
      const fragment = shuffled[i % shuffled.length];
      const [author, location] = names[i % names.length];
      const sizes = product.sizes.filter((s) => s !== "One Size");
      const size = sizes.length
        ? sizes[Math.min(sizes.length - 1, Math.floor(random() * sizes.length))]
        : "One Size";

      out.push({
        productSlug: product.slug,
        author,
        location,
        rating: fragment.rating,
        title: fragment.title,
        body: fragment.body,
        fit: fragment.fit,
        size,
        helpful: Math.floor(random() * 64),
        verified: random() > 0.12,
        daysAgo: 3 + Math.floor(random() * 260),
      });
    }
  });

  return out;
}
