import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductGallery from "@/components/ProductGallery";
import ProductPurchase from "@/components/ProductPurchase";
import ProductGrid from "@/components/ProductGrid";
import ReviewsSection from "@/components/ReviewsSection";
import Reveal from "@/components/Reveal";
import Stars from "@/components/Stars";
import { getProductBySlug, getRelatedProducts, getReviewsForProduct } from "@/lib/data";
import { CATEGORY_LABELS } from "@/lib/catalog";
import { discountPercent, formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };

  return {
    title: product.name,
    description: product.subtitle || product.description.slice(0, 150),
    openGraph: {
      title: `${product.name} — voidzone`,
      description: product.subtitle || product.description.slice(0, 150),
      images: product.images[0] ? [{ url: product.images[0].url }] : undefined,
    },
  };
}

const SIZE_TABLE = [
  { size: "XS", chest: "50", length: "66", sleeve: "60" },
  { size: "S", chest: "53", length: "68", sleeve: "62" },
  { size: "M", chest: "56", length: "70", sleeve: "64" },
  { size: "L", chest: "59", length: "72", sleeve: "66" },
  { size: "XL", chest: "62", length: "74", sleeve: "68" },
  { size: "XXL", chest: "65", length: "76", sleeve: "70" },
];

const CARE = [
  { title: "Wash", copy: "Cold, inside out, with like colours" },
  { title: "Dry", copy: "Dry flat in shade — never tumble" },
  { title: "Press", copy: "Cool iron on the reverse only" },
  { title: "Repair", copy: "Free for life — send it back to us" },
];

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [reviews, related] = await Promise.all([
    getReviewsForProduct(product.id),
    getRelatedProducts(product, 4),
  ]);

  const off = discountPercent(product.price, product.compareAtPrice);
  const isNumericSize = !product.sizes.includes("One Size");

  return (
    <div className="pt-[76px]">
      {/* Breadcrumb */}
      <nav
        aria-label="Breadcrumb"
        className="mx-auto max-w-[1500px] px-5 pt-8 sm:px-8"
      >
        <ol className="flex flex-wrap items-center gap-2 text-[0.7rem] tracking-[0.12em] text-bone/35 uppercase">
          <li>
            <Link href="/" className="transition-colors hover:text-bone">
              Home
            </Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            <Link href="/shop" className="transition-colors hover:text-bone">
              Shop
            </Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            <Link
              href={`/shop?category=${product.category}`}
              className="transition-colors hover:text-bone"
            >
              {CATEGORY_LABELS[product.category] ?? product.category}
            </Link>
          </li>
          <li aria-hidden="true">/</li>
          <li className="text-bone/60">{product.name}</li>
        </ol>
      </nav>

      {/* Purchase block */}
      <div className="mx-auto grid max-w-[1500px] gap-12 px-5 pt-8 pb-20 sm:px-8 lg:grid-cols-2 lg:gap-16">
        <div className="lg:sticky lg:top-24 lg:self-start">
          <ProductGallery images={product.images} name={product.name} />
        </div>

        <div className="lg:py-2">
          <div className="flex flex-wrap items-center gap-3">
            {product.collectionName ? (
              <Link
                href={`/shop?collection=${product.collection}`}
                className="eyebrow text-acid transition-opacity hover:opacity-70"
              >
                {product.collectionName}
              </Link>
            ) : null}
            <span className="h-[1px] w-6 bg-white/20" />
            <span className="eyebrow text-bone/40">
              {CATEGORY_LABELS[product.category] ?? product.category}
            </span>
            {product.badges.slice(0, 1).map((badge) => (
              <span
                key={badge}
                className="rounded-full bg-white/10 px-2.5 py-1 text-[0.6rem] font-semibold tracking-[0.14em] text-bone/75 uppercase"
              >
                {badge}
              </span>
            ))}
          </div>

          <h1 className="mt-4 text-[clamp(2.2rem,5.5vw,3.8rem)] leading-[0.92] font-extrabold tracking-[-0.045em]">
            {product.name}
          </h1>

          <p className="mt-3 text-[1.02rem] text-bone/60">{product.subtitle}</p>

          <div className="mt-6 flex flex-wrap items-center gap-5">
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-bold tabular-nums">
                {formatPrice(product.price)}
              </span>
              {product.compareAtPrice ? (
                <>
                  <span className="text-base text-bone/35 line-through tabular-nums">
                    {formatPrice(product.compareAtPrice)}
                  </span>
                  <span className="rounded-full bg-flare px-2.5 py-1 text-[0.65rem] font-bold tracking-[0.1em] text-void uppercase">
                    Save {off}%
                  </span>
                </>
              ) : null}
            </div>

            <a
              href="#reviews"
              className="flex items-center gap-2 text-sm text-bone/55 transition-colors hover:text-bone"
            >
              <Stars rating={product.rating} size={13} />
              <span className="tabular-nums">
                {product.rating > 0 ? product.rating.toFixed(1) : "New"} (
                {product.reviewCount})
              </span>
            </a>
          </div>

          <div className="mt-7 flex items-center gap-3 text-sm text-bone/55">
            <span
              className="h-4 w-4 rounded-full ring-1 ring-white/20 ring-inset"
              style={{ backgroundColor: product.colorHex }}
            />
            {product.colorway}
          </div>

          <div className="mt-8">
            <ProductPurchase
              key={product.slug}
              slug={product.slug}
              name={product.name}
              price={product.price}
              colorway={product.colorway}
              image={product.images[0]?.url ?? ""}
              sizes={product.sizes}
              stock={product.stock}
            />
          </div>
        </div>
      </div>

      {/* Details */}
      <section className="border-t border-white/10 bg-void-soft">
        <div className="mx-auto grid max-w-[1500px] gap-14 px-5 py-20 sm:px-8 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <h2 className="text-[clamp(1.6rem,3.4vw,2.4rem)] leading-[1] font-extrabold tracking-[-0.04em]">
              The detail
            </h2>
            <p className="mt-6 max-w-2xl text-[1rem] leading-[1.75] text-bone/65">
              {product.description}
            </p>

            <ul className="mt-9 grid gap-3 sm:grid-cols-2">
              {product.details.map((detail) => (
                <li
                  key={detail}
                  className="flex items-start gap-3 border-t border-white/10 pt-3 text-[0.9rem] text-bone/60"
                >
                  <span
                    aria-hidden="true"
                    className="mt-[0.45rem] h-1 w-1 shrink-0 rounded-full bg-acid"
                  />
                  {detail}
                </li>
              ))}
            </ul>

            <div className="mt-12 grid gap-6 border-t border-white/10 pt-9 sm:grid-cols-2 lg:grid-cols-4">
              {CARE.map((item) => (
                <div key={item.title}>
                  <h3 className="text-[0.72rem] font-bold tracking-[0.16em] text-bone uppercase">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-[0.82rem] leading-relaxed text-bone/45">
                    {item.copy}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Size guide */}
          <div id="size-guide" className="scroll-mt-28">
            <h3 className="text-[0.72rem] font-bold tracking-[0.18em] text-bone uppercase">
              {isNumericSize ? "Size guide" : "Specification"}
            </h3>
            <p className="mt-3 text-sm text-bone/50">
              {isNumericSize
                ? "Measurements in centimetres, taken flat. Add 2cm for the fit you see in the product photography."
                : "One size, fully adjustable."}
            </p>

            {isNumericSize ? (
              <div className="mt-6 overflow-x-auto">
                <table className="w-full min-w-[22rem] border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-white/15 text-left">
                      {["Size", "Chest", "Length", "Sleeve"].map((heading) => (
                        <th
                          key={heading}
                          className="py-3 pr-4 text-[0.68rem] font-semibold tracking-[0.14em] text-bone/45 uppercase"
                        >
                          {heading}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {SIZE_TABLE.map((row) => (
                      <tr
                        key={row.size}
                        className="border-b border-white/8 text-bone/70 transition-colors hover:bg-white/[0.03]"
                      >
                        <td className="py-3 pr-4 font-semibold text-bone">
                          {row.size}
                        </td>
                        <td className="py-3 pr-4 tabular-nums">{row.chest}</td>
                        <td className="py-3 pr-4 tabular-nums">{row.length}</td>
                        <td className="py-3 pr-4 tabular-nums">{row.sleeve}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}

            <figure className="mt-9 overflow-hidden border border-white/10">
              <div className="relative aspect-[4/3]">
                <Image
                  src={product.images[1]?.url ?? product.images[0]?.url ?? ""}
                  alt={product.images[1]?.alt ?? product.name}
                  fill
                  sizes="(max-width: 1024px) 100vw, 30vw"
                  className="object-cover"
                />
              </div>
              <figcaption className="bg-void px-4 py-3 text-xs text-bone/45">
                {product.colorway} — photographed under daylight-balanced
                lighting, no retouching.
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <div className="mx-auto max-w-[1500px] px-5 py-20 sm:px-8">
        <ReviewsSection
          reviews={reviews}
          rating={product.rating}
          reviewCount={product.reviewCount}
          breakdown={product.ratingBreakdown}
        />
      </div>

      {/* Related */}
      {related.length ? (
        <section className="border-t border-white/10 bg-void-soft">
          <div className="mx-auto max-w-[1500px] px-5 py-20 sm:px-8">
            <Reveal>
              <div className="flex flex-wrap items-end justify-between gap-6">
                <div>
                  <p className="eyebrow flex items-center gap-3 text-acid">
                    <span className="inline-block h-[1px] w-8 bg-acid" />
                    Pairs well with
                  </p>
                  <h2 className="mt-4 text-[clamp(1.8rem,4vw,2.8rem)] leading-[0.95] font-extrabold tracking-[-0.04em]">
                    More from{" "}
                    {CATEGORY_LABELS[product.category] ?? product.category}
                  </h2>
                </div>
                <Link
                  href={`/shop?category=${product.category}`}
                  className="link-sweep text-[0.72rem] font-semibold tracking-[0.18em] text-bone uppercase"
                >
                  View category
                </Link>
              </div>
            </Reveal>
            <div className="mt-12">
              <ProductGrid products={related} columns={4} />
            </div>
          </div>
        </section>
      ) : null}
    </div>
  );
}
