import type { Metadata } from "next";
import { Archivo, Inter, Instrument_Serif } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/CartProvider";
import SiteHeader from "@/components/SiteHeader";
import AnnouncementBar from "@/components/AnnouncementBar";
import SiteFooter from "@/components/SiteFooter";
import CartDrawer from "@/components/CartDrawer";

const archivo = Archivo({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-archivo",
  weight: ["500", "600", "700", "800"],
});

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

const instrument = Instrument_Serif({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-instrument",
  weight: ["400"],
  style: ["normal", "italic"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://voidzone.store"),
  title: {
    default: "voidzone — heavyweight streetwear",
    template: "%s — voidzone",
  },
  description:
    "Heavyweight streetwear built in small runs. 500gsm fleece, technical shells, overdyed denim and knitwear designed in Rotterdam and cut in Portugal.",
  keywords: [
    "streetwear",
    "heavyweight hoodie",
    "techwear",
    "cargo pants",
    "voidzone",
  ],
  openGraph: {
    title: "voidzone — heavyweight streetwear",
    description:
      "Heavyweight streetwear built in small runs. Fleece, technical shells, overdyed denim and knitwear.",
    type: "website",
    locale: "en_US",
    siteName: "voidzone",
  },
  twitter: {
    card: "summary_large_image",
    title: "voidzone — heavyweight streetwear",
    description: "Heavyweight streetwear built in small runs.",
  },
};

export const viewport = {
  themeColor: "#08080a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${archivo.variable} ${inter.variable} ${instrument.variable}`}
    >
      <body className="min-h-screen bg-void text-bone antialiased">
        <CartProvider>
          <AnnouncementBar />
          <SiteHeader />
          <main id="main">{children}</main>
          <SiteFooter />
          <CartDrawer />
        </CartProvider>
      </body>
    </html>
  );
}
