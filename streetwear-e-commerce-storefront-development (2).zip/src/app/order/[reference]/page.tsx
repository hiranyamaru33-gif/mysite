import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatPrice, formatPriceExact } from "@/lib/format";
import { SHIPPING_OPTIONS } from "@/lib/types";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ reference: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { reference } = await params;
  return { title: `Order ${reference}` };
}

export default async function OrderConfirmationPage({ params }: PageProps) {
  const { reference } = await params;

  const [order] = await db
    .select()
    .from(orders)
    .where(eq(orders.reference, reference))
    .limit(1);

  if (!order) notFound();

  const shipping =
    SHIPPING_OPTIONS.find((option) => option.id === order.shippingMethod) ??
    SHIPPING_OPTIONS[0];

  const eta = new Date();
  eta.setDate(eta.getDate() + (shipping.id === "overnight" ? 1 : shipping.id === "express" ? 3 : 6));

  return (
    <div className="pt-[76px]">
      <div className="mx-auto max-w-3xl px-5 py-16 sm:px-8 sm:py-24">
        <div className="text-center">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-acid/15 text-acid animate-[rise_0.7s_var(--ease-out-expo)_both]">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
              <path
                d="M4 12.5 9.5 18 20 6.5"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>

          <h1 className="mt-7 text-[clamp(2.2rem,6vw,3.6rem)] leading-[0.92] font-extrabold tracking-[-0.045em] animate-[rise_0.8s_var(--ease-out-expo)_both]">
            Order confirmed
          </h1>
          <p className="mx-auto mt-5 max-w-lg text-[0.98rem] leading-relaxed text-bone/60 animate-[fade_1s_ease_both]">
            Thanks {order.firstName} — we have sent a receipt to{" "}
            <span className="text-bone">{order.email}</span>. Your pieces are
            being picked now.
          </p>
        </div>

        <dl className="mt-14 grid gap-8 border-y border-white/10 py-8 sm:grid-cols-3">
          <div>
            <dt className="field-label">Order</dt>
            <dd className="mt-1.5 font-mono text-sm font-semibold text-acid">
              {order.reference}
            </dd>
          </div>
          <div>
            <dt className="field-label">Delivery</dt>
            <dd className="mt-1.5 text-sm text-bone/80">
              {eta.toLocaleDateString("en-US", {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
              <span className="block text-xs text-bone/40">
                {shipping.label} · {shipping.days}
              </span>
            </dd>
          </div>
          <div>
            <dt className="field-label">Total paid</dt>
            <dd className="mt-1.5 text-sm font-semibold tabular-nums">
              {formatPriceExact(order.total)}
            </dd>
          </div>
        </dl>

        <section className="mt-12">
          <h2 className="eyebrow text-bone/40">
            {order.items.length} {order.items.length === 1 ? "item" : "items"}
          </h2>
          <ul className="mt-5 divide-y divide-white/8">
            {order.items.map((item) => (
              <li
                key={`${item.slug}-${item.size}`}
                className="flex items-center gap-4 py-5"
              >
                <div className="relative h-20 w-16 shrink-0 overflow-hidden bg-void-soft">
                  {item.image ? (
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  ) : null}
                </div>
                <div className="min-w-0 flex-1">
                  <Link
                    href={`/product/${item.slug}`}
                    className="text-sm font-semibold transition-colors hover:text-acid"
                  >
                    {item.name}
                  </Link>
                  <p className="mt-1 text-xs text-bone/40">
                    {item.colorway} · Size {item.size} · Qty {item.quantity}
                  </p>
                </div>
                <span className="shrink-0 text-sm font-semibold tabular-nums">
                  {formatPrice(item.price * item.quantity)}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-10 grid gap-8 border-t border-white/10 pt-10 sm:grid-cols-2">
          <div>
            <h2 className="field-label">Shipping to</h2>
            <address className="mt-2 text-sm leading-relaxed text-bone/70 not-italic">
              {order.firstName} {order.lastName}
              <br />
              {order.address1}
              {order.address2 ? (
                <>
                  <br />
                  {order.address2}
                </>
              ) : null}
              <br />
              {order.city}, {order.region} {order.postalCode}
              <br />
              {order.country}
            </address>
          </div>
          <div>
            <h2 className="field-label">Payment</h2>
            <p className="mt-2 text-sm text-bone/70">
              Paid in full
              <br />
              <span className="text-bone/40">
                Demo store — no card was charged
              </span>
            </p>
          </div>
        </section>

        <div className="mt-12 border-t border-white/10 pt-10">
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-bone/50">Subtotal</dt>
              <dd className="tabular-nums">{formatPriceExact(order.subtotal)}</dd>
            </div>
            {order.discount > 0 ? (
              <div className="flex justify-between text-acid">
                <dt>Discount {order.promoCode ? `(${order.promoCode})` : ""}</dt>
                <dd className="tabular-nums">
                  −{formatPriceExact(order.discount)}
                </dd>
              </div>
            ) : null}
            <div className="flex justify-between">
              <dt className="text-bone/50">Shipping</dt>
              <dd className="tabular-nums">
                {order.shippingCost === 0
                  ? "Free"
                  : formatPriceExact(order.shippingCost)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-bone/50">Tax</dt>
              <dd className="tabular-nums">{formatPriceExact(order.tax)}</dd>
            </div>
            <div className="flex justify-between border-t border-white/12 pt-3 text-base font-bold">
              <dt>Total</dt>
              <dd className="tabular-nums">{formatPriceExact(order.total)}</dd>
            </div>
          </dl>
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-3">
          <Link href="/shop" className="btn btn-acid">
            Keep shopping
          </Link>
          <Link href="/support" className="btn btn-ghost">
            Track or manage order
          </Link>
        </div>
      </div>
    </div>
  );
}
