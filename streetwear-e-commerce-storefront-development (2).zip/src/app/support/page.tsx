import type { Metadata } from "next";
import Link from "next/link";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Support",
  description:
    "Shipping, returns, sizing and care information for voidzone orders.",
};

const SECTIONS = [
  {
    id: "shipping",
    title: "Shipping & delivery",
    body: [
      "Orders placed before 1pm CET ship the same working day from Rotterdam. Standard delivery is carbon-neutral and tracked, arriving in 5–7 business days across Europe and 7–10 elsewhere.",
      "Express (2–3 days) and overnight options are calculated at checkout. Shipping is free on orders over $250 — the discount applies automatically.",
      "You will receive a tracking link by email as soon as the parcel is scanned. Customs duties for deliveries outside the EU are calculated at checkout, so nothing is owed on arrival.",
    ],
  },
  {
    id: "returns",
    title: "Returns & exchanges",
    body: [
      "Thirty days from delivery to change your mind, unworn and with tags attached. We pay return shipping within the EU and the UK.",
      "Exchanges for a different size are prioritised and usually leave the warehouse within 24 hours of arrival. Start a return from the link in your confirmation email and we will send a prepaid label.",
      "Final-sale and archive pieces are marked on the product page and cannot be returned, other than for a fault.",
    ],
  },
  {
    id: "sizing",
    title: "Size guide",
    body: [
      "Every product page carries flat measurements in centimetres. Measure a garment you already own the same way and compare — it is more reliable than trusting a letter size.",
      "Our fleece and jersey pieces are cut boxy. If you want a closer fit, take one size down. Trousers are true to the stated waist with a tapered leg; denim runs a half size generous.",
      "Still unsure? Email sizing@voidzone.store with your measurements and the piece you are considering. A human replies within a working day.",
    ],
  },
  {
    id: "care",
    title: "Care instructions",
    body: [
      "Wash cold, inside out, with like colours. Heavyweight fleece and loopback cotton should be dried flat — tumble drying breaks the loft and shrinks the rib.",
      "Raw and overdyed denim will fade. Wash it as little as possible for the first month and expect honest fading rather than even distressing.",
      "Waxed cotton needs rewaxing roughly once a season to stay weatherproof. We sell the wax tin, and it lasts years.",
    ],
  },
  {
    id: "contact",
    title: "Contact",
    body: [
      "Support: hello@voidzone.store — replies within one working day, 09:00–18:00 CET.",
      "Repairs: repairs@voidzone.store — free for the life of every garment. Send us a photo of the damage first and we will confirm before you post anything.",
      "Studio: Scheepmakerspassage 8, 3011 Rotterdam, Netherlands. Visits by appointment only.",
    ],
  },
];

export default function SupportPage() {
  return (
    <div className="pt-[76px]">
      <header className="mx-auto max-w-[1500px] px-5 pt-16 pb-12 sm:px-8">
        <Reveal>
          <p className="eyebrow flex items-center gap-3 text-acid">
            <span className="inline-block h-[1px] w-8 bg-acid" />
            Help centre
          </p>
          <h1 className="mt-5 max-w-3xl text-[clamp(2.4rem,7vw,5rem)] leading-[0.88] font-extrabold tracking-[-0.05em]">
            EVERYTHING YOU MIGHT NEED
          </h1>
        </Reveal>
      </header>

      <div className="mx-auto max-w-[1500px] px-5 pb-8 sm:px-8">
        <nav
          aria-label="Support sections"
          className="flex flex-wrap gap-2 border-y border-white/10 py-5"
        >
          {SECTIONS.map((section) => (
            <a
              key={section.id}
              href={`#${section.id}`}
              className="rounded-full border border-white/15 px-4 py-2 text-[0.7rem] font-medium tracking-[0.12em] uppercase transition-colors hover:border-acid hover:text-acid"
            >
              {section.title}
            </a>
          ))}
        </nav>
      </div>

      <div className="mx-auto max-w-[1500px] space-y-16 px-5 py-16 sm:px-8">
        {SECTIONS.map((section, index) => (
          <Reveal key={section.id} delay={index * 40}>
            <section
              id={section.id}
              className="scroll-mt-28 grid gap-6 border-t border-white/10 pt-10 lg:grid-cols-[18rem_1fr] lg:gap-16"
            >
              <h2 className="text-[clamp(1.5rem,3vw,2.2rem)] leading-[1] font-extrabold tracking-[-0.04em]">
                {section.title}
              </h2>
              <div className="max-w-2xl space-y-4">
                {section.body.map((paragraph) => (
                  <p
                    key={paragraph}
                    className="text-[0.95rem] leading-[1.75] text-bone/60"
                  >
                    {paragraph}
                  </p>
                ))}
              </div>
            </section>
          </Reveal>
        ))}

        <Reveal>
          <div className="rounded-2xl border border-white/12 bg-void-soft px-6 py-12 text-center">
            <h2 className="text-2xl font-extrabold tracking-[-0.03em]">
              Still stuck?
            </h2>
            <p className="mx-auto mt-3 max-w-md text-sm text-bone/55">
              Email us and a person who has handled the garment in question will
              reply. No bots, no ticket queues.
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <a href="mailto:hello@voidzone.store" className="btn btn-acid">
                Email support
              </a>
              <Link href="/shop" className="btn btn-ghost">
                Back to the shop
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
