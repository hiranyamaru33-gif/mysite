import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { and, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import {
  FREE_SHIPPING_THRESHOLD,
  PROMO_CODES,
  SHIPPING_OPTIONS,
  TAX_RATE,
} from "@/lib/types";

export const dynamic = "force-dynamic";

const itemSchema = z.object({
  slug: z.string().min(1).max(120),
  name: z.string().min(1).max(200),
  colorway: z.string().min(1).max(80),
  image: z.string().max(600).default(""),
  price: z.number().int().positive().max(100_000_00),
  size: z.string().min(1).max(24),
  quantity: z.number().int().min(1).max(20),
});

const checkoutSchema = z.object({
  email: z.string().email().max(200),
  firstName: z.string().min(1).max(80),
  lastName: z.string().min(1).max(80),
  address1: z.string().min(3).max(160),
  address2: z.string().max(160).default(""),
  city: z.string().min(1).max(80),
  region: z.string().min(1).max(80),
  postalCode: z.string().min(2).max(20),
  country: z.string().min(2).max(80).default("United States"),
  shippingMethod: z.string().min(1).max(40),
  promoCode: z.string().max(40).default(""),
  items: z.array(itemSchema).min(1).max(40),
});

function reference() {
  const stamp = Date.now().toString(36).toUpperCase().slice(-5);
  const random = randomUUID().replace(/-/g, "").slice(0, 4).toUpperCase();
  return `VZ-${stamp}-${random}`;
}

export async function POST(request: Request) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const parsed = checkoutSchema.safeParse(payload);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Please check the highlighted fields.",
        issues: parsed.error.flatten().fieldErrors,
      },
      { status: 422 },
    );
  }

  const data = parsed.data;

  // Re-price server side — the client is never trusted for money.
  const slugs = [...new Set(data.items.map((item) => item.slug))];
  const rows = await db
    .select({
      slug: products.slug,
      name: products.name,
      price: products.price,
      stock: products.stock,
      images: products.images,
      colorway: products.colorway,
    })
    .from(products)
    .where(inArray(products.slug, slugs));

  const bySlug = new Map(rows.map((row) => [row.slug, row]));
  const lines = [];

  for (const item of data.items) {
    const product = bySlug.get(item.slug);
    if (!product) {
      return NextResponse.json(
        { error: `“${item.name}” is no longer available.` },
        { status: 409 },
      );
    }
    if (product.stock < item.quantity) {
      return NextResponse.json(
        { error: `Only ${product.stock} × ${product.name} remain.` },
        { status: 409 },
      );
    }
    lines.push({
      slug: product.slug,
      name: product.name,
      colorway: product.colorway,
      image: product.images[0]?.url ?? "",
      price: product.price,
      size: item.size,
      quantity: item.quantity,
    });
  }

  const subtotal = lines.reduce(
    (sum, line) => sum + line.price * line.quantity,
    0,
  );

  const shipping = SHIPPING_OPTIONS.find(
    (option) => option.id === data.shippingMethod,
  );
  if (!shipping) {
    return NextResponse.json(
      { error: "Choose a shipping method." },
      { status: 422 },
    );
  }

  const promo = data.promoCode ? PROMO_CODES[data.promoCode] : undefined;
  const discount = promo ? Math.round(subtotal * (promo.percent / 100)) : 0;
  const discounted = subtotal - discount;
  const shippingCost =
    discounted === 0 || discounted >= FREE_SHIPPING_THRESHOLD ? 0 : shipping.cost;
  const tax = Math.round(discounted * TAX_RATE);
  const total = discounted + shippingCost + tax;

  const orderReference = reference();

  const [order] = await db
    .insert(orders)
    .values({
      reference: orderReference,
      email: data.email,
      firstName: data.firstName,
      lastName: data.lastName,
      address1: data.address1,
      address2: data.address2,
      city: data.city,
      region: data.region,
      postalCode: data.postalCode,
      country: data.country,
      shippingMethod: shipping.id,
      shippingCost,
      subtotal,
      discount,
      tax,
      total,
      promoCode: data.promoCode,
      items: lines,
      status: "paid",
    })
    .returning({ id: orders.id, reference: orders.reference, total: orders.total });

  // Decrement stock so the demo storefront behaves like a real one.
  await Promise.all(
    lines.map((line) =>
      db
        .update(products)
        .set({ stock: Math.max(0, (bySlug.get(line.slug)?.stock ?? 0) - line.quantity) })
        .where(and(eq(products.slug, line.slug))),
    ),
  );

  return NextResponse.json({
    ok: true,
    reference: order.reference,
    id: order.id,
    total: order.total,
    email: data.email,
  });
}
