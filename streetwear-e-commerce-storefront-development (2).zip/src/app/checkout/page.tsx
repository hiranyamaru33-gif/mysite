"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { computeTotals, useCart } from "@/components/CartProvider";
import { formatPrice, formatPriceExact } from "@/lib/format";
import { FREE_SHIPPING_THRESHOLD, PROMO_CODES, SHIPPING_OPTIONS } from "@/lib/types";

type Step = 0 | 1 | 2;

const STEPS = ["Information", "Shipping", "Payment"] as const;

const COUNTRIES = [
  "United States",
  "Canada",
  "United Kingdom",
  "Netherlands",
  "Germany",
  "France",
  "Japan",
  "Australia",
];

type FormState = {
  email: string;
  firstName: string;
  lastName: string;
  address1: string;
  address2: string;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  cardName: string;
  cardNumber: string;
  cardExpiry: string;
  cardCvc: string;
};

const EMPTY: FormState = {
  email: "",
  firstName: "",
  lastName: "",
  address1: "",
  address2: "",
  city: "",
  region: "",
  postalCode: "",
  country: "United States",
  cardName: "",
  cardNumber: "",
  cardExpiry: "",
  cardCvc: "",
};

function formatCard(value: string) {
  return value
    .replace(/\D/g, "")
    .slice(0, 16)
    .replace(/(.{4})/g, "$1 ")
    .trim();
}

function formatExpiry(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)}/${digits.slice(2)}`;
}

export default function CheckoutPage() {
  const router = useRouter();
  const { lines, clearCart, count } = useCart();

  const [step, setStep] = useState<Step>(0);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [shippingMethod, setShippingMethod] = useState("standard");
  const [promoInput, setPromoInput] = useState("");
  const [promo, setPromo] = useState<string | null>(null);
  const [promoError, setPromoError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const shipping =
    SHIPPING_OPTIONS.find((option) => option.id === shippingMethod) ??
    SHIPPING_OPTIONS[0];

  const subtotal = useMemo(
    () => lines.reduce((sum, line) => sum + line.price * line.quantity, 0),
    [lines],
  );

  const totals = useMemo(
    () =>
      computeTotals(subtotal, shipping.cost, promo ? PROMO_CODES[promo].percent : 0),
    [subtotal, shipping.cost, promo],
  );

  useEffect(() => {
    if (count === 0 && !submitting) {
      router.replace("/shop");
    }
  }, [count, router, submitting]);

  const update = (key: keyof FormState) => (value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
  };

  const validateInformation = () => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email))
      next.email = "Enter a valid email address.";
    if (form.firstName.trim().length < 2) next.firstName = "Required.";
    if (form.lastName.trim().length < 2) next.lastName = "Required.";
    if (form.address1.trim().length < 4) next.address1 = "Enter your street address.";
    if (form.city.trim().length < 2) next.city = "Required.";
    if (form.region.trim().length < 2) next.region = "Required.";
    if (form.postalCode.trim().length < 3) next.postalCode = "Required.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const validatePayment = () => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (form.cardName.trim().length < 3) next.cardName = "Name on card is required.";
    if (form.cardNumber.replace(/\D/g, "").length !== 16)
      next.cardNumber = "Enter the 16-digit card number.";
    if (!/^\d{2}\/\d{2}$/.test(form.cardExpiry)) next.cardExpiry = "MM/YY";
    if (!/^\d{3,4}$/.test(form.cardCvc)) next.cardCvc = "3–4 digits";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const applyPromo = () => {
    const code = promoInput.trim().toUpperCase();
    if (!code) return;
    if (PROMO_CODES[code]) {
      setPromo(code);
      setPromoError(null);
    } else {
      setPromo(null);
      setPromoError(`“${code}” is not a valid code.`);
    }
  };

  const placeOrder = async () => {
    if (!validatePayment()) {
      setStep(2);
      return;
    }
    setSubmitting(true);
    setServerError(null);

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email.trim(),
          firstName: form.firstName.trim(),
          lastName: form.lastName.trim(),
          address1: form.address1.trim(),
          address2: form.address2.trim(),
          city: form.city.trim(),
          region: form.region.trim(),
          postalCode: form.postalCode.trim(),
          country: form.country,
          shippingMethod: shipping.id,
          promoCode: promo ?? "",
          items: lines.map((line) => ({
            slug: line.slug,
            name: line.name,
            colorway: line.colorway,
            image: line.image,
            price: line.price,
            size: line.size,
            quantity: line.quantity,
          })),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setServerError(data?.error ?? "Something went wrong. Please try again.");
        setSubmitting(false);
        return;
      }

      clearCart();
      router.push(`/order/${data.reference}`);
    } catch {
      setServerError("We could not reach the payment service. Please try again.");
      setSubmitting(false);
    }
  };

  if (!lines.length) {
    return (
      <div className="grid min-h-[70svh] place-items-center px-6 pt-[76px]">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold tracking-[-0.04em]">
            Your cart is empty
          </h1>
          <p className="mt-3 text-sm text-bone/50">
            Add a piece and come back — your cart will be waiting.
          </p>
          <Link href="/shop" className="btn btn-acid mt-8">
            Start shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-[76px]">
      <div className="mx-auto grid max-w-[1500px] gap-12 px-5 py-12 sm:px-8 lg:grid-cols-[1.25fr_1fr] lg:gap-20 lg:py-16">
        {/* Form column */}
        <div>
          <Link
            href="/shop"
            className="link-sweep text-[0.7rem] tracking-[0.16em] text-bone/45 uppercase"
          >
            ← Continue shopping
          </Link>

          <h1 className="mt-6 text-[clamp(2.2rem,5vw,3.4rem)] leading-[0.92] font-extrabold tracking-[-0.045em]">
            Checkout
          </h1>

          {/* Steps */}
          <ol className="mt-8 flex items-center gap-3">
            {STEPS.map((label, index) => {
              const done = index < step;
              const active = index === step;
              return (
                <li key={label} className="flex flex-1 items-center gap-3">
                  <button
                    type="button"
                    onClick={() => index < step && setStep(index as Step)}
                    disabled={index > step}
                    aria-current={active ? "step" : undefined}
                    className="flex min-w-0 flex-1 items-center gap-2.5 text-left disabled:cursor-default"
                  >
                    <span
                      className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-[0.7rem] font-bold transition-colors duration-400 ${
                        done
                          ? "bg-acid text-void"
                          : active
                            ? "border border-acid text-acid"
                            : "border border-white/20 text-bone/35"
                      }`}
                    >
                      {done ? (
                        <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
                          <path
                            d="M1.5 6.5 4.5 9.5 10.5 2.5"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      ) : (
                        index + 1
                      )}
                    </span>
                    <span
                      className={`truncate text-[0.7rem] font-semibold tracking-[0.14em] uppercase transition-colors ${
                        active ? "text-bone" : "text-bone/35"
                      }`}
                    >
                      {label}
                    </span>
                  </button>
                  {index < STEPS.length - 1 ? (
                    <span className="h-[1px] w-6 shrink-0 bg-white/12" />
                  ) : null}
                </li>
              );
            })}
          </ol>

          <div className="mt-10">
            {step === 0 ? (
              <section className="animate-[rise_0.5s_var(--ease-out-expo)_both] space-y-8">
                <div>
                  <h2 className="text-lg font-bold tracking-[-0.02em]">
                    Contact
                  </h2>
                  <div className="mt-4">
                    <label htmlFor="email" className="field-label block">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      autoComplete="email"
                      value={form.email}
                      onChange={(event) => update("email")(event.target.value)}
                      placeholder="you@email.com"
                      className="field mt-1.5"
                    />
                    <FieldError message={errors.email} />
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-bold tracking-[-0.02em]">
                    Shipping address
                  </h2>
                  <div className="mt-4 grid gap-5 sm:grid-cols-2">
                    <Field
                      id="firstName"
                      label="First name"
                      value={form.firstName}
                      onChange={update("firstName")}
                      error={errors.firstName}
                      autoComplete="given-name"
                    />
                    <Field
                      id="lastName"
                      label="Last name"
                      value={form.lastName}
                      onChange={update("lastName")}
                      error={errors.lastName}
                      autoComplete="family-name"
                    />
                    <div className="sm:col-span-2">
                      <Field
                        id="address1"
                        label="Address"
                        value={form.address1}
                        onChange={update("address1")}
                        error={errors.address1}
                        autoComplete="address-line1"
                        placeholder="Street and number"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <Field
                        id="address2"
                        label="Apartment, suite (optional)"
                        value={form.address2}
                        onChange={update("address2")}
                        autoComplete="address-line2"
                      />
                    </div>
                    <Field
                      id="city"
                      label="City"
                      value={form.city}
                      onChange={update("city")}
                      error={errors.city}
                      autoComplete="address-level2"
                    />
                    <Field
                      id="region"
                      label="State / Region"
                      value={form.region}
                      onChange={update("region")}
                      error={errors.region}
                      autoComplete="address-level1"
                    />
                    <Field
                      id="postalCode"
                      label="Postcode"
                      value={form.postalCode}
                      onChange={update("postalCode")}
                      error={errors.postalCode}
                      autoComplete="postal-code"
                    />
                    <div>
                      <label htmlFor="country" className="field-label block">
                        Country
                      </label>
                      <select
                        id="country"
                        value={form.country}
                        onChange={(event) => update("country")(event.target.value)}
                        className="field mt-1.5 bg-void"
                      >
                        {COUNTRIES.map((country) => (
                          <option key={country} value={country}>
                            {country}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => validateInformation() && setStep(1)}
                  className="btn btn-acid w-full"
                >
                  Continue to shipping
                </button>
              </section>
            ) : null}

            {step === 1 ? (
              <section className="animate-[rise_0.5s_var(--ease-out-expo)_both] space-y-8">
                <div>
                  <h2 className="text-lg font-bold tracking-[-0.02em]">
                    Delivery method
                  </h2>
                  <div className="mt-4 space-y-3">
                    {SHIPPING_OPTIONS.map((option) => {
                      const checked = option.id === shippingMethod;
                      const free =
                        option.cost === 0 || subtotal >= FREE_SHIPPING_THRESHOLD;
                      return (
                        <label
                          key={option.id}
                          className={`flex cursor-pointer items-center gap-4 border p-5 transition-colors duration-300 ${
                            checked
                              ? "border-acid bg-acid/[0.06]"
                              : "border-white/12 hover:border-white/30"
                          }`}
                        >
                          <input
                            type="radio"
                            name="shipping"
                            value={option.id}
                            checked={checked}
                            onChange={() => setShippingMethod(option.id)}
                            className="peer sr-only"
                          />
                          <span
                            className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border transition-colors ${
                              checked ? "border-acid" : "border-white/25"
                            }`}
                          >
                            <span
                              className={`h-2.5 w-2.5 rounded-full transition-transform duration-300 ${
                                checked ? "scale-100 bg-acid" : "scale-0"
                              }`}
                            />
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="flex items-baseline justify-between gap-3">
                              <span className="text-sm font-semibold">
                                {option.label}
                              </span>
                              <span className="text-sm font-semibold tabular-nums">
                                {free ? "Free" : formatPrice(option.cost)}
                              </span>
                            </span>
                            <span className="mt-1 block text-xs text-bone/45">
                              {option.detail} · {option.days}
                            </span>
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="border border-white/10 p-5">
                  <p className="field-label">Delivering to</p>
                  <p className="mt-2 text-sm leading-relaxed text-bone/70">
                    {form.firstName} {form.lastName}
                    <br />
                    {form.address1}
                    {form.address2 ? `, ${form.address2}` : ""}
                    <br />
                    {form.city}, {form.region} {form.postalCode}
                    <br />
                    {form.country}
                  </p>
                  <button
                    type="button"
                    onClick={() => setStep(0)}
                    className="link-sweep mt-3 text-[0.68rem] tracking-[0.14em] text-bone/45 uppercase"
                  >
                    Edit
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="btn btn-acid w-full"
                >
                  Continue to payment
                </button>
              </section>
            ) : null}

            {step === 2 ? (
              <section className="animate-[rise_0.5s_var(--ease-out-expo)_both] space-y-8">
                <div>
                  <div className="flex items-center justify-between gap-4">
                    <h2 className="text-lg font-bold tracking-[-0.02em]">
                      Payment
                    </h2>
                    <span className="inline-flex items-center gap-2 text-[0.65rem] tracking-[0.14em] text-bone/35 uppercase">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
                        <rect
                          x="4"
                          y="10"
                          width="16"
                          height="10"
                          rx="2"
                          stroke="currentColor"
                          strokeWidth="1.6"
                        />
                        <path
                          d="M8 10V7a4 4 0 0 1 8 0v3"
                          stroke="currentColor"
                          strokeWidth="1.6"
                        />
                      </svg>
                      Encrypted
                    </span>
                  </div>

                  <p className="mt-3 rounded-lg border border-acid/25 bg-acid/[0.06] px-4 py-3 text-xs text-acid/90">
                    Demo store — no card is charged. Use any 16 digits.
                  </p>

                  <div className="mt-5 grid gap-5 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <Field
                        id="cardName"
                        label="Name on card"
                        value={form.cardName}
                        onChange={update("cardName")}
                        error={errors.cardName}
                        autoComplete="cc-name"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <Field
                        id="cardNumber"
                        label="Card number"
                        value={form.cardNumber}
                        onChange={(value) =>
                          update("cardNumber")(formatCard(value))
                        }
                        error={errors.cardNumber}
                        autoComplete="cc-number"
                        inputMode="numeric"
                        placeholder="4242 4242 4242 4242"
                      />
                    </div>
                    <Field
                      id="cardExpiry"
                      label="Expiry"
                      value={form.cardExpiry}
                      onChange={(value) =>
                        update("cardExpiry")(formatExpiry(value))
                      }
                      error={errors.cardExpiry}
                      autoComplete="cc-exp"
                      inputMode="numeric"
                      placeholder="MM/YY"
                    />
                    <Field
                      id="cardCvc"
                      label="CVC"
                      value={form.cardCvc}
                      onChange={(value) =>
                        update("cardCvc")(value.replace(/\D/g, "").slice(0, 4))
                      }
                      error={errors.cardCvc}
                      autoComplete="cc-csc"
                      inputMode="numeric"
                      placeholder="123"
                    />
                  </div>
                </div>

                {serverError ? (
                  <p className="rounded-lg border border-flare/40 bg-flare/10 px-4 py-3 text-sm text-flare">
                    {serverError}
                  </p>
                ) : null}

                <div className="flex flex-col gap-3 sm:flex-row">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="btn btn-ghost sm:w-auto"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={placeOrder}
                    disabled={submitting}
                    className="btn btn-acid flex-1 disabled:opacity-60"
                  >
                    {submitting
                      ? "Processing…"
                      : `Pay ${formatPriceExact(totals.total)}`}
                  </button>
                </div>

                <p className="text-center text-xs text-bone/35">
                  By placing this order you agree to our terms. Demo store — no
                  charge is made.
                </p>
              </section>
            ) : null}
          </div>
        </div>

        {/* Summary column */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="border border-white/12 bg-void-soft">
            <div className="border-b border-white/10 px-6 py-5">
              <h2 className="text-sm font-bold tracking-[-0.01em]">
                Order summary{" "}
                <span className="text-bone/40 tabular-nums">({count})</span>
              </h2>
            </div>

            <ul className="max-h-[22rem] divide-y divide-white/8 overflow-y-auto px-6">
              {lines.map((line) => (
                <li
                  key={`${line.slug}-${line.size}`}
                  className="flex items-center gap-4 py-4"
                >
                  <div className="relative h-16 w-14 shrink-0 overflow-hidden bg-void">
                    {line.image ? (
                      <Image
                        src={line.image}
                        alt={line.name}
                        fill
                        sizes="56px"
                        className="object-cover"
                      />
                    ) : null}
                    <span className="absolute -top-0 -right-0 grid h-5 w-5 place-items-center rounded-bl-lg bg-acid text-[0.6rem] font-bold text-void tabular-nums">
                      {line.quantity}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{line.name}</p>
                    <p className="mt-0.5 text-xs text-bone/40">
                      {line.colorway} · {line.size}
                    </p>
                  </div>
                  <span className="shrink-0 text-sm font-semibold tabular-nums">
                    {formatPrice(line.price * line.quantity)}
                  </span>
                </li>
              ))}
            </ul>

            <div className="space-y-4 border-t border-white/10 px-6 py-5">
              <div className="flex gap-2">
                <input
                  value={promoInput}
                  onChange={(event) =>
                    setPromoInput(event.target.value.toUpperCase())
                  }
                  placeholder="Promo code"
                  aria-label="Promo code"
                  className="field flex-1"
                />
                <button
                  type="button"
                  onClick={applyPromo}
                  className="btn btn-ghost shrink-0 !px-5"
                >
                  Apply
                </button>
              </div>
              {promoError ? (
                <p className="text-xs text-flare">{promoError}</p>
              ) : null}
              {promo ? (
                <p className="flex items-center justify-between text-xs text-acid">
                  <span>
                    {promo} · {PROMO_CODES[promo].label}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setPromo(null);
                      setPromoInput("");
                    }}
                    className="text-bone/40 transition-colors hover:text-flare"
                  >
                    Remove
                  </button>
                </p>
              ) : null}
              {!promo ? (
                <p className="text-xs text-bone/30">
                  Try VOID10 or NIGHTSHIFT.
                </p>
              ) : null}
            </div>

            <dl className="space-y-2.5 border-t border-white/10 px-6 py-5 text-sm">
              <Row label="Subtotal" value={formatPriceExact(subtotal)} />
              {totals.discount > 0 ? (
                <Row
                  label="Discount"
                  value={`−${formatPriceExact(totals.discount)}`}
                  accent
                />
              ) : null}
              <Row
                label={`Shipping · ${shipping.label}`}
                value={
                  totals.shipping === 0
                    ? "Free"
                    : formatPriceExact(totals.shipping)
                }
              />
              <Row label="Estimated tax" value={formatPriceExact(totals.tax)} />
              <div className="flex items-baseline justify-between border-t border-white/12 pt-4">
                <dt className="text-base font-bold">Total</dt>
                <dd className="flex items-baseline gap-2">
                  <span className="text-[0.65rem] tracking-[0.14em] text-bone/35 uppercase">
                    USD
                  </span>
                  <span className="text-xl font-bold tabular-nums">
                    {formatPriceExact(totals.total)}
                  </span>
                </dd>
              </div>
            </dl>
          </div>

          <ul className="mt-6 space-y-2 text-xs text-bone/40">
            <li>· Free returns within 30 days</li>
            <li>· Free repairs for the life of the garment</li>
            <li>· Carbon-neutral tracked delivery</li>
          </ul>
        </aside>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  accent = false,
}: {
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-bone/50">{label}</dt>
      <dd className={`tabular-nums ${accent ? "text-acid" : ""}`}>{value}</dd>
    </div>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
  error,
  placeholder,
  autoComplete,
  inputMode,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  placeholder?: string;
  autoComplete?: string;
  inputMode?: "numeric" | "text" | "email";
}) {
  return (
    <div>
      <label htmlFor={id} className="field-label block">
        {label}
      </label>
      <input
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        inputMode={inputMode}
        aria-invalid={error ? "true" : undefined}
        className={`field mt-1.5 ${error ? "!border-flare" : ""}`}
      />
      <FieldError message={error} />
    </div>
  );
}

function FieldError({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <p className="mt-1.5 text-[0.7rem] text-flare animate-[fade_0.3s_ease_both]">
      {message}
    </p>
  );
}
