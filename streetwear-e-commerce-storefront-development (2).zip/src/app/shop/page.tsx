import type { Metadata } from "next";
import ShopBrowser from "@/components/ShopBrowser";
import Reveal from "@/components/Reveal";
import { getAllProducts, getCollections, getFacetCounts } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop all",
  description:
    "Browse every voidzone piece — heavyweight hoodies, technical outerwear, cargo trousers, knitwear, footwear and accessories.",
};

export default async function ShopPage() {
  const [products, collections, facets] = await Promise.all([
    getAllProducts(),
    getCollections(),
    getFacetCounts(),
  ]);

  return (
    <div className="pt-[76px]">
      <header className="mx-auto max-w-[1500px] px-5 pt-14 pb-10 sm:px-8 sm:pt-20">
        <Reveal>
          <p className="eyebrow flex items-center gap-3 text-acid">
            <span className="inline-block h-[1px] w-8 bg-acid" />
            {products.length} pieces · AW26
          </p>
          <h1 className="mt-5 max-w-3xl text-[clamp(2.6rem,8vw,6rem)] leading-[0.86] font-extrabold tracking-[-0.05em]">
            THE FULL RANGE
          </h1>
          <p className="mt-6 max-w-xl text-[0.98rem] leading-relaxed text-bone/55">
            Every voidzone piece currently in production. Filter by category,
            collection, size or price — the range changes when a colourway sells
            through, not when the calendar says so.
          </p>
        </Reveal>
      </header>

      <ShopBrowser
        products={products}
        collections={collections.map((collection) => ({
          slug: collection.slug,
          name: collection.name,
          count: collection.products.length,
        }))}
        categoryCounts={facets.categories}
        minPrice={facets.minPrice}
        maxPrice={facets.maxPrice}
      />
    </div>
  );
}
