import Link from "next/link";

export default function NotFound() {
  return (
    <div className="grid min-h-[80svh] place-items-center px-6 pt-[76px]">
      <div className="text-center">
        <p className="eyebrow text-acid">Error 404</p>
        <h1 className="mt-5 text-[clamp(3rem,12vw,8rem)] leading-[0.85] font-extrabold tracking-[-0.06em]">
          LOST IN
          <br />
          THE VOID
        </h1>
        <p className="mx-auto mt-6 max-w-md text-[0.95rem] leading-relaxed text-bone/55">
          This page has either sold out or never existed. The good stuff is one
          click away.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Link href="/shop" className="btn btn-acid">
            Shop all
          </Link>
          <Link href="/" className="btn btn-ghost">
            Back home
          </Link>
        </div>
      </div>
    </div>
  );
}
