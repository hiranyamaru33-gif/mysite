import Image from "next/image";
import Link from "next/link";
import Hero from "@/components/Hero";
import ProductGrid from "@/components/ProductGrid";
import Reveal from "@/components/Reveal";
import SectionHeading from "@/components/SectionHeading";
import NewsletterForm from "@/components/NewsletterForm";
import Stars from "@/components/Stars";
import { getCollections, getFeaturedProducts, getNewArrivals } from "@/lib/data";
import { CATEGORY_LABELS } from "@/lib/catalog";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

const HERO_IMAGE =
  "https://images.pexels.com/photos/10378760/pexels-photo-10378760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=2000";

const HERO_ALT =
  "Group of models in heavyweight streetwear posing on a concrete platform at night";

const CATEGORY_TILES = [
  {
    slug: "hoodies",
    image:
      "https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    alt: "Model wearing a heavyweight hoodie against a grey backdrop",
  },
  {
    slug: "outerwear",
    image:
      "https://images.pexels.com/photos/5236966/pexels-photo-5236966.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    alt: "Model wearing a satin bomber jacket",
  },
  {
    slug: "bottoms",
    image:
      "https://images.pexels.com/photos/19189048/pexels-photo-19189048.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    alt: "Model wearing cargo trousers against a graffiti wall",
  },
  {
    slug: "footwear",
    image:
      "https://images.pexels.com/photos/18368099/pexels-photo-18368099.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    alt: "Close-up of a white sneaker on an urban ledge",
  },
];

const PILLARS = [
  {
    title: "Made in small runs",
    copy: "Nothing is mass-produced. We cut 150–400 units per colourway and move on, so you are unlikely to meet yourself coming the other way.",
  },
  {
    title: "Fabric first",
    copy: "Every piece starts with the mill. 500gsm loopback, 3-layer membranes, 14oz selvedge — chosen for how it ages, not how it photographs.",
  },
  {
    title: "Repaired, not replaced",
    copy: "Free repairs for the life of every garment. Send it back, we stitch it, you get it back within ten days.",
  },
];

export default async function HomePage() {
  const [featured, collections, arrivals] = await Promise.all([
    getFeaturedProducts(8),
    getCollections(),
    getNewArrivals(3),
  ]);

  const hero = featured[0] ?? arrivals[0] ?? null;
  const totalReviews = featured.reduce((sum, p) => sum + p.reviewCount, 0);

  const stats = [
    { value: "500gsm", label: "Core fleece" },
    { value: `${featured.length * 3}+`, label: "Pieces in stock" },
    { value: `${totalReviews * 6}`, label: "Orders shipped" },
  ];

  const testimonial = {
    quote:
      "The only hoodie I have owned that still looks intentional after two winters of daily wear.",
    author: "Iris V.",
    location: "Helsinki, FI",
    rating: 5,
  };

  return (
    <>
      <Hero image={HERO_IMAGE} alt={HERO_ALT} stats={stats} />

      {/* ---------------------------- Ticker ---------------------------- */}
      <section
        aria-label="Brand statement"
        className="overflow-hidden border-y border-white/10 bg-void-soft py-5"
      >
        <div className="flex w-max animate-marquee items-center gap-8 will-change-transform">
          {[0, 1].map((copy) => (
            <div
              key={copy}
              className="flex items-center gap-8"
              aria-hidden={copy === 1}
            >
              {[
                "Heavyweight",
                "Small runs",
                "Made in Portugal",
                "Free repairs for life",
                "Carbon neutral",
                "No seasonal waste",
              ].map((word) => (
                <span
                  key={word}
                  className="flex items-center gap-8 font-[family-name:var(--font-display)] text-lg font-bold tracking-[-0.02em] whitespace-nowrap text-bone/45 uppercase"
                >
                  {word}
                  <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-acid" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ------------------------- Category tiles ----------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-20 sm:px-8 sm:pt-28">
        <SectionHeading
          eyebrow="Categories"
          title="Shop by silhouette"
          copy="Four bodies carry the whole range. Everything else is a variation on them."
        />

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {CATEGORY_TILES.map((tile, index) => (
            <Reveal key={tile.slug} delay={index * 80}>
              <Link
                href={`/shop?category=${tile.slug}`}
                className="group relative block aspect-[4/5] overflow-hidden bg-void-soft"
              >
                <Image
                  src={tile.image}
                  alt={tile.alt}
                  fill
                  sizes="(max-width: 640px) 100vw, 25vw"
                  className="object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.07]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void via-void/25 to-transparent opacity-90 transition-opacity duration-700 group-hover:opacity-70" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5">
                  <h3 className="text-xl font-bold tracking-[-0.03em]">
                    {CATEGORY_LABELS[tile.slug] ?? tile.slug}
                  </h3>
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-white/25 text-bone transition-[background-color,color,transform] duration-500 group-hover:translate-x-1 group-hover:border-acid group-hover:bg-acid group-hover:text-void">
                    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
                      <path
                        d="M1 7h12M8 2l5 5-5 5"
                        stroke="currentColor"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* --------------------------- Collections ------------------------ */}
      <section
        id="collections"
        className="mx-auto max-w-[1500px] scroll-mt-24 px-5 pt-24 sm:px-8 sm:pt-32"
      >
        <SectionHeading
          eyebrow="Featured collections"
          title="Four rooms in the same building"
          copy="Void Core never leaves. Night Shift is built for after dark. Off-Grid handles weather. Archive comes back once, then it is gone."
          href="/shop"
          linkLabel="Shop everything"
        />

        <div className="mt-12 space-y-5">
          {collections.map((collection, index) => {
            const lead = collection.products[0];
            const from = lead ? Math.min(...collection.products.map((p) => p.price)) : 0;

            return (
              <Reveal key={collection.slug} delay={index * 70}>
                <Link
                  href={`/shop?collection=${collection.slug}`}
                  className={`group relative grid overflow-hidden border border-white/10 bg-void-soft transition-colors duration-500 hover:border-white/25 lg:grid-cols-2 ${
                    index % 2 === 1 ? "lg:[&>figure]:order-2" : ""
                  }`}
                >
                  <figure className="relative aspect-[16/10] lg:aspect-auto lg:min-h-[26rem]">
                    <Image
                      src={collection.image}
                      alt={collection.alt}
                      fill
                      sizes="(max-width: 1024px) 100vw, 50vw"
                      className="object-cover transition-transform duration-[1400ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.05]"
                    />
                    <div className="absolute inset-0 bg-void/25 transition-opacity duration-700 group-hover:opacity-0" />
                  </figure>

                  <div className="flex flex-col justify-center gap-5 p-7 sm:p-12">
                    <div className="flex items-center gap-3">
                      <span className="eyebrow text-acid">
                        {collection.tagline}
                      </span>
                      <span className="h-[1px] flex-1 bg-white/12" />
                      <span className="text-[0.7rem] text-bone/35 tabular-nums">
                        {collection.products.length} pieces
                      </span>
                    </div>

                    <h3 className="text-[clamp(2rem,4.4vw,3.4rem)] leading-[0.9] font-extrabold tracking-[-0.045em]">
                      {collection.name}
                    </h3>

                    <p className="max-w-md text-[0.95rem] leading-relaxed text-bone/55">
                      {collection.blurb}
                    </p>

                    <div className="flex flex-wrap items-center gap-4 pt-1">
                      <span className="btn btn-ghost">
                        Explore collection
                      </span>
                      {lead ? (
                        <span className="text-xs text-bone/40">
                          From {formatPrice(from)}
                        </span>
                      ) : null}
                    </div>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ----------------------------- Featured ------------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-24 sm:px-8 sm:pt-32">
        <SectionHeading
          eyebrow="Most wanted"
          title="The pieces that keep selling out"
          copy="Ranked by what actually moved this season, not by what we need to shift."
          href="/shop?sort=popular"
          linkLabel="Shop all"
        />
        <div className="mt-12">
          <ProductGrid products={featured} priorityCount={4} />
        </div>
      </section>

      {/* ------------------------------ Story --------------------------- */}
      <section
        id="story"
        className="relative mt-28 scroll-mt-24 overflow-hidden border-y border-white/10"
      >
        <div className="absolute inset-0">
          <Image
            src="https://images.pexels.com/photos/10380584/pexels-photo-10380584.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1800"
            alt="Models in streetwear posing beside a car under an illuminated bridge at night"
            fill
            sizes="100vw"
            className="object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-void via-void/80 to-void/40" />
        </div>

        <div className="relative mx-auto grid max-w-[1500px] gap-14 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-[1fr_1.15fr] lg:items-center">
          <Reveal>
            <p className="eyebrow flex items-center gap-3 text-acid">
              <span className="inline-block h-[1px] w-8 bg-acid" />
              Why it costs what it costs
            </p>
            <h2 className="mt-5 text-[clamp(2.1rem,5vw,4rem)] leading-[0.92] font-extrabold tracking-[-0.045em]">
              We would rather sell you{" "}
              <em className="font-[family-name:var(--font-editorial)] font-normal italic">
                one
              </em>{" "}
              good thing.
            </h2>
            <p className="mt-6 max-w-lg text-[0.98rem] leading-relaxed text-bone/60">
              voidzone started in a Rotterdam garage in 2019 with a single
              hoodie pattern and a stubborn opinion: streetwear had stopped being
              about construction. We went back to the mills, paid for the fabric
              we wanted, and let the price follow.
            </p>

            <div className="mt-9 grid gap-7 sm:grid-cols-3">
              {PILLARS.map((pillar) => (
                <div key={pillar.title}>
                  <h3 className="text-[0.8rem] font-bold tracking-[0.06em] text-bone uppercase">
                    {pillar.title}
                  </h3>
                  <p className="mt-2 text-[0.82rem] leading-relaxed text-bone/50">
                    {pillar.copy}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={140}>
            <figure className="relative border border-white/12 bg-void-soft/80 p-8 backdrop-blur-sm sm:p-12">
              <div className="absolute -top-4 left-8 font-[family-name:var(--font-editorial)] text-6xl leading-none text-acid select-none">
                &ldquo;
              </div>
              <blockquote className="font-[family-name:var(--font-editorial)] text-[clamp(1.35rem,2.6vw,2rem)] leading-[1.25] text-bone/90 italic">
                {testimonial.quote}
              </blockquote>
              <figcaption className="mt-8 flex items-center gap-4 border-t border-white/10 pt-6">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-acid/15 font-[family-name:var(--font-display)] text-sm font-bold text-acid">
                  {testimonial.author.slice(0, 1)}
                </span>
                <div>
                  <p className="text-sm font-semibold">{testimonial.author}</p>
                  <p className="text-xs text-bone/40">{testimonial.location}</p>
                </div>
                <Stars
                  rating={testimonial.rating}
                  size={13}
                  className="ml-auto"
                />
              </figcaption>
            </figure>
          </Reveal>
        </div>
      </section>

      {/* ---------------------------- New arrivals ---------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-24 sm:px-8 sm:pt-32">
        <SectionHeading
          eyebrow="Just landed"
          title="New arrivals"
          href="/shop?sort=newest"
          linkLabel="See everything new"
        />
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {arrivals.map((product, index) => (
            <Reveal key={product.slug} delay={index * 90}>
              <Link
                href={`/product/${product.slug}`}
                className="group flex h-full flex-col overflow-hidden border border-white/10 bg-void-soft transition-colors duration-500 hover:border-white/25"
              >
                <div className="relative aspect-[16/11] overflow-hidden">
                  <Image
                    src={product.images[0]?.url ?? ""}
                    alt={product.images[0]?.alt ?? product.name}
                    fill
                    sizes="(max-width: 1024px) 100vw, 33vw"
                    className="object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.06]"
                  />
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <p className="eyebrow text-acid">
                    {CATEGORY_LABELS[product.category] ?? product.category}
                  </p>
                  <h3 className="mt-3 text-2xl leading-tight font-bold tracking-[-0.03em]">
                    {product.name}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm text-bone/50">
                    {product.subtitle}
                  </p>
                  <div className="mt-auto flex items-center justify-between pt-6">
                    <span className="text-lg font-semibold tabular-nums">
                      {formatPrice(product.price)}
                    </span>
                    <span className="text-[0.7rem] tracking-[0.16em] text-bone/50 uppercase transition-colors group-hover:text-acid">
                      View piece →
                    </span>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------ CTA ----------------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-24 sm:px-8 sm:pt-32">
        <Reveal>
          <div className="relative overflow-hidden border border-white/12 bg-void-soft px-6 py-16 text-center sm:px-12 sm:py-24">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -top-1/2 left-1/2 h-[40rem] w-[40rem] -translate-x-1/2 rounded-full bg-acid/10 blur-[120px]"
            />
            <div className="relative">
              <p className="eyebrow text-acid">Drop 05 — 14 March</p>
              <h2 className="mx-auto mt-5 max-w-3xl text-[clamp(2.2rem,6vw,4.6rem)] leading-[0.9] font-extrabold tracking-[-0.05em]">
                Get first access to the next voidzone drop
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-[0.95rem] leading-relaxed text-bone/55">
                Subscribers get a 30-minute head start and 10% off their first
                order. Roughly one email a month, and never on a Sunday.
              </p>
              <NewsletterForm
                id="cta-email"
                variant="inline"
                label="Email address"
                note="No spam. Roughly one email a month."
              />
              {hero ? (
                <p className="mt-6 text-xs text-bone/35">
                  Currently trending:{" "}
                  <Link
                    href={`/product/${hero.slug}`}
                    className="link-sweep text-bone/60"
                  >
                    {hero.name}
                  </Link>
                </p>
              ) : null}
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
