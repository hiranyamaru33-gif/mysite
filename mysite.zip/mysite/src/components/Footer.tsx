import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-neutral-950">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 py-16">
        <div className="grid md:grid-cols-4 gap-10 md:gap-16">
          <div className="md:col-span-2">
            <Link href="/" className="font-[family-name:var(--font-cormorant)] text-3xl font-bold tracking-tight text-white hover:text-amber-400 transition-colors inline-block">
              VOIDZONE
            </Link>
            <p className="text-sm text-neutral-500 mt-4 max-w-sm leading-relaxed">
              Premium streetwear for the modern silhouette. Oversized fits, bold prints, and refined materials.
            </p>
          </div>
          <div>
            <h4 className="text-xs font-bold tracking-[0.2em] text-neutral-500 uppercase mb-5">Shop</h4>
            <div className="space-y-3 text-sm text-neutral-300">
              <Link href="/shop" className="block hover:text-amber-400 transition-colors">All Products</Link>
              <Link href="/shop?category=hoodies" className="block hover:text-amber-400 transition-colors">Hoodies</Link>
              <Link href="/shop?category=pants" className="block hover:text-amber-400 transition-colors">Pants</Link>
              <Link href="/shop?category=accessories" className="block hover:text-amber-400 transition-colors">Accessories</Link>
            </div>
          </div>
          <div>
            <h4 className="text-xs font-bold tracking-[0.2em] text-neutral-500 uppercase mb-5">Company</h4>
            <div className="space-y-3 text-sm text-neutral-300">
              <Link href="#" className="block hover:text-amber-400 transition-colors">Lookbook</Link>
              <Link href="#" className="block hover:text-amber-400 transition-colors">About</Link>
              <Link href="#" className="block hover:text-amber-400 transition-colors">Contact</Link>
              <Link href="#" className="block hover:text-amber-400 transition-colors">Shipping</Link>
            </div>
          </div>
        </div>
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-600">
          <p>© 2026 VOIDZONE. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="#" className="hover:text-neutral-400 transition-colors">Privacy</Link>
            <Link href="#" className="hover:text-neutral-400 transition-colors">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
