"use client";
export default function AnnouncementBar() {
  return (
    <div className="relative bg-neutral-950 border-b border-white/5 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 py-2.5 flex items-center justify-center gap-3 text-[11px] tracking-[0.15em] text-neutral-300">
        <span className="text-amber-400 font-bold">FREE SHIPPING</span>
        <span className="text-neutral-600">|</span>
        <span>ON ORDERS OVER $150</span>
      </div>
    </div>
  );
}
