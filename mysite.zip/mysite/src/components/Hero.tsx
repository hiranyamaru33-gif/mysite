"use client";
import { ArrowDown } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="relative min-h-[92vh] flex items-end overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="/images/hero.jpg"
          alt="Streetwear editorial"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/30 to-neutral-950/20" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-10 pb-24 pt-48 w-full">
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className="text-amber-400 text-xs font-bold tracking-[0.25em] uppercase mb-6">
            Spring / Summer 2026
          </p>
          <h1 className="font-[family-name:var(--font-cormorant)] text-5xl sm:text-7xl lg:text-9xl font-light leading-[0.92] text-white tracking-tight max-w-5xl">
            Oversized<br />
            <span className="italic font-light text-neutral-300">for the modern</span><br />
            silhouette.
          </h1>
          <div className="mt-10 flex items-center gap-6">
            <Link
              href="/shop"
              className="inline-flex items-center gap-2 bg-white text-neutral-950 px-8 py-4 text-sm font-semibold tracking-wide rounded-full hover:bg-amber-400 transition-colors"
            >
              SHOP COLLECTION
            </Link>
            <Link
              href="#collections"
              className="inline-flex items-center gap-2 text-white text-sm font-medium tracking-wide hover:text-amber-400 transition-colors group"
            >
              EXPLORE <ArrowDown size={16} className="group-hover:translate-y-0.5 transition-transform" />
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
