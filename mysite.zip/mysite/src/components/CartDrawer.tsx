"use client";
import { X, Plus, Minus, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useCart } from "@/lib/cart-context";
import Link from "next/link";

export default function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    removeFromCart,
    updateQuantity,
    totalItems,
    totalPrice,
  } = useCart();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[60] bg-neutral-950/50 backdrop-blur-sm"
            onClick={closeCart}
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-[60] w-full max-w-md bg-neutral-900 border-l border-white/5 shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="flex items-center justify-between px-6 h-16 border-b border-white/5">
              <h2 className="font-[family-name:var(--font-cormorant)] text-xl font-semibold tracking-tight">
                Cart ({totalItems})
              </h2>
              <button
                onClick={closeCart}
                className="p-2 text-neutral-400 hover:text-white transition-colors"
                aria-label="Close cart"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
              {items.length === 0 ? (
                <div className="text-center py-20 text-neutral-500">
                  <p className="text-sm">Your cart is empty.</p>
                  <p className="text-xs mt-2 text-neutral-600">Add something to get started.</p>
                </div>
              ) : (
                items.map((item) => (
                  <div key={`${item.id}-${item.size}`} className="flex gap-4 group">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-20 h-24 object-cover rounded-md bg-neutral-800 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-medium text-white leading-tight truncate">
                        {item.name}
                      </h3>
                      <p className="text-xs text-neutral-500 mt-1">Size: {item.size}</p>
                      <p className="text-xs text-neutral-500">Color: {item.color}</p>
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-3 bg-neutral-800 rounded-full px-2 py-0.5">
                          <button
                            onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
                            className="text-neutral-400 hover:text-amber-400 transition-colors"
                            aria-label="Decrease"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="text-xs font-medium tabular-nums w-4 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
                            className="text-neutral-400 hover:text-amber-400 transition-colors"
                            aria-label="Increase"
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.id, item.size)}
                          className="text-neutral-600 hover:text-red-400 transition-colors"
                          aria-label="Remove"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-medium tabular-nums">
                        ${(parseFloat(item.price) * item.quantity).toFixed(2)}
                      </p>
                      <p className="text-xs text-neutral-500">${item.price} ea.</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className="border-t border-white/5 px-6 py-6 bg-neutral-900/50">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-neutral-400">Subtotal</span>
                  <span className="text-lg font-semibold font-[family-name:var(--font-cormorant)] tabular-nums">
                    ${totalPrice.toFixed(2)}
                  </span>
                </div>
                <p className="text-xs text-neutral-500 mb-5">Shipping and taxes calculated at checkout.</p>
                <Link
                  href="/checkout"
                  onClick={closeCart}
                  className="block w-full bg-amber-500 hover:bg-amber-400 text-neutral-950 text-center font-semibold py-3.5 rounded-xl transition-colors text-sm tracking-wide"
                >
                  CHECKOUT
                </Link>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
