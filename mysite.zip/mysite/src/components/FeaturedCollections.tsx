import Link from "next/link";
import { ArrowRight } from "lucide-react";

const collections = [
  {
    title: "New Arrivals",
    subtitle: "Oversized essentials, fresh silhouettes",
    image: "/images/product-3.jpg",
    link: "/shop?new=true",
  },
  {
    title: "The Void Hoodie",
    subtitle: "Heavyweight fleece, bold prints",
    image: "/images/product-1.jpg",
    link: "/shop?category=hoodies",
  },
  {
    title: "Outerwear",
    subtitle: "Bomber jackets and layer pieces",
    image: "/images/product-4.jpg",
    link: "/shop?category=outerwear",
  },
];

export default function FeaturedCollections() {
  return (
    <section id="collections" className="mx-auto max-w-7xl px-6 lg:px-10 py-28">
      <div className="flex items-end justify-between mb-14">
        <div>
          <h2 className="font-[family-name:var(--font-cormorant)] text-4xl lg:text-6xl font-light tracking-tight text-white">
            Featured<br />Collections
          </h2>
        </div>
        <Link href="/shop" className="hidden sm:inline-flex items-center gap-2 text-sm text-amber-400 hover:text-amber-300 transition-colors font-medium group">
          View All <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {collections.map((col) => (
          <Link
            key={col.title}
            href={col.link}
            className="group relative h-[480px] overflow-hidden rounded-2xl"
          >
            <img
              src={col.image}
              alt={col.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-neutral-950/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="font-[family-name:var(--font-cormorant)] text-3xl font-light text-white tracking-tight group-hover:text-amber-400 transition-colors">
                {col.title}
              </h3>
              <p className="text-sm text-neutral-300 mt-1.5">{col.subtitle}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
