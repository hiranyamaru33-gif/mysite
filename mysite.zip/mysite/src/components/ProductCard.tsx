"use client";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

interface ProductCardProps {
  product: {
    id: number;
    slug: string;
    name: string;
    price: string;
    image: string;
    color: string;
    newArrival?: boolean;
    featured?: boolean;
  };
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <Link href={`/product/${product.slug}`} className="group block">
      <div className="relative overflow-hidden rounded-2xl bg-neutral-900 mb-4 aspect-[4/5]">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="bg-neutral-950/80 backdrop-blur-md rounded-full p-2 text-amber-400">
            <ArrowUpRight size={16} />
          </div>
        </div>
        {(product.newArrival || product.featured) && (
          <div className="absolute top-3 left-3 flex gap-2">
            {product.newArrival && (
              <span className="bg-amber-500 text-neutral-950 text-[10px] font-bold px-2.5 py-1 rounded-full tracking-wide">NEW</span>
            )}
            {product.featured && (
              <span className="bg-white/10 backdrop-blur-md text-white text-[10px] font-semibold px-2.5 py-1 rounded-full tracking-wide border border-white/10">FEATURED</span>
            )}
          </div>
        )}
      </div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-medium text-white group-hover:text-amber-400 transition-colors leading-snug">
            {product.name}
          </h3>
          <p className="text-xs text-neutral-500 mt-1">{product.color}</p>
        </div>
        <span className="text-sm font-semibold tabular-nums text-neutral-200 shrink-0">
          ${parseFloat(product.price).toFixed(2)}
        </span>
      </div>
    </Link>
  );
}
