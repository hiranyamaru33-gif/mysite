"use client";

import { useState } from "react";
import { useCart } from "@/lib/cart-context";
import { Check, Plus } from "lucide-react";

interface AddToCartButtonProps {
  product: {
    id: number;
    slug: string;
    name: string;
    price: string;
    image: string;
    color: string;
  };
}

export default function AddToCartButton({ product }: AddToCartButtonProps) {
  const { addToCart } = useCart();
  const [selectedSize, setSelectedSize] = useState("M");
  const [added, setAdded] = useState(false);

  const sizes = ["S", "M", "L", "XL", "XXL"];

  const handleAdd = () => {
    addToCart({
      id: product.id,
      slug: product.slug,
      name: product.name,
      price: product.price,
      image: product.image,
      size: selectedSize,
      color: product.color,
    }, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-xs font-bold tracking-[0.2em] text-neutral-500 uppercase mb-3">Select Size</h3>
        <div className="flex gap-2">
          {sizes.map((s) => (
            <button
              key={s}
              onClick={() => setSelectedSize(s)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ${
                selectedSize === s
                  ? "bg-white text-neutral-950 border-white"
                  : "bg-neutral-900 text-neutral-300 border-white/10 hover:border-white/30 hover:text-white"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={handleAdd}
        className={`w-full py-4 rounded-xl text-sm font-semibold tracking-wide transition-all flex items-center justify-center gap-2 ${
          added
            ? "bg-emerald-500 text-neutral-950"
            : "bg-amber-500 hover:bg-amber-400 text-neutral-950"
        }`}
      >
        {added ? (
          <>
            <Check size={18} /> Added to Cart
          </>
        ) : (
          <>
            <Plus size={18} /> Add to Cart — ${product.price}
          </>
        )}
      </button>
    </div>
  );
}
