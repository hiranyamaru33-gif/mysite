"use client";
import Link from "next/link";
import { ShoppingBag, Menu, X } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { useState } from "react";

export default function Header() {
  const { totalItems, toggleCart } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-neutral-950/80 backdrop-blur-xl border-b border-white/5">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <span className="font-[family-name:var(--font-cormorant)] text-2xl font-bold tracking-tight text-white group-hover:text-amber-400 transition-colors">
              VOIDZONE
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-10 text-sm font-medium tracking-wide text-neutral-300">
            <Link href="/shop" className="hover:text-amber-400 transition-colors">SHOP</Link>
            <Link href="#" className="hover:text-amber-400 transition-colors">LOOKBOOK</Link>
            <Link href="#" className="hover:text-amber-400 transition-colors">ABOUT</Link>
          </nav>

          <div className="flex items-center gap-5">
            <button
              onClick={toggleCart}
              className="relative p-2 text-neutral-300 hover:text-amber-400 transition-colors"
              aria-label="Open cart"
            >
              <ShoppingBag size={20} strokeWidth={1.5} />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-amber-500 text-[10px] font-bold text-neutral-950">
                  {totalItems}
                </span>
              )}
            </button>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 text-neutral-300 hover:text-white"
              aria-label="Menu"
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <nav className="md:hidden pb-6 pt-2 border-t border-white/5 space-y-3 text-sm font-medium text-neutral-300">
            <Link href="/shop" onClick={() => setMobileOpen(false)} className="block hover:text-amber-400">SHOP</Link>
            <Link href="#" onClick={() => setMobileOpen(false)} className="block hover:text-amber-400">LOOKBOOK</Link>
            <Link href="#" onClick={() => setMobileOpen(false)} className="block hover:text-amber-400">ABOUT</Link>
          </nav>
        )}
      </div>
    </header>
  );
}
