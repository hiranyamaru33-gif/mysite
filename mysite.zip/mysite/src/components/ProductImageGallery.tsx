"use client";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface ProductImageGalleryProps {
  images: string[];
}

export default function ProductImageGallery({ images }: ProductImageGalleryProps) {
  const [current, setCurrent] = useState(0);
  const safeImages = images.length > 0 ? images : ["/images/hero.jpg"];

  const prev = () => setCurrent((i) => (i === 0 ? safeImages.length - 1 : i - 1));
  const next = () => setCurrent((i) => (i === safeImages.length - 1 ? 0 : i + 1));

  return (
    <div className="relative">
      <div className="relative aspect-[4/5] overflow-hidden rounded-3xl bg-neutral-900">
        <img
          src={safeImages[current]}
          alt="Product"
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.03]"
        />
        <button
          onClick={prev}
          className="absolute left-4 top-1/2 -translate-y-1/2 bg-neutral-950/60 backdrop-blur-md rounded-full p-2.5 text-white hover:bg-neutral-950 transition-colors"
          aria-label="Previous image"
        >
          <ChevronLeft size={18} />
        </button>
        <button
          onClick={next}
          className="absolute right-4 top-1/2 -translate-y-1/2 bg-neutral-950/60 backdrop-blur-md rounded-full p-2.5 text-white hover:bg-neutral-950 transition-colors"
          aria-label="Next image"
        >
          <ChevronRight size={18} />
        </button>
      </div>
      <div className="flex gap-3 mt-4">
        {safeImages.map((img, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`flex-1 aspect-[4/5] overflow-hidden rounded-xl border-2 transition-all ${
              i === current ? "border-amber-400 ring-1 ring-amber-400/30" : "border-transparent opacity-60 hover:opacity-100"
            }`}
            aria-label={`Image ${i + 1}`}
          >
            <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
