import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import ProductCard from "./ProductCard";

export default async function FeaturedProducts() {
  const result = await db.query.products.findMany({
    where: eq(products.featured, true),
    with: { category: true },
  });

  return (
    <section className="mx-auto max-w-7xl px-6 lg:px-10 py-28 border-t border-white/5">
      <div className="flex items-end justify-between mb-14">
        <h2 className="font-[family-name:var(--font-cormorant)] text-4xl lg:text-6xl font-light tracking-tight text-white">
          Featured<br />Pieces
        </h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
        {result.map((p) => (
          <ProductCard
            key={p.id}
            product={{
              id: p.id,
              slug: p.slug,
              name: p.name,
              price: String(p.price),
              image: p.image,
              color: p.color,
              newArrival: p.newArrival ?? false,
              featured: p.featured ?? false,
            }}
          />
        ))}
      </div>
    </section>
  );
}
