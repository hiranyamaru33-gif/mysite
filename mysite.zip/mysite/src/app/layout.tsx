import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cormorant_Garamond, Inter } from "next/font/google";
import { CartProvider } from "@/lib/cart-context";
import AnnouncementBar from "@/components/AnnouncementBar";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-cormorant",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "VOIDZONE — Premium Streetwear",
  description: "Curated streetwear for the modern silhouette. Oversized fits, premium fabrics, and bold design.",
  keywords: ["streetwear", "street fashion", "oversized hoodie", "premium clothing", "fashion store"],
  openGraph: {
    title: "VOIDZONE — Premium Streetwear",
    description: "Curated streetwear for the modern silhouette.",
    images: [{ url: "/images/hero.jpg" }],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${cormorant.variable} ${inter.variable}`}>
      <body className="bg-neutral-950 text-neutral-50 antialiased font-[family-name:var(--font-inter)] selection:bg-amber-500/30 selection:text-amber-50">
        <CartProvider>
          <AnnouncementBar />
          <Header />
          <main>{children}</main>
          <Footer />
          <CartDrawer />
        </CartProvider>
      </body>
    </html>
  );
}
