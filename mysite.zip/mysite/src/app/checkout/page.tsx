"use client";

import { useCart } from "@/lib/cart-context";
import { useState } from "react";
import { ArrowLeft, Check } from "lucide-react";
import Link from "next/link";

export default function CheckoutPage() {
  const { items, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ email: "", name: "", address: "", city: "", zip: "", country: "US" });
  const [submitted, setSubmitted] = useState(false);

  if (items.length === 0 && !submitted) {
    return (
      <div className="mx-auto max-w-3xl px-6 pt-36 pb-20 text-center">
        <h1 className="font-[family-name:var(--font-cormorant)] text-4xl font-light tracking-tight mb-4">Your cart is empty</h1>
        <p className="text-neutral-500 mb-8">Add some pieces before checking out.</p>
        <Link href="/shop" className="inline-block bg-amber-500 text-neutral-950 px-8 py-3.5 rounded-xl text-sm font-semibold hover:bg-amber-400 transition-colors">Continue Shopping</Link>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="mx-auto max-w-xl px-6 pt-36 pb-20 text-center">
        <div className="w-20 h-20 mx-auto mb-8 rounded-full bg-emerald-500/10 flex items-center justify-center">
          <Check size={36} className="text-emerald-400" />
        </div>
        <h1 className="font-[family-name:var(--font-cormorant)] text-5xl font-light tracking-tight mb-4">Thank You</h1>
        <p className="text-neutral-400 mb-2">Your order has been confirmed.</p>
        <p className="text-sm text-neutral-500 mb-10">Order #VZ-{Math.floor(Math.random() * 90000) + 10000}</p>
        <Link href="/" className="inline-block bg-white text-neutral-950 px-8 py-3.5 rounded-xl text-sm font-semibold hover:bg-amber-400 transition-colors">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-6 pt-28 pb-20">
      <Link href="/" className="inline-flex items-center gap-2 text-xs text-neutral-500 hover:text-white mb-10 transition-colors">
        <ArrowLeft size={14} /> Back to Home
      </Link>
      <h1 className="font-[family-name:var(--font-cormorant)] text-5xl lg:text-7xl font-light tracking-tight mb-2">Checkout</h1>
      <p className="text-neutral-500 text-sm mb-16">Complete your purchase.</p>

      <div className="grid lg:grid-cols-2 gap-16">
        <div>
          <h2 className="text-sm font-bold tracking-[0.15em] text-neutral-500 uppercase mb-6">Contact</h2>
          <div className="space-y-4 mb-10">
            <input
              type="email"
              placeholder="Email address"
              className="w-full bg-neutral-900 border border-white/5 rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:border-amber-500/50 transition-colors"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>

          <h2 className="text-sm font-bold tracking-[0.15em] text-neutral-500 uppercase mb-6">Shipping</h2>
          <div className="space-y-4 mb-10">
            <input type="text" placeholder="Full name" className="w-full bg-neutral-900 border border-white/5 rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:border-amber-500/50 transition-colors" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input type="text" placeholder="Address" className="w-full bg-neutral-900 border border-white/5 rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:border-amber-500/50 transition-colors" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <div className="flex gap-4">
              <input type="text" placeholder="City" className="flex-1 bg-neutral-900 border border-white/5 rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:border-amber-500/50 transition-colors" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              <input type="text" placeholder="ZIP" className="w-32 bg-neutral-900 border border-white/5 rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:border-amber-500/50 transition-colors" value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} />
            </div>
            <select
              className="w-full bg-neutral-900 border border-white/5 rounded-xl px-5 py-3.5 text-sm text-white focus:outline-none focus:border-amber-500/50 transition-colors appearance-none"
              value={form.country}
              onChange={(e) => setForm({ ...form, country: e.target.value })}
            >
              <option>United States</option>
              <option>Canada</option>
              <option>United Kingdom</option>
              <option>Australia</option>
            </select>
          </div>

          <h2 className="text-sm font-bold tracking-[0.15em] text-neutral-500 uppercase mb-6">Payment</h2>
          <p className="text-xs text-neutral-500">Demo checkout — no real payment is processed.</p>
        </div>

        <div className="bg-neutral-900 rounded-3xl p-8 lg:p-10 border border-white/5 h-fit sticky top-28">
          <h3 className="text-sm font-bold tracking-[0.15em] text-neutral-500 uppercase mb-6">Order Summary</h3>
          {items.map((item) => (
            <div key={`${item.id}-${item.size}`} className="flex gap-4 mb-5">
              <img src={item.image} alt={item.name} className="w-16 h-20 object-cover rounded-xl bg-neutral-800 shrink-0" />
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-white truncate">{item.name}</h4>
                <p className="text-xs text-neutral-500">Size: {item.size} · Qty: {item.quantity}</p>
              </div>
              <span className="text-sm font-medium tabular-nums text-neutral-300 shrink-0">${(parseFloat(item.price) * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div className="border-t border-white/5 pt-6 space-y-3">
            <div className="flex justify-between text-sm text-neutral-400"><span>Subtotal</span><span className="tabular-nums">${totalPrice.toFixed(2)}</span></div>
            <div className="flex justify-between text-sm text-neutral-400"><span>Shipping</span><span className="tabular-nums">Free</span></div>
            <div className="flex justify-between text-lg font-semibold pt-2 border-t border-white/10"><span>Total</span><span className="font-[family-name:var(--font-cormorant)] text-2xl tabular-nums">${totalPrice.toFixed(2)}</span></div>
          </div>
          <button
            onClick={() => { setSubmitted(true); clearCart(); }}
            className="w-full mt-8 bg-amber-500 hover:bg-amber-400 text-neutral-950 py-4 rounded-xl text-sm font-bold tracking-wide transition-colors"
          >
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
}
