import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { eq } from "drizzle-orm";
import { Star, Check, ArrowRight } from "lucide-react";
import { notFound } from "next/navigation";
import Link from "next/link";
import ProductImageGallery from "@/components/ProductImageGallery";
import AddToCartButton from "@/components/AddToCartButton";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await db.query.products.findFirst({
    where: eq(products.slug, slug),
    with: { category: true, reviews: true },
  });

  if (!product) return notFound();

  const avgRating = product.reviews.length
    ? product.reviews.reduce((s, r) => s + r.rating, 0) / product.reviews.length
    : 0;

  const imageList = product.images && product.images.length > 0 ? product.images : [product.image, product.image];

  return (
    <div className="mx-auto max-w-7xl px-6 lg:px-10 pt-28 pb-20">
      <nav className="text-xs text-neutral-500 mb-10 flex items-center gap-2">
        <Link href="/" className="hover:text-white">Home</Link>
        <ArrowRight size={10} />
        <Link href="/shop" className="hover:text-white">Shop</Link>
        <ArrowRight size={10} />
        <span className="text-neutral-300 truncate max-w-[200px]">{product.name}</span>
      </nav>

      <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
        {/* Images */}
        <ProductImageGallery images={imageList} />

        {/* Info */}
        <div className="flex flex-col">
          <div className="mb-2 flex items-center gap-2">
            {product.newArrival && (
              <span className="bg-amber-500 text-neutral-950 text-[10px] font-bold px-2.5 py-0.5 rounded-full tracking-wide">NEW</span>
            )}
            {product.featured && (
              <span className="bg-white/10 text-white text-[10px] font-semibold px-2.5 py-0.5 rounded-full tracking-wide border border-white/10">FEATURED</span>
            )}
          </div>

          <h1 className="font-[family-name:var(--font-cormorant)] text-4xl lg:text-6xl font-light tracking-tight text-white leading-[1.05]">
            {product.name}
          </h1>

          <div className="flex items-center gap-3 mt-4 mb-8">
            <span className="text-2xl font-semibold tabular-nums text-white">${String(product.price)}</span>
            <span className="text-sm text-neutral-500">{product.color}</span>
          </div>

          <div className="flex items-center gap-1.5 mb-8 text-amber-400">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} size={14} fill={i <= Math.round(avgRating) ? "currentColor" : "none"} strokeWidth={1.5} />
            ))}
            <span className="text-xs text-neutral-400 ml-1">({product.reviews.length} reviews)</span>
          </div>

          <p className="text-neutral-300 text-sm leading-relaxed mb-10">
            {product.description}
          </p>

          <AddToCartButton
            product={{
              id: product.id,
              slug: product.slug,
              name: product.name,
              price: String(product.price),
              image: product.image,
              color: product.color,
            }}
          />

          <div className="mt-10 pt-10 border-t border-white/5 grid grid-cols-3 gap-6 text-xs text-neutral-500">
            <div>
              <h4 className="font-semibold text-neutral-300 mb-1 uppercase tracking-wider">Material</h4>
              <p>Premium brushed fleece, ripstop cotton, satin blend</p>
            </div>
            <div>
              <h4 className="font-semibold text-neutral-300 mb-1 uppercase tracking-wider">Fit</h4>
              <p>Oversized, dropped shoulder, boxy silhouette</p>
            </div>
            <div>
              <h4 className="font-semibold text-neutral-300 mb-1 uppercase tracking-wider">Care</h4>
              <p>Cold wash, hang dry, do not bleach</p>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-28 pt-16 border-t border-white/5">
        <h2 className="font-[family-name:var(--font-cormorant)] text-3xl font-light tracking-tight text-white mb-10">Customer Reviews</h2>
        {product.reviews.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-6">
            {product.reviews.map((r) => (
              <div key={r.id} className="bg-neutral-900 rounded-2xl p-6 border border-white/5">
                <div className="flex items-center gap-0.5 mb-3 text-amber-400">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} size={14} fill={i <= r.rating ? "currentColor" : "none"} strokeWidth={1.5} />
                  ))}
                </div>
                <p className="text-sm text-neutral-300 leading-relaxed mb-4">"{r.content}"</p>
                <p className="text-xs font-semibold text-neutral-500">{r.author}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-neutral-500 text-sm">No reviews yet. Be the first.</p>
        )}
      </section>

      {/* Related */}
      <section className="mt-28 pt-16 border-t border-white/5">
        <h2 className="font-[family-name:var(--font-cormorant)] text-3xl font-light tracking-tight text-white mb-10">You Might Also Like</h2>
        <RelatedProducts currentSlug={product.slug} />
      </section>
    </div>
  );
}

async function RelatedProducts({ currentSlug }: { currentSlug: string }) {
  const all = await db.query.products.findMany({
    where: (p, { ne }) => ne(p.slug, currentSlug),
  });
  const related = all.slice(0, 4);

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
      {related.map((p) => (
        <Link key={p.id} href={`/product/${p.slug}`} className="group block">
          <div className="overflow-hidden rounded-2xl bg-neutral-900 mb-4 aspect-[4/5]">
            <img src={p.image} alt={p.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
          </div>
          <h3 className="text-sm font-medium text-white group-hover:text-amber-400 transition-colors">{p.name}</h3>
          <p className="text-xs text-neutral-500 mt-1">${String(p.price)}</p>
        </Link>
      ))}
    </div>
  );
}
