import Hero from "@/components/Hero";
import FeaturedCollections from "@/components/FeaturedCollections";
import FeaturedProducts from "@/components/FeaturedProducts";

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedCollections />
      <FeaturedProducts />
    </>
  );
}
