import { db } from "@/db";
import { products, categories } from "@/db/schema";
import Link from "next/link";

export default async function ShopPage({
  searchParams,
}: {
  searchParams?: Promise<{ category?: string; new?: string; sort?: string; q?: string }>
}) {
  const params = await searchParams ?? {};
  const categorySlug = params?.category || "";
  const showNew = params?.new === "true";
  const sort = params?.sort || "featured";
  const query = params?.q || "";

  const allCategories = await db.query.categories.findMany();
  const allProducts = await db.query.products.findMany({
    with: { category: true },
  });

  let filtered = allProducts.filter((p) => {
    if (categorySlug && p.categoryId && allCategories.find((c) => c.slug === categorySlug)?.id !== p.categoryId) {
      return false;
    }
    if (showNew && !p.newArrival) return false;
    if (query && !p.name.toLowerCase().includes(query.toLowerCase()) && !p.description?.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });

  if (sort === "price_asc") {
    filtered.sort((a, b) => Number(a.price) - Number(b.price));
  } else if (sort === "price_desc") {
    filtered.sort((a, b) => Number(b.price) - Number(a.price));
  } else if (sort === "newest") {
    filtered.sort((a, b) => (b.newArrival ? 1 : 0) - (a.newArrival ? 1 : 0));
  } else {
    filtered.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || a.id - b.id);
  }

  return (
    <div className="mx-auto max-w-7xl px-6 lg:px-10 pt-28 pb-20">
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Sidebar */}
        <aside className="lg:w-64 shrink-0">
          <h2 className="font-[family-name:var(--font-cormorant)] text-3xl font-light tracking-tight mb-8">Shop</h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-xs font-bold tracking-[0.2em] text-neutral-500 uppercase mb-3">Categories</h3>
              <div className="space-y-2">
                <Link href="/shop" className={`block text-sm ${!categorySlug ? "text-amber-400 font-medium" : "text-neutral-300 hover:text-white"}`}>All</Link>
                {allCategories.map((cat) => (
                  <Link key={cat.id} href={`/shop?category=${cat.slug}`} className={`block text-sm ${categorySlug === cat.slug ? "text-amber-400 font-medium" : "text-neutral-300 hover:text-white"}`}>
                    {cat.name}
                  </Link>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-xs font-bold tracking-[0.2em] text-neutral-500 uppercase mb-3">Filter</h3>
              <div className="space-y-2">
                <Link href={showNew ? "/shop" : "/shop?new=true"} className={`block text-sm ${showNew ? "text-amber-400 font-medium" : "text-neutral-300 hover:text-white"}`}>
                  New Arrivals
                </Link>
              </div>
            </div>
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-8">
            <p className="text-sm text-neutral-400">{filtered.length} products</p>
            <div className="flex gap-4 text-sm">
              <Link href={`/shop?category=${categorySlug}${showNew ? "&new=true" : ""}&sort=featured`} className={`hover:text-amber-400 ${sort === "featured" || !sort ? "text-amber-400" : "text-neutral-500"}`}>Featured</Link>
              <Link href={`/shop?category=${categorySlug}${showNew ? "&new=true" : ""}&sort=price_asc`} className={`hover:text-amber-400 ${sort === "price_asc" ? "text-amber-400" : "text-neutral-500"}`}>Price ↑</Link>
              <Link href={`/shop?category=${categorySlug}${showNew ? "&new=true" : ""}&sort=price_desc`} className={`hover:text-amber-400 ${sort === "price_desc" ? "text-amber-400" : "text-neutral-500"}`}>Price ↓</Link>
              <Link href={`/shop?category=${categorySlug}${showNew ? "&new=true" : ""}&sort=newest`} className={`hover:text-amber-400 ${sort === "newest" ? "text-amber-400" : "text-neutral-500"}`}>Newest</Link>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filtered.map((p) => (
              <a key={p.id} href={`/product/${p.slug}`} className="group block">
                <div className="relative overflow-hidden rounded-2xl bg-neutral-900 mb-4 aspect-[4/5]">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  {p.newArrival && (
                    <span className="absolute top-3 left-3 bg-amber-500 text-neutral-950 text-[10px] font-bold px-2.5 py-1 rounded-full">NEW</span>
                  )}
                </div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-medium text-white group-hover:text-amber-400 transition-colors leading-snug">{p.name}</h3>
                    <p className="text-xs text-neutral-500 mt-1">{p.color}</p>
                  </div>
                  <span className="text-sm font-semibold tabular-nums text-neutral-200 shrink-0">${String(p.price)}</span>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
