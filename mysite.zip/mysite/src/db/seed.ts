import { db } from "./index";
import { categories, products, reviews } from "./schema";

async function seed() {
  console.log("Seeding database...");

  await db.delete(reviews);
  await db.delete(products);
  await db.delete(categories);

  const insertedCategories = await db.insert(categories).values([
    { slug: "hoodies", name: "Hoodies", description: "Oversized and premium hoodies for street style." },
    { slug: "pants", name: "Pants", description: "Cargo, joggers, and wide-leg street pants." },
    { slug: "outerwear", name: "Outerwear", description: "Bomber jackets, coats, and layer pieces." },
    { slug: "tees", name: "Tees", description: "Graphic tees and oversized basics." },
    { slug: "accessories", name: "Accessories", description: "Caps, beanies, and finishing touches." },
  ]).returning();
  const [hoodies, pants, outerwear, tees, accessories] = insertedCategories;

  const demoProducts = [
    {
      slug: "void-hoodie-black",
      name: "Void Oversized Hoodie — Black",
      description:
        "A heavy-weight oversized hoodie in jet black. Features a dropped shoulder silhouette, ribbed cuffs, and an abstract geometric print across the back. Made from 480gsm brushed fleece with a soft, dense hand-feel. The oversized hood and extended sleeves create a dramatic, modern streetwear profile.",
      price: "189.00",
      image: "/images/product-1.jpg",
      images: ["/images/product-1.jpg", "/images/product-5.jpg"],
      categoryId: hoodies.id,
      featured: true,
      newArrival: true,
      stock: 24,
      size: ["S", "M", "L", "XL", "XXL"],
      color: "Black",
    },
    {
      slug: "void-hoodie-cream",
      name: "Void Oversized Hoodie — Cream",
      description:
        "A refined oversized hoodie in warm cream with a minimal embroidered logo at the chest. Constructed from premium heavyweight fleece with a brushed interior. The oversized fit pairs effortlessly with wide-leg pants or layered under outerwear.",
      price: "179.00",
      image: "/images/product-2.jpg",
      images: ["/images/product-2.jpg", "/images/product-8.jpg"],
      categoryId: hoodies.id,
      featured: true,
      newArrival: false,
      stock: 18,
      size: ["S", "M", "L", "XL", "XXL"],
      color: "Cream",
    },
    {
      slug: "void-cargo-olive",
      name: "Void Cargo Pants — Olive",
      description:
        "Oversized cargo pants in dark olive with oversized side pockets and an adjustable drawstring hem. Tapered fit with a low crotch and stacked leg. Made from durable ripstop cotton blend. Functional, bold, and built for movement.",
      price: "165.00",
      image: "/images/product-3.jpg",
      images: ["/images/product-3.jpg", "/images/product-1.jpg"],
      categoryId: pants.id,
      featured: true,
      newArrival: true,
      stock: 12,
      size: ["28", "30", "32", "34", "36", "38"],
      color: "Olive",
    },
    {
      slug: "void-bomber-black",
      name: "Void Bomber Jacket — Black",
      description:
        "A premium oversized bomber jacket in black with subtle texture. Features silver-tone hardware, ribbed collar, and a slightly cropped silhouette. The satin-like finish catches light, giving the jacket a premium sheen without being flashy.",
      price: "245.00",
      image: "/images/product-4.jpg",
      images: ["/images/product-4.jpg", "/images/product-5.jpg"],
      categoryId: outerwear.id,
      featured: false,
      newArrival: false,
      stock: 8,
      size: ["S", "M", "L", "XL", "XXL"],
      color: "Black",
    },
    {
      slug: "void-hoodie-charcoal",
      name: "Void Oversized Hoodie — Charcoal",
      description:
        "A dark charcoal hoodie with a slightly oversized fit and dropped shoulder. Features a minimal embroidered logo and ribbed cuffs. Made from 480gsm brushed fleece for a heavy, premium feel.",
      price: "175.00",
      image: "/images/product-5.jpg",
      images: ["/images/product-5.jpg", "/images/product-1.jpg"],
      categoryId: hoodies.id,
      featured: false,
      newArrival: true,
      stock: 15,
      size: ["S", "M", "L", "XL", "XXL"],
      color: "Charcoal",
    },
    {
      slug: "void-cap-black",
      name: "Void Logo Cap — Black",
      description:
        "A premium structured cap in black with a minimal embroidered logo on the crown. Features a flat brim, adjustable strap closure, and a structured crown. The perfect finishing touch for any streetwear fit.",
      price: "45.00",
      image: "/images/product-6.jpg",
      images: ["/images/product-6.jpg", "/images/product-4.jpg"],
      categoryId: accessories.id,
      featured: false,
      newArrival: false,
      stock: 30,
      size: ["One Size"],
      color: "Black",
    },
    {
      slug: "void-tee-white",
      name: "Void Abstract Tee — White",
      description:
        "An oversized white tee with a bold black abstract graphic print. Made from 220gsm premium cotton with a slightly boxy fit. The oversized sleeves and dropped shoulder create a modern street profile.",
      price: "75.00",
      image: "/images/product-7.jpg",
      images: ["/images/product-7.jpg", "/images/product-2.jpg"],
      categoryId: tees.id,
      featured: true,
      newArrival: false,
      stock: 22,
      size: ["S", "M", "L", "XL", "XXL"],
      color: "White",
    },
    {
      slug: "void-hoodie-navy",
      name: "Void Oversized Hoodie — Navy",
      description:
        "A rich navy oversized hoodie with a slightly cropped body and elongated sleeves. Features a minimal embroidered logo and ribbed cuffs. Made from premium heavyweight fleece with a brushed interior.",
      price: "185.00",
      image: "/images/product-8.jpg",
      images: ["/images/product-8.jpg", "/images/product-1.jpg"],
      categoryId: hoodies.id,
      featured: false,
      newArrival: true,
      stock: 14,
      size: ["S", "M", "L", "XL", "XXL"],
      color: "Navy",
    },
  ];

  const insertedProducts = await db.insert(products).values(demoProducts).returning();

  const demoReviews = [
    { productId: insertedProducts[0].id, author: "Marcus T.", rating: 5, content: "The fit is unreal. The oversized silhouette hits exactly where it should — dramatic but not sloppy. The fleece weight is genuine premium." },
    { productId: insertedProducts[0].id, author: "Jade W.", rating: 5, content: "Best hoodie I own. The geometric print is subtle in person but makes the piece stand out." },
    { productId: insertedProducts[1].id, author: "Kai L.", rating: 4, content: "Cream color is even nicer in person. Slightly oversized, pairs well with loose pants." },
    { productId: insertedProducts[2].id, author: "Riley S.", rating: 5, content: "These cargo pants are built. The fabric holds its shape and the oversized pockets are functional art." },
    { productId: insertedProducts[3].id, author: "Devon A.", rating: 5, content: "Bomber jacket is the standout piece. The texture catches the light beautifully." },
    { productId: insertedProducts[4].id, author: "Noah P.", rating: 4, content: "Heavyweight and warm. The charcoal color is versatile — works with everything." },
    { productId: insertedProducts[5].id, author: "Zara K.", rating: 5, content: "Minimal cap that completes the look. The embroidery is clean and the structure holds well." },
    { productId: insertedProducts[6].id, author: "Mia R.", rating: 5, content: "The abstract print is striking. The tee is oversized and drapes beautifully. Already ordered another color." },
  ];

  await db.insert(reviews).values(demoReviews);

  console.log(`Seeded ${insertedCategories.length} categories, ${insertedProducts.length} products, ${demoReviews.length} reviews.`);
}

seed().catch(console.error);
